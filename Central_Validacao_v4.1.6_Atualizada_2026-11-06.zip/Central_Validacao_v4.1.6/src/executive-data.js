(function(root,factory){
 const node=typeof module==='object'&&module.exports;
 const api=factory(node?require('./history-store.js'):root.ComHistory,node?require('./reconcile.js'):root.ComReconcile,node?require('./consolidated.js'):root.ComConsolidated,node?require('./model.js'):root.ComModel);
 if(node)module.exports=api;else root.ComExecutiveData=api;
})(globalThis,function(H,R,X,M){
 'use strict';
 const master=p=>String(p?.vinculos?.find(v=>String(v.values?.matricula??'').trim())?.values.matricula??p?.matricula??'');
 const dimensions={plan:'plano',sponsor:'patrocinador',group:'contractGroup',subgroup:'contractSubgroup'};
 function filter(ps,f={}){
   let rows=ps.filter(p=>R.participantMatch(p,f)&&(!f.rule||p.issues.some(i=>i.rule===f.rule))&&(!f.person||p.matricula===M.key(f.person))&&(!f.channel||(f.channel.endsWith(':valid')?p.validCounts[f.channel.split(':')[0]]>0:p.counts[f.channel.split(':')[0]]>0)));
   if(f.curiosity==='multi_email')rows=rows.filter(p=>p.counts.EM>=2);
   if(f.curiosity==='multi_mobile')rows=rows.filter(p=>p.counts.CE>=2);
   if(f.curiosity==='leader_email'||f.curiosity==='leader_mobile'){const type=f.curiosity==='leader_email'?'EM':'CE',max=rows.reduce((m,p)=>Math.max(m,p.counts[type]),0);rows=max?rows.filter(p=>p.counts[type]===max):[];}
   return rows;
 }
 function metrics(ps){const s=R.summarize(ps);return {...s,withoutMobile:ps.filter(p=>R.assessable(p)&&p.exclusions.sem_celular).length,withoutPhone:ps.filter(p=>R.assessable(p)&&p.exclusions.sem_fixo).length,coverageRate:s.identified?s.covered/s.identified:null,errorRate:s.identified?s.fail/s.identified:null};}
 function facets(ps,f,key){
   const own={...f,[key]:''},rows=filter(ps,own),values=new Set();
   for(const p of rows){
     if(dimensions[key])for(const v of X.bindings(p,own))values.add(v[dimensions[key]]);
     else if(key==='rule')for(const i of p.issues)values.add(i.rule);
     else if(key==='ageBand')values.add(M.demographicBand(p));
     else if(key==='status')values.add(p.status);
     else if(key==='treatment')values.add(p.treatmentStatus);
     else if(key==='exclusion')for(const [id]of M.exclusions)if(p.exclusions[id])values.add(id);
   }return [...values].filter(Boolean).sort((a,b)=>a.localeCompare(b,'pt-BR'));
 }
 function segments(ps,f,key){
   const groups=new Map();
   for(const p of ps){if(!R.assessable(p))continue;const values=new Set(key==='ageBand'?[M.demographicBand(p)]:X.bindings(p,f).map(v=>v[dimensions[key]]));for(const value of values){if(!groups.has(value))groups.set(value,[]);groups.get(value).push(p);}}
   return [...groups].map(([label,rows])=>({label,...metrics(rows)})).sort((a,b)=>b.fail-a.fail||b.identified-a.identified);
 }
 function findings(p,all=true){
   const out=(all?p.allContextIssues||p.contextIssues:p.contextIssues).map(i=>({...i,evidence:i.migrationNote?'Detalhamento de origem não disponível no histórico anterior.':i.raw||i.message,key:i.rule+'|'+(i.problemCode||i.problem||i.message)}));
   for(const c of p.channels||p.evidenceContacts||[])for(const i of all?c.allIssues||c.issues:c.issues){const canonical=c.typeCode==='EM'?String(c.normalized||c.raw).toLowerCase():String(c.ddd||'')+'|'+String(c.normalized||c.raw);out.push({...i,evidence:c.label+': '+R.evidence(c),key:i.rule+'|'+c.typeCode+'|'+canonical+'|'+(i.problemCode||i.problem||i.message)});}
   return out;
 }
 function risks(ps){const groups=new Map();for(const p of ps)for(const i of p.issues){if(!groups.has(i.rule))groups.set(i.rule,{rule:i.rule,label:M.rules.find(r=>r.id===i.rule)?.label||i.ruleLabel,severity:i.severity,people:new Set(),occurrences:0});const g=groups.get(i.rule);g.people.add(p.id);g.occurrences++;}return [...groups.values()].map(g=>({...g,people:g.people.size})).sort((a,b)=>b.occurrences-a.occurrences);}
 function counts(ps,all=true){const out=new Map();for(const p of ps){if(!R.assessable(p))continue;for(const i of findings(p,all)){if(!out.has(i.rule))out.set(i.rule,{occurrences:0,people:new Set()});const g=out.get(i.rule);g.occurrences++;g.people.add(p.matricula);}}return out;}
 function inventory(items){const map=new Map();for(const i of items){if(!map.has(i.key))map.set(i.key,[]);map.get(i.key).push(i);}return map;}
 function flow(before,after){
   const old=inventory(before),now=inventory(after),enteredIssues=[],exitedIssues=[];let retained=0;
   for(const key of new Set([...old.keys(),...now.keys()])){const a=old.get(key)||[],b=now.get(key)||[],keep=Math.min(a.length,b.length);retained+=keep;for(let i=keep;i<a.length;i++)exitedIssues.push(a[i]);for(let i=keep;i<b.length;i++)enteredIssues.push(b[i]);}
   return {entered:enteredIssues.length,exited:exitedIssues.length,retained,enteredIssues,exitedIssues};
 }
 function ruleRows(current,previous,f={}){
   const ps=filter(H.people(current),f),prior=previous?filter(H.people(previous),f):[],a=counts(ps),b=counts(prior),flows=new Map();
   const canFlow=previous&&!previous.migrationNote&&!current.migrationNote;
   if(canFlow){
     const collect=rows=>{const byRule=new Map();for(const p of rows)for(const i of findings(p,true)){if(!byRule.has(i.rule))byRule.set(i.rule,new Map());const map=byRule.get(i.rule),key=JSON.stringify([p.matricula,i.key]);map.set(key,(map.get(key)||0)+1);}return byRule;},before=collect(prior),after=collect(ps);
     for(const r of M.rules){const old=before.get(r.id)||new Map(),now=after.get(r.id)||new Map();let entered=0,exited=0,retained=0;for(const key of new Set([...old.keys(),...now.keys()])){const a=old.get(key)||0,b=now.get(key)||0,keep=Math.min(a,b);retained+=keep;entered+=b-keep;exited+=a-keep;}flows.set(r.id,{entered,exited,retained});}
   }
   return M.rules.map(r=>{const available=previous&&(previous.result.evaluatedRules||previous.result.selection).includes(r.id),value=a.get(r.id)?.occurrences||0,old=available?b.get(r.id)?.occurrences||0:null,x=available?flows.get(r.id):null;return {rule:r.id,label:r.label,severity:r.severity,current:value,previous:old,people:a.get(r.id)?.people.size||0,delta:available?value-old:null,entered:x?.entered??null,exited:x?.exited??null,retained:x?.retained??null,rate:available?(old>0?(value-old)/old:value===0?0:null):null};});
 }
 const ageRanges=M.demographicRanges;
 function demographics(ps){
   const rows=ageRanges.map(([label])=>({label,F:0,M:0,N:0,D:0,total:0})),byLabel=new Map(rows.map(r=>[r.label,r]));
   for(const p of ps){if(!R.assessable(p))continue;const row=byLabel.get(M.demographicBand(p)),sex=M.participantSex(p);row[sex]++;row.total++;}return rows;
 }
 function compare(current,previous,f={}){
   if(!previous)return {available:false,reason:'Não há fotografia do mês anterior disponível.'};
   if(previous.migrationNote&&(f.status||f.treatment||f.rule==='shared'))return {available:false,reason:'O histórico convertido não permite comparar este critério sem nova validação da origem.'};
   if(H.profile(current)!==H.profile(previous))return {available:false,reason:'Os perfis de regras dos períodos são diferentes.'};
   const a=metrics(filter(H.people(current),f)),b=metrics(filter(H.people(previous),f));
   if(!a.identified||!b.identified)return {available:false,reason:'O recorte não possui público nos dois períodos.'};
   return {available:true,current:a,previous:b,coveragePP:(a.coverageRate-b.coverageRate)*100,errorPP:(a.errorRate-b.errorRate)*100,withoutAny:a.withoutAny-b.withoutAny,public:a.identified-b.identified};
 }
 function series(db,f={},selected=null){
   const candidates=H.canonical(selected?.classification==='demonstration'?{...db,runs:db.runs.filter(r=>r.classification==='demonstration')}:db);
   const runs=selected?[...candidates.filter(r=>r.photo<selected.photo&&r.photo.slice(0,7)!==selected.photo.slice(0,7)),selected]:candidates;
   return runs.map(run=>{const m=H.measure(run,f)||(run.people?metrics(filter(run.people,f)):null);return {id:run.id,photo:run.photo,profile:H.profile(run),...(m||{identified:null,covered:null,coverageRate:null,errorRate:null,fail:null,issues:null}),unavailable:!m};});
 }
 function movementRows(current,previous,f={}){
   if(!previous)return [];
   const available=new Set(previous.result.evaluatedRules||previous.result.selection),a=filter(H.people(current),{...f,rule:''}),b=filter(H.people(previous),{...f,rule:''}),allA=new Map(H.people(current).map(p=>[p.matricula,p])),allB=new Map(H.people(previous).map(p=>[p.matricula,p])),map=new Map(),idsA=new Set(a.map(p=>p.matricula)),idsB=new Set(b.map(p=>p.matricula));
   function add(ps,side){for(const p of ps)for(const i of findings(p,true)){if(i.severity!=='Erro'||!available.has(i.rule)||f.rule&&i.rule!==f.rule)continue;const key=p.matricula+'|'+i.rule;if(!map.has(key))map.set(key,{matricula:p.matricula,master:master(p),nome:p.nome,rule:i.rule,label:M.rules.find(r=>r.id===i.rule)?.label||i.ruleLabel,before:[],after:[]});map.get(key)[side].push(i);}}
   add(b,'before');add(a,'after');
   return [...map.values()].map(row=>{
     const changes=previous.migrationNote||current.migrationNote?{entered:null,exited:null,retained:null}:flow(row.before,row.after),prior=row.before.length,now=row.after.length,oldKeys=row.before.map(i=>i.key).sort(),newKeys=row.after.map(i=>i.key).sort(),delta=now-prior;
     let movement=delta>0?'aumento':delta<0?'reducao':oldKeys.join('\n')!==newKeys.join('\n')?'alteracao':'persistente';
     let reason=delta>0?(!allB.has(row.matricula)?'Ingresso no público avaliado':!idsB.has(row.matricula)?'Alteração de enquadramento no recorte':'Acréscimo de ocorrências da regra'):delta<0?(!allA.has(row.matricula)?'Saída do público avaliado':!idsA.has(row.matricula)?'Alteração de enquadramento no recorte':'Redução de ocorrências da regra'):movement==='alteracao'?'Alteração das evidências, sem variação de quantidade':'Ocorrências mantidas';
     return {...row,...changes,previous:prior,current:now,delta,movement,reason,previousEvidence:row.before.map(i=>i.evidence).join('\n'),currentEvidence:row.after.map(i=>i.evidence).join('\n'),previousKeys:oldKeys.join('\n'),currentKeys:newKeys.join('\n')};
   }).sort((a,b)=>b.delta-a.delta||a.matricula.localeCompare(b.matricula,'pt-BR'));
 }
 function leaders(ps,type,limit=5){return ps.filter(p=>R.assessable(p)&&p.counts[type]>0).sort((a,b)=>b.counts[type]-a.counts[type]||a.nome.localeCompare(b.nome,'pt-BR')).slice(0,limit);}
 function changes(current,previous,f){if(!previous)return null;const rows=movementRows(current,previous,f);return {newErrors:rows.filter(r=>r.movement==='aumento').length,resolved:rows.filter(r=>r.movement==='reducao').length,persisting:rows.filter(r=>r.movement==='persistente').length};}
 return {master,dimensions,filter,metrics,facets,segments,demographics,ageRanges,flow,findings,counts,risks,ruleRows,compare,series,movementRows,leaders,changes};
});

