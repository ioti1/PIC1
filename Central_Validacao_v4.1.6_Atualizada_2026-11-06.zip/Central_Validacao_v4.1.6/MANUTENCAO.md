# Manutenção · Central de Validação 4.1.6

## Filtro etário e remoção do resumo mensal · 06/11/2026

A tela executiva não renderiza mais timeline-panel/Comparativo mensal. render() também deixa de calcular a série histórica que esse bloco usava; comparison() mantém a série sob demanda para o PDF. As regras e o formato do histórico não mudaram.

model.demographicRanges/demographicAge/demographicBand centralizam os intervalos e o tratamento de idades divergentes, ausentes ou inválidas. participantMatch aceita os novos intervalos e preserva comparação direta com classificações antigas quando recebidas por integrações anteriores. Seletor e gráfico utilizam os mesmos intervalos. As classificações ageBand já salvas não são reescritas silenciosamente.

history.measure retorna null quando há filtro etário, porque os cubos antigos não conservam o detalhe numérico necessário para recalcular os novos intervalos. A consulta usa os registros mínimos dos períodos envolvidos; a série do PDF continua expandindo os demais meses sequencialmente, sem manter todas as bases na memória.

O gráfico omite a linha etária não disponível, mas não altera o universo. Mostra nota se houver pessoas sem idade válida. Durante a seleção, o gráfico usa todos os outros filtros e exclui apenas seu próprio ageBand para permitir trocar a faixa; isso fica explícito na legenda de escopo. As linhas são botões com aria-pressed, foco visível, título e clique alternável; faixas vazias no recorte são desabilitadas.

Regressão: node tools/central-v41-qa/executive-v416.cjs. Verifica remoção do bloco mensal, nove faixas, retenção de idade ausente no total geral, limites 0/18/19/29/30/39, seleção/limpeza, sincronismo do seletor, recorte dos dois meses, Excel e fila de tratamento. As premissas visuais de testes históricos v415 com dez linhas etárias e resumo mensal foram substituídas por esta revisão. Homologação visual no navegador permanece pendente.

## Perfil horizontal e lista recolhível · 06/11/2026

exec-age-comparison-grid dispõe perfil etário à esquerda e comparativo à direita, em proporção 1:2. Empilha a 1.280 px, mantendo a ordem. demographicChart usa barras horizontais com escala comum entre faixas/sexos, contagens exatas e mesmas categorias; não altera demographics nem o histórico. O quadro de valores continua disponível.

peopleExpanded inicia false e controla execPeopleBody. Expandir/Recolher atua no DOM sem renderizar novamente a paginação nem alterar filtros. Nas atualizações normais, people() respeita o estado de expansão existente. Ações de exportação e fila permanecem fora do corpo recolhível.

Regressão: node tools/central-v41-qa/executive-v415.cjs. Verifica posição/proporção, dez faixas horizontais, séries M/F, estado recolhido inicial e página 2 de 4 preservada após alternar e atualizar. Cálculos, validação, PDF e persistência permanecem inalterados. Homologação visual no navegador corporativo continua pendente.

## Ordem e tabela executivas · 06/11/2026

Escopo restrito a apresentação do executivo: exec-segment-grid dispõe Plano → Patrocinadora → Subsituação, todos via horizontal e escala comum. Abaixo de 1.100 px, empilha mantendo a ordem. Ocorrências por código não é mais renderizado no executivo. execDemographics passa a ser criado dentro de execEvolution, imediatamente antes de changes-panel, sem duplicação de ID.

O alinhamento numérico do rodapé usa tfoot th:not([colspan]), pois nth-child não representa a posição visual após a célula de título com colspan=2. O estilo de linhas alternadas usa tokens específicos para branco/bege e equivalentes no modo escuro. Nenhuma fórmula, regra, persistência, nomenclatura ou gerador PDF foi alterado.

Regressão: node tools/central-v41-qa/executive-v414.cjs. Verifica ordem dos três gráficos, barra horizontal de patrocinadora, remoção do gráfico redundante, posição etária, totais anteriores/atuais, sete colunas lógicas do rodapé e regras de alternância/alinhamento. Homologação visual no navegador permanece pendente.

## Perfil e movimentação · 05/11/2026

Model: campo opcional sexo acrescentado após os vinte campos originais, sem fallback posicional. Aliases reconhecem Sexo; valores M/F são explícitos. Os históricos versão 3 permanecem compatíveis: a ausência de sexo é desconhecida, nunca inferida. project/binding guardam o mínimo necessário; a deduplicação inclui sexo e idade para preservar conflitos. Motor e semântica das regras não foram alterados.

executive-data.ruleRows calcula Entradas/Saídas por multiconjunto de matrícula + chave de negócio de cada achado. Quantidades idênticas são retidas pelo mínimo entre meses; novas e ausentes se reconciliam com a diferença líquida. movementRows expõe ambos os fluxos, inclusive quando o saldo é zero. Históricos legados sem evidências detalhadas não sustentam fluxos brutos. Nunca rotular uma saída como correção confirmada sem prova na origem.

demographics reutiliza o público filtrado e as idades da fotografia; conta uma pessoa uma vez. Sexo divergente entre vínculos é separado. Idades diferentes entre vínculos, ausentes ou fora do intervalo aceito pelo motor ficam Não disponível. Patrocinadora respeita os vínculos do recorte e pode se sobrepor entre categorias.

Regressão: node tools/central-v41-qa/executive-v413.cjs. Inclui o caso 1.901 → 1.907 com 16 entradas e 10 saídas, substituição de chave com saldo zero, multiplicidade, limites etários, sexo M/F e persistência, compatibilidade com vinte colunas, expansão/retração e limpeza dos filtros. Saídas PDF sintéticas foram renderizadas e inspecionadas; o HTML ainda requer homologação visual no navegador corporativo.

## Revisão de apresentação · 04/11/2026

O executivo utiliza duas colunas iguais, áreas de plotagem padronizadas, rótulos de barras posicionados sem interferir na escala e uma única escala para os gráficos horizontais relacionados. O comparativo E1–E10 ocupa a largura disponível, com eixo log1p identificado e marcas de zero, um e potências de dez. Contagens exibidas permanecem absolutas. Dois meses comparáveis geram um comparativo compacto; três ou mais preservam a série temporal com lacunas e critérios respeitados.

utils.js concentra shortPlan (seis aliases de apresentação), coveragePercent (precisão adaptativa para não arredondar frações para zero ou cem) e changeStats (variação percentual indisponível quando não há base anterior positiva). Não usar aliases como chave de vínculo nem alterar nomes originais nos arquivos de evidência. Motor e formato de histórico permanecem inalterados.

PDF: comparação compacta com percentuais para dois meses; arco contínuo sem extremidades arredondadas que encubram intervalos; percentual de cobertura preciso e quantidade/percentual sem canal explícitos. Os PDFs sintéticos de revisão foram renderizados e inspecionados. A interface HTML não foi homologada visualmente no navegador: testes de contrato, conteúdo, escala, fontes e filtros não substituem essa etapa. O portal público Petros retornou HTTP 403 à consulta; não foi possível inspecionar diretamente o painel Nossos Participantes. A identidade existente do HUB foi preservada.

Regressões complementares: node tools/central-v41-qa/executive-v412.cjs e node tools/central-v41-qa/pdf-layout-v412.cjs. As saídas usam exclusivamente dados sintéticos e ficam fora da distribuição.

## Correção de leitura XLSX · 04/11/2026

O leitor prioriza arrayBuffer quando disponível, inclusive em fontes de bytes já lidos. FileReader é utilizado somente na compatibilidade com Blob nativo sem esse método; objetos comuns não são enviados a readAsArrayBuffer. Isso mantém uma única leitura do arquivo de origem para hash e interpretação. Motor 3.2.0 e formato do histórico 3 não foram alterados.

Regressão: node tools/central-v41-qa/xlsx-browser-regression.cjs. O teste usa a restrição de tipo Blob do FileReader, reproduz o erro anterior e verifica baixar histórico/iniciar nova fotografia, reabrir histórico/carregar o mês seguinte, comparação dos meses e compatibilidade de Blob legado. É uma simulação de contrato de API, não homologação em navegador real.

## Fonte vigente

A pasta Entregas/Central_Validacao_v4.1 é a referência desta entrega para as próximas manutenções. A integração existente em Entregas/PIC_Entrega_v3/HUB/apps/Central_Validacao também recebeu a revisão de código; suas pastas antigas não integram o novo pacote. Não retomar as versões antigas da pasta New project. O RAR original e os pacotes anteriores não foram alterados.

Backup anterior à otimização: Entregas/Central_Validacao_Antes_Otimizacao_v41_2026-11-03.zip.

## Arquitetura

- model.js e reconcile.js: motor 3.2.0, regras estáveis e exclusão centralizada por assessable.
- app.js: ingestão, assistentes, avaliação, projeção das regras e fila de tratamento.
- history-store.js: PIC-HISTORICO versão 3, política publico-sem-obito-v1, fatos mínimos e cubo agregado.
- history-persistence.js: cache IndexedDB, leitura sequencial e gravação com verificação de alteração externa.
- executive-data.js: filtros, métricas e variações por chave de negócio.
- executive.js: coordenação do histórico, carregamento sob demanda e painel executivo.
- report-pdf.js: PDF com síntese executiva após a capa e detalhes posteriores.
- batch-export.js, consolidated.js e xlsx-writer.js: lotes, evidências e exportação.
- styles/operations.css: folhas operacionais consolidadas em sua ordem original.
- styles/executive.css: portal, executivo e progresso, com pontos de adaptação para telas menores.

Os componentes antigos de integração externa de painéis foram retirados desta entrega. Não adicionar dependências remotas, CDN, publicação ou telemetria.

## Contratos obrigatórios

1. Excluir integralmente participantes com qualquer data de óbito informada em qualquer vínculo, antes de analisar contatos e compartilhamento.
2. Manter o disclaimer de morte presumida e I-Petros. Não inferir a origem I-Petros a partir de plano sem definição de negócio.
3. Preservar matrícula original como texto nas evidências; a chave de conciliação pode ser normalizada.
4. Aplicar plano, patrocinadora e situação ao mesmo vínculo; não criar combinações artificiais entre vínculos distintos.
5. Separar contagem de ocorrências, contatos e participantes distintos. Somatórios por vínculo podem se sobrepor.
6. Comparar automaticamente apenas com o mês calendário anterior e critérios compatíveis.
7. Não manter livros, endereços ou valores de contatos sem achados no histórico. Manter apenas evidências necessárias.
8. Guardar somente uma execução vigente por mês e classificação; preservar arquivos anteriores fora do histórico para versionamento.
9. Atualizar seleção de regras a partir dos resultados já calculados; não exigir as fontes corporativas para a consulta histórica.
10. Não afirmar correção cadastral apenas por tratamento manual, mudança de perfil ou saída do público.
11. Exportações do recorte devem contemplar todas as linhas, não apenas a página visível.
12. Não executar arquivos de dados como scripts. Validar formato, integridade e limites de entrada.
13. Não prometer leitura automática irrestrita de pastas ou ausência de autenticação no SharePoint.
14. Preservar herança da fotografia oficial no assistente de contatos e mapeamento somente leitura nas fontes históricas.

## Histórico e memória

Os meses ficam comprimidos em blocos de 1.000 pessoas, com compressão leve. A abertura mantém metadados/cubos e bytes comprimidos; detalhes são expandidos sob demanda. Fora do par selecionado, meses carregados para filtros individuais são liberados após o cálculo.

Após a avaliação, o grafo das fontes completas é substituído pelos fatos mínimos. A próxima execução libera o grafo anterior antes da ingestão. Ao salvar, o cache conserva dados comprimidos e remove registros antigos que não integram o catálogo ativo.

Históricos versão 2 são convertidos pelos fatos já disponíveis. O payload corporativo legado não é expandido. Detalhes ausentes ficam explicitamente indisponíveis; compartilhamento antigo não é reinterpretado. Grave a migração em uma nova cópia antes da substituição.

Alterações futuras de regra/política exigem versão e decisão explícita de migração. Não reinterpretar silenciosamente históricos.

## Verificação

Os testes e saídas sintéticas ficam fora da distribuição, em tools/central-v41-qa e tmp/central-v41-qa na raiz do projeto. Os testes antigos preservados em legacy-tests documentam contratos anteriores; alguns pressupostos foram substituídos intencionalmente.

Comandos principais na raiz:
- node tools/central-v41-qa/verify.cjs
- node tools/central-v41-qa/migration.cjs
- node --expose-gc --max-old-space-size=768 tools/central-v41-qa/volume.cjs

A suíte funcional verifica exclusão de óbitos, retenção mínima, regras, metadados do Excel, herança da fotografia, retomada, diferenças por matrícula e geração do PDF. A suíte de migração verifica conversão sem expandir as evidências corporativas antigas. O teste de volume utiliza dois meses com 50.001 pessoas e 150.003 contatos por mês, em Node.js, não no navegador.

PDF e abas de Excel sintéticos foram renderizados para revisão visual. Não distribuir essas amostras como resultados oficiais.

A política de navegação impediu homologação do HTML nesta sessão. Testes de integração usam uma representação lógica do DOM; não equivalem a teste visual, de permissões nativas ou de sincronização SharePoint. Essa limitação deve acompanhar a entrega até homologação no ambiente de destino.
