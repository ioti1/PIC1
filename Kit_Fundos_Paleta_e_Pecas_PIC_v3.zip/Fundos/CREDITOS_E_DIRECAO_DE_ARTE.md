# Imagens do programa
Imagens ilustrativas produzidas com o gerador de imagens integrado da OpenAI para esta entrega. Não retratam participantes, empregados, sistemas ou resultados reais da Petros.

Novas imagens e direções utilizadas:
- analise-equipe.png: profissionais brasileiros maduros analisando documentos e gráficos ao lado de um notebook; escritório acolhedor, luz natural, Cyprus e Sand, composição editorial com área de respiro.
- reuniao-dados.png: equipe diversa discutindo gráficos abstratos em uma tela, reunião profissional, tons institucionais e luz natural.
- dados.png: módulos translúcidos organizados em camadas, representação conceitual de estrutura e qualidade dos dados, fundo Cyprus e reflexos Sand.
- ia.png: rede de nós claros conectados sobre camadas de dados, inteligência artificial como conexão e análise; sem robô, cérebro ou texto.
- tecnologia.png: equipamentos e conectores de uma infraestrutura de dados, fotografia editorial em Cyprus e Sand, composição com espaço para títulos.

Outros fundos preservados do projeto: hero-cuidado, analise, colaboracao e fundo-editorial. As imagens são recursos de apoio; o logotipo oficial é produzido por curvas vetoriais, sem geração raster.
