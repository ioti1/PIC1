# PIC · Central de Validação de Comunicação · 4.1.2

Revisão visual de 04/11/2026: gráficos executivos alinhados, siglas dos seis planos, comparação compacta para dois meses com variação absoluta e percentual, E1–E10 em escala logarítmica log(1 + quantidade), cobertura com precisão adaptativa e PDF revisado. A pesquisa por matrícula/nome permanece no topo ao abrir filtros adicionais. Os três blocos de relatórios ficam lado a lado em telas amplas e empilhados em telas menores.

A escala logarítmica altera somente a altura das barras: os valores, filtros e exportações mantêm as contagens originais. Zero permanece sem barra. Percentuais não são calculados quando a base anterior é zero e o valor atual é positivo. As siglas são de apresentação; nomes originais e chaves continuam preservados no histórico e no Excel.

Correção de 04/11/2026: compatibilidade do carregamento XLSX com os objetos de bytes reutilizados na leitura. O ajuste permite adicionar uma nova fotografia após baixar ou reabrir o histórico, sem exigir recriação do arquivo central. Feche a aba da versão anterior e abra o index.html desta revisão.

Aplicação HTML local para validação dos meios de comunicação, tratamento das pendências e acompanhamento executivo mensal. Abra index.html mantendo as pastas assets, src, styles e vendor ao lado dele. Não é necessário instalar servidor nem manter conexão com a internet.

## Público e escopo

O público oficial é a referência do estudo. Contatos de pessoas não identificadas nesse público não integram os indicadores. Qualquer data de óbito informada em qualquer vínculo exclui o participante inteiro, seus contatos e seus apontamentos, inclusive das evidências e comparações. Datas de óbito futuras ou sem formato reconhecível também são consideradas informadas e excluem o registro; a aplicação não confirma o evento.

Conforme a definição da área, os óbitos informados na base são tratados como morte presumida. Os relatórios apresentam:

“Este estudo não contempla participantes e pensionistas com morte presumida, nem a base corporativa do I-Petros.”

A exclusão da base I-Petros é uma delimitação da origem do estudo: a ferramenta não identifica automaticamente essa origem em qualquer arquivo. Cabe ao responsável selecionar as bases autorizadas.

## Primeira execução

1. Abra index.html e selecione a visão operacional.
2. Carregue uma ou mais bases oficiais em XLSX, CSV ou TXT. As fontes são concatenadas antes da avaliação.
3. Revise o mapeamento das colunas no assistente e informe a fotografia do estudo. Para reprocessar um mês anterior, utilize a data correspondente àquela fotografia.
4. Processe o público oficial. Os contatos herdarão essa data; o assistente de contatos não a solicita novamente.
5. Carregue as bases de comunicação, confira o mapeamento e confirme o carregamento.
6. Selecione as regras e execute a validação.
7. Consulte o universo, a fila de tratamento e a visão executiva. Os filtros limitam os indicadores e as exportações correspondentes.
8. Em Histórico, use Salvar como para gerar seu arquivo central de dados. Mantenha uma cópia de segurança antes de substituí-lo.

Carregar outra base oficial depois de uma avaliação inicia uma nova execução, preserva o mês concluído no histórico e libera a origem anterior da memória. Para adicionar contatos à mesma avaliação, carregue todas as fontes antes de processar.

## Histórico mensal

O arquivo central é um arquivo de dados, não um programa JavaScript. A visão executiva e a operacional utilizam esse mesmo histórico. No próximo mês, abra o arquivo central, processe a nova fotografia e salve a atualização.

O histórico mantém uma execução vigente por mês e classificação. Reprocessar o mesmo mês substitui sua execução vigente no histórico em uso. Isso não altera os arquivos originais; preserve suas cópias anteriores quando precisar de rastreabilidade de versões.

A comparação automática usa o mês calendário imediatamente anterior. Se não houver esse mês, os relatórios apresentam somente o período vigente, sem substituir por um mês mais antigo. A série pode apresentar outros meses existentes, com lacunas identificáveis. Critérios e versões não comparáveis são sinalizados.

As variações por código permitem consultar matrícula, quantidades anteriores e atuais, motivo e evidências. A saída do público não comprova correção cadastral. Totais de ocorrências não equivalem a participantes distintos.

## O que fica salvo

São preservados identidade, perfil necessário aos filtros, datas relevantes, contagens dos canais, resultados das regras, evidências dos contatos com apontamentos e marcações de tratamento. Não ficam guardadas as planilhas corporativas completas, endereços, colunas não mapeadas ou valores de contatos sem apontamentos.

O histórico não substitui as bases originais. Uma fotografia retomada permite consultar evidências e alterar a seleção das regras já avaliadas, mas não refazer o mapeamento nem recuperar valores de contatos sem apontamentos. Para isso, processe novamente as fontes originais.

A abertura lê primeiro os índices e os dados compactados. Os detalhes dos meses são carregados sob demanda. O processamento inicial de XLSX ainda precisa de memória proporcional ao tamanho das fontes.

## Visão executiva

Os filtros aparecem próximos ao cabeçalho. Indicadores, canais, planos, situações contratuais, evolução, comparativo dos códigos, destaques do cadastro e consulta individual formam uma página contínua. Selecione barras e indicadores para restringir o recorte.

A investigação mensal detalha acréscimos, reduções, manutenção de ocorrências e alteração das evidências. O Excel de investigação contempla todas as linhas do recorte, não apenas a página exibida. Os destaques de e-mail e celular contam registros cadastrados, não endereços ou números necessariamente distintos.

## Relatórios e Excel

O PDF tem capa, síntese executiva na página seguinte, gráficos e quadros detalhados. A comparação com o mês anterior aparece somente quando houver período comparável. O rodapé utiliza Núcleo Analytics - Setor de Cadastro e paginação.

O lote completo gera HTML sintético e um único Excel com abas por código. As abas apresentam identificação do erro, fotografia, geração, escopo, cabeçalho fixo, altura uniforme e campos de perfil. O lote completo considera todas as regras disponíveis, independentemente da seleção da fila.

O Excel do recorte utiliza os filtros aplicados e todas as linhas encontradas. A ausência de data de óbito nas evidências decorre da exclusão desses participantes do estudo; a coluna pode ser mantida por compatibilidade de layout.

## Migração do histórico anterior

Abra seu arquivo de histórico anterior. A conversão remove os óbitos identificados e descarta os dados corporativos desnecessários. Em seguida, use Salvar como e gere um novo arquivo. Confira os totais antes de substituir sua cópia de referência.

Históricos antigos podem não conter nascimento e evidências individuais no índice disponível. Esses detalhes são sinalizados como indisponíveis, não inventados. Alertas de compartilhamento antigos não são revalidados sem as fontes originais; comparações que dependam deles ou de critérios não recuperáveis ficam indisponíveis. Reprocesse as fontes originais quando precisar desses detalhes na nova estrutura.

## Arquivo local e SharePoint

Você pode manter o arquivo central em uma pasta sincronizada do SharePoint/OneDrive. Abra o HTML e os dados disponíveis localmente; a aplicação não realiza autenticação no SharePoint nem elimina as exigências de acesso da organização.

O navegador pode lembrar o vínculo autorizado com um arquivo, mas permissões podem precisar de nova confirmação. Não há leitura irrestrita automática de diretórios. Em navegadores sem gravação direta, utilize o download e substitua o arquivo de forma controlada.

Utilize um responsável por vez para salvar o arquivo central. A ferramenta detecta alteração do arquivo desde sua abertura antes da gravação direta, mas não é um banco de dados multiusuário e não garante resolver conflitos de sincronização simultânea.

O cache do navegador é uma conveniência, não uma cópia de segurança. Não limpe os dados do navegador antes de salvar o arquivo.

## Proteção e limites

As dependências estão incluídas na pasta; não há CDN, telemetria nem envio de bases pela aplicação. A política de conteúdo bloqueia conexões externas. O arquivo central não possui criptografia própria, autenticação de usuários ou trilha de autoria assinada. Restrinja o acesso pela infraestrutura corporativa e proteja os dispositivos e as cópias.

Marcar uma pendência como tratada organiza a fila; não altera os dados de origem nem comprova correção no cadastro. Preserve as bases originais e os controles de auditoria da área.

## Verificações desta versão

Foram testados dados sintéticos, migração do histórico, exportações, comparação por matrícula e dois meses com 50.001 pessoas e 150.003 contatos por mês em Node.js. PDF e Excel gerados foram inspecionados visualmente. Isso não equivale à homologação de volume no navegador real.

A política de navegação da sessão impediu a abertura do HTML para homologação. Layout no navegador, permissões nativas e sincronização real do SharePoint devem ser conferidos no ambiente corporativo antes do uso regular.
