(function(){
 'use strict';
 const H=ComHistory,D=ComExecutiveData,P=ComHistoryPersistence,M=ComModel,R=ComReconcile,U=CVCUtils,X=ComConsolidated,W=ComExport,B=ComBatchExport;
 const $=s=>document.querySelector(s),esc=U.escapeHtml,n=U.formatNumber,pct=v=>v==null?'—':U.formatPercent(v),date=U.formatDate;
 const pause=()=>new Promise(resolve=>setTimeout(resolve,0));
 let db=H.fresh(),handle=null,expected='',selected='',priorId='',dirty=false,loading=false,cacheOK=false,origin='Nenhum histórico carregado',serial=Promise.resolve(),renderToken=0;
 let filters={},personPage=1,personSize=20,changesOpen=false,changeType='aumento',changeRule='',changePage=1,changeRows=[],pendingTreatment=null,treatmentTimer=null;
 const defs={group:'Situação contratual',subgroup:'Subsituação contratual',plan:'Plano',sponsor:'Patrocinadora',ageBand:'Faixa etária',status:'Qualidade cadastral',treatment:'Tratamento',coverage:'Validade dos canais',exclusion:'Disponibilidade de canais',rule:'Apontamento'};
 const current=()=>db.runs.find(r=>r.id===selected);
 const previous=()=>db.runs.find(r=>r.id===priorId)||null;
 const label=(key,v)=>key==='plan'?U.shortPlan(v):key==='rule'?M.rules.find(r=>r.id===v)?.label||v:Object.fromEntries(M.exclusions)[v]||v;
 function notify(s){$('#toast').textContent=s;$('#toast').hidden=false;clearTimeout(notify.timer);notify.timer=setTimeout(()=>$('#toast').hidden=true,8000);}
 function message(s){$('#historyMessage').textContent=s;$('#historyMessage').hidden=!s;}
 function progress(p){$('#historyWorkTitle').textContent=p.phase||'Atualizando histórico';$('#historyWorkDetail').textContent=p.detail||'Aguarde a conclusão da operação.';$('#historyWorkBar').value=p.percent||0;$('#historyWorkPercent').textContent=Math.round(p.percent||0)+'%';}
 async function work(title,fn){
   loading=true;controls();progress({phase:title,percent:1});if(!$('#historyWorkDialog').open)$('#historyWorkDialog').showModal();await pause();
   try{return await fn(progress);}finally{loading=false;$('#historyWorkDialog').close();controls();}
 }
 function choose(){
   const list=H.canonical(db);if(!db.runs.some(r=>r.id===selected))selected=list.at(-1)?.id||'';
   if(!db.runs.some(r=>r.id===priorId)||priorId===selected)priorId=current()?H.previous(db,current())?.id||'':'';
 }
 function controls(){
   choose();const sorted=[...db.runs].sort((a,b)=>b.photo.localeCompare(a.photo)),refs=new Set(H.canonical(db).map(r=>r.id));
   for(const [id,value,placeholder]of [['execPhoto',selected,'Selecione a fotografia'],['execPrevious',priorId,'Sem período anterior']]){
     $('#'+id).innerHTML='<option value="">'+placeholder+'</option>'+sorted.filter(r=>id!=='execPrevious'||r.photo<current()?.photo&&r.classification===current()?.classification).map(r=>'<option value="'+esc(r.id)+'">'+date(r.photo)+(r.classification==='demonstration'?' · demonstração':'')+'</option>').join('');$('#'+id).value=value;
   }
   const last=H.canonical(db).at(-1);$('#portalMonths').textContent=n(refs.size);$('#portalRuns').textContent=n(db.runs.length);$('#portalPhoto').textContent=last?date(last.photo):'Aguardando processamento';$('#portalBase').textContent=origin;
   $('#historyOrigin').textContent=origin;$('#historyStatus').textContent=n(db.runs.length)+' competências registradas';$('#historyDirty').textContent=dirty?'Existem alterações locais ainda não gravadas no arquivo.':'O arquivo não possui alterações locais pendentes.';
   $('#historyCache').textContent=cacheOK?'Cópia local reduzida disponível neste navegador.':'Utilize o arquivo de histórico para preservar os resultados.';$('#openHistory').textContent=dirty?'Histórico · salvar alterações':'Histórico & base';
   for(const id of ['historySave','historySaveAs','historyDownload'])$('#'+id).disabled=loading||!db.runs.length;for(const id of ['historyOpen','historyManualOpen'])$('#'+id).disabled=loading;
   $('#historyCapture').disabled=loading||!ComApp.state.result;$('#historyReconnect').hidden=!handle;
   $('#historyTable').innerHTML='<table><thead><tr><th>Fotografia</th><th>Público avaliado</th><th>Processamento</th><th></th></tr></thead><tbody>'+sorted.map(r=>'<tr><td><b>'+date(r.photo)+'</b></td><td>'+n(r.personCount)+'</td><td>'+esc(new Date(r.result.processedAt).toLocaleString('pt-BR'))+(r.migrationNote?'<small>Histórico convertido para o formato reduzido</small>':'')+'</td><td><button class="quiet" data-history-run="'+esc(r.id)+'">Consultar</button></td></tr>').join('')+'</tbody></table>';
 }
 async function persist(run=null){try{await P.saveDatabase(db,run);cacheOK=true;}catch(e){cacheOK=false;notify('Não foi possível atualizar a cópia local. Salve o arquivo de histórico. '+e.message);}controls();}
 function captureNow(state,onProgress){
   const snapshot=H.capture(state),old=db.runs.find(r=>r.id===snapshot.id);if(old&&snapshot.savedAt<=old.savedAt)snapshot.savedAt=new Date(Date.parse(old.savedAt)+1).toISOString();
   serial=serial.catch(()=>{}).then(async()=>{await H.pack(snapshot,JSZip,onProgress);H.put(db,snapshot);dirty=true;selected=snapshot.id;priorId=H.previous(db,snapshot)?.id||'';await persist(snapshot);H.evict(db,[selected,priorId]);if($('#page-executive').classList.contains('active'))await render();}).catch(e=>{notify('Não foi possível registrar a fotografia. '+e.message);throw e;});
   return serial;
 }
 function capture(reason='manual',onProgress){
   if(!ComApp.state.result)return serial;
   if(reason==='treatment'){pendingTreatment=ComApp.state;clearTimeout(treatmentTimer);treatmentTimer=setTimeout(()=>{const state=pendingTreatment;pendingTreatment=null;captureNow(state).catch(()=>{});},400);dirty=true;controls();return serial;}
   return captureNow(ComApp.state,onProgress);
 }
 async function flush(){if(pendingTreatment){clearTimeout(treatmentTimer);const state=pendingTreatment;pendingTreatment=null;await captureNow(state);}await serial;}
 function release(){H.evict(db,[]);changeRows=[];renderToken++;}
 async function ensurePair(onProgress){
   choose();if(!current())return;await H.expand(current(),JSZip,onProgress);if(previous())await H.expand(previous(),JSZip,onProgress);H.evict(db,[selected,priorId]);
 }
 async function accept(file,h=null,onProgress){
   await flush();const incoming=await H.decode(file,JSZip,onProgress),hasLocal=db.runs.some(r=>!incoming.runs.some(v=>v.id===r.id&&v.savedAt===r.savedAt));
   db=H.merge(incoming,db);dirty=hasLocal||!!incoming.migrated;handle=h;expected=h?await P.signature(file):'';origin=h?'Arquivo vinculado: '+file.name:'Arquivo aberto: '+file.name;
   selected='';priorId='';filters={};choose();await P.write('handle',handle).catch(()=>{});await persist();
   if(ComApp.state.result){const r=db.runs.find(r=>r.id===ComApp.state.result.runId);if(r){await H.expand(r,JSZip,onProgress);ComApp.restoreExecution(H.hydrate(r));}}
   message(incoming.migrated?'Histórico convertido para o formato reduzido, com exclusão dos registros com óbito. O arquivo anterior não foi alterado. Salve uma nova cópia para preservar a conversão.':'Histórico carregado. Os resultados estão disponíveis sem novo processamento.');await render();
 }
 async function chooseFile(){
   if(loading)return;try{if(window.showOpenFilePicker){const [h]=await window.showOpenFilePicker({multiple:false,types:[{description:'Histórico cadastral PIC',accept:{'application/zip':['.pic']}}]});const file=await h.getFile();await work('Carregando histórico',p=>accept(file,h,p));}else $('#historyInput').click();}catch(e){if(e.name!=='AbortError')message('Não foi possível abrir o arquivo. '+e.message);}
 }
 async function reconnect(){if(!handle||loading)return;try{if(!await P.permission(handle,false,true))throw Error('Autorize a leitura ou selecione o arquivo novamente.');const file=await handle.getFile();await work('Conferindo arquivo vinculado',p=>accept(file,handle,p));}catch(e){message(e.message);}}
 async function save(asNew=false){
   if(loading||!db.runs.length)return;let target=handle;
   try{
     if(asNew||!target)target=window.showSaveFilePicker?await window.showSaveFilePicker({suggestedName:'PIC_Historico.pic',types:[{description:'Histórico cadastral PIC',accept:{'application/zip':['.pic']}}]}):null;
     if(target&&!await P.permission(target,true,true))throw Error('A gravação não foi autorizada. Utilize Baixar uma cópia.');
     await work('Salvando histórico',async p=>{
       await flush();const update=Date.now(),payload={...db,revision:db.revision+1,updatedAt:new Date().toISOString()},blob=await H.encode(payload,JSZip,p);
       if(target){
         const file=await target.getFile();if(target!==handle&&file.size){const other=await H.decode(file,JSZip);if(other.id!==db.id||other.revision>db.revision)throw Error('O destino possui outro histórico ou uma versão mais recente. Abra o arquivo antes de salvar.');}
         p({percent:99,phase:'Gravando arquivo de histórico',detail:'Aguarde a confirmação da gravação.'});expected=await P.commit(target,blob,target===handle?expected:await P.signature(file));handle=target;db.revision=payload.revision;origin='Arquivo vinculado: '+target.name;dirty=db.runs.some(r=>Date.parse(r.savedAt)>update);await P.write('handle',handle).catch(()=>{});await persist();message('Arquivo salvo. Aguarde a conclusão da sincronização do OneDrive antes de encerrar o computador.');
       }else{U.downloadBlob(blob,'PIC_Historico.pic');message('Download solicitado. Mantenha o arquivo na pasta corporativa com acesso restrito.');}
       p({percent:100,phase:'Histórico concluído',detail:'Os resultados foram preservados no arquivo.'});await pause();
     });
   }catch(e){if(e.name!=='AbortError')message(e.message);}
 }
 async function download(){if(loading||!db.runs.length)return;try{await work('Preparando cópia do histórico',async p=>{await flush();U.downloadBlob(await H.encode(db,JSZip,p),'PIC_Historico.pic');message('Cópia preparada. O arquivo contém dados pessoais e deve permanecer em pasta restrita.');});}catch(e){message(e.message);}}
 function openHistory(){controls();$('#historyDialog').showModal();}
 async function activate(){
   await flush();await ensurePair();if(!current())throw Error('Selecione uma fotografia para consulta.');
   if(ComApp.state.result?.runId!==current().id)ComApp.restoreExecution(H.hydrate(current()));return ComApp.state;
 }
 function sourceRows(){return current()?.people||[];}
 function scope(){return D.filter(sourceRows(),filters);}
 function facets(changed){
   const ps=sourceRows();
   if(changed&&filters[changed])for(const key of Object.keys(defs))if(key!==changed&&filters[key]&&!D.filter(ps,{[key]:filters[key],[changed]:filters[changed]}).length)delete filters[key];
   for(const key of Object.keys(defs)){const values=D.facets(ps,filters,key),el=$('#exec-'+key);if(filters[key]&&!values.includes(filters[key]))delete filters[key];el.innerHTML='<option value="">Todos</option>'+values.map(v=>'<option value="'+esc(v)+'" title="'+esc(v)+'">'+esc(label(key,v))+'</option>').join('');el.value=filters[key]||'';el.title=key==='plan'?(filters[key]||'Todos os planos'):'';el.disabled=!values.length;}$('#execCuriosity').value=filters.curiosity||'';
 }
 function kpi(title,value,note,action=''){return '<'+(action?'button':'article')+' class="exec-metric" '+action+'><span>'+esc(title)+'</span><strong>'+esc(typeof value==='number'?n(value):value)+'</strong><small>'+esc(note)+'</small></'+(action?'button':'article')+'>';}
 function horizontal(groups,key,dimension,scaleMax){
   const max=scaleMax||Math.max(1,...groups.map(g=>g[key]));return groups.length?groups.map(g=>'<button class="exec-horizontal" data-dimension="'+dimension+'" data-value="'+esc(g.label)+'" title="'+esc(g.label)+': '+n(g[key])+' de '+n(g.identified)+' participantes"><span>'+esc(dimension==='plan'?U.shortPlan(g.label):g.label)+'</span><i aria-hidden="true"><b style="width:'+g[key]/max*100+'%"></b></i><strong>'+n(g[key])+'</strong></button>').join(''):'<p class="exec-chart-empty">Não há participantes neste recorte.</p>';
 }
 function verticalBar(value,max,prior=false,log=false){const height=Math.max(0,Math.min(100,(log?Math.log1p(value||0)/Math.log1p(max):(value||0)/max)*100));return '<div class="vertical-track" style="--bar-height:'+height+'%"><b>'+(value==null?'—':n(value))+'</b><i'+(prior?' class="prior-fill"':'')+' style="height:'+height+'%" aria-hidden="true"></i></div>';}
 function overview(ps){
   const m=D.metrics(ps),cmp=D.compare(current(),previous(),filters),delta=cmp.available?m.errorOccurrences-cmp.previous.errorOccurrences:null;
   const covered=m.covered,notCovered=m.identified-covered,angle=m.identified?covered/m.identified*360:0,channelMax=Math.max(1,m.identified);
   const planGroups=D.segments(ps,filters,'plan'),subgroups=D.segments(ps,filters,'subgroup'),segmentMax=Math.max(1,...planGroups.map(g=>g.fail),...subgroups.map(g=>g.fail)),segmentHeight=Math.min(6,Math.max(3,planGroups.length,subgroups.length))*44;
   $('#execOverview').innerHTML='<div class="exec-metrics">'+
     kpi('Público avaliado',m.identified,'Participantes sem registro de óbito','data-reset-quality="yes"')+
     kpi('Participantes com erro',m.fail,U.coveragePercent(m.fail,m.identified)+' do público avaliado','data-quality="Inconsistente"')+
     kpi('Ocorrências de erro',m.errorOccurrences,'Um participante pode ter várias ocorrências',previous()?'data-open-movements="aumento"':'data-quality="Inconsistente"')+
     kpi('Variação de ocorrências',delta==null?'—':(delta>0?'+':'')+n(delta),previous()?'Em relação a '+date(previous().photo):'Sem fotografia do mês anterior',previous()?'data-open-movements="aumento"':'')+
     '</div><div class="exec-grid" style="--segment-height:'+segmentHeight+'px">'+
     '<article class="card exec-panel coverage-panel"><div class="exec-panel-head"><h2>Cobertura de comunicação</h2><span>Participantes distintos</span></div><div class="coverage-layout"><div class="exec-ring" role="img" aria-label="'+n(covered)+' participantes com canal válido e '+n(notCovered)+' sem canal válido" style="--ring-angle:'+angle+'deg"><div><strong>'+U.coveragePercent(covered,m.identified)+'</strong><span>com canal válido</span></div></div><div class="ring-legend"><button data-coverage="Com canal válido"><i></i><span>Com canal válido</span><b>'+n(covered)+'</b></button><button data-coverage="Sem canal válido"><i class="neutral"></i><span>Sem canal válido</span><b>'+n(notCovered)+'</b></button></div></div><small class="exec-panel-footer">Validade estrutural, sem confirmação de entrega ou titularidade.</small></article>'+
     '<article class="card exec-panel channel-panel"><div class="exec-panel-head"><h2>Presença e validade dos canais</h2><span>Participantes distintos</span></div><div class="exec-chart-legend"><span>Cadastrado</span><span class="valid-key">Estrutura válida</span></div><div class="exec-vertical channels">'+Object.entries(M.types).map(([type,t])=>{const a=ps.filter(p=>p.counts[type]>0).length,b=ps.filter(p=>p.validCounts[type]>0).length;return '<div class="vertical-group" title="'+esc(t.label)+': '+n(a)+' com cadastro; '+n(b)+' com estrutura válida"><div class="vertical-bars">'+verticalBar(a,channelMax,true)+verticalBar(b,channelMax)+'</div><span>'+t.label+'</span></div>';}).join('')+'</div><div class="absence-chips exec-panel-footer">'+[['sem_email','Sem e-mail',m.withoutEmail],['sem_celular','Sem celular',m.withoutMobile],['sem_fixo','Sem telefone fixo',m.withoutPhone],['sem_todos','Sem canais cadastrados',m.withoutAny]].map(([id,label,v])=>'<button data-exclusion="'+id+'"><span>'+label+'</span><b>'+n(v)+'</b></button>').join('')+'</div></article>'+
     '<article class="card exec-panel plan-panel"><div class="exec-panel-head"><h2>Participantes com erro por plano</h2><span>Participantes distintos</span></div><div class="exec-scroll-bars">'+horizontal(planGroups,'fail','plan',segmentMax)+'</div><small class="exec-panel-footer">Pessoas com múltiplos vínculos podem integrar mais de um plano. As quantidades não são aditivas.</small></article>'+
     '<article class="card exec-panel subgroup-panel"><div class="exec-panel-head"><h2>Participantes com erro por subsituação</h2><span>Participantes distintos</span></div><div class="exec-scroll-bars">'+horizontal(subgroups,'fail','subgroup',segmentMax)+'</div><small class="exec-panel-footer">Os dois gráficos utilizam a mesma escala. Cada pessoa é contada uma vez por categoria.</small></article></div>';
 }
 function lineChart(data){
   const series=[{key:'errorOccurrences',label:'Ocorrências de erro',color:'var(--exec-primary)'},{key:'fail',label:'Participantes com erro',color:'var(--exec-secondary)'}],Wv=1000,Hv=260,L=65,T=30,Rv=40,Bv=42,max=Math.max(1,...data.flatMap(d=>series.map(s=>d[s.key]||0))),start=new Date(data[0].photo.slice(0,7)+'-01').getTime(),end=new Date(data.at(-1).photo.slice(0,7)+'-01').getTime();
   const xx=d=>L+(new Date(d.photo.slice(0,7)+'-01').getTime()-start)/Math.max(1,end-start)*(Wv-L-Rv),yy=v=>T+(1-v/max)*(Hv-T-Bv);
   let svg='<svg viewBox="0 0 '+Wv+' '+Hv+'" role="img" aria-label="Evolução mensal de ocorrências de erro e participantes com erro. Valores disponíveis na tabela de apoio." class="exec-line">';
   for(const f of [0,.5,1])svg+='<line x1="'+L+'" x2="'+(Wv-Rv)+'" y1="'+yy(max*f)+'" y2="'+yy(max*f)+'" class="chart-grid"/><text x="'+(L-10)+'" y="'+(yy(max*f)+4)+'" text-anchor="end">'+n(Math.round(max*f))+'</text>';
   for(const s of series)for(let i=0;i<data.length;i++){const d=data[i],v=d[s.key],a=data[i-1];if(v==null)continue;if(a&&a[s.key]!=null&&a.profile===d.profile){const da=new Date(a.photo.slice(0,7)+'-01'),dd=new Date(d.photo.slice(0,7)+'-01'),gap=dd.getUTCFullYear()*12+dd.getUTCMonth()-da.getUTCFullYear()*12-da.getUTCMonth();if(gap===1)svg+='<line x1="'+xx(a)+'" y1="'+yy(a[s.key])+'" x2="'+xx(d)+'" y2="'+yy(v)+'" stroke="'+s.color+'" stroke-width="2.5"'+(s.key==='fail'?' stroke-dasharray="6 4"':'')+'/>';}svg+='<circle cx="'+xx(d)+'" cy="'+yy(v)+'" r="4.5" fill="'+s.color+'"><title>'+date(d.photo)+' · '+s.label+': '+n(v)+'</title></circle>';if(s.key==='errorOccurrences'&&(data.length<=12||i%2===0||i===data.length-1))svg+='<text x="'+xx(d)+'" y="'+Math.max(13,yy(v)-10)+'" text-anchor="middle">'+n(v)+'</text>';}
   data.forEach((d,i)=>{if(data.length<=12||i%2===0||i===data.length-1)svg+='<text x="'+xx(d)+'" y="'+(Hv-13)+'" text-anchor="middle">'+d.photo.slice(5,7)+'/'+d.photo.slice(2,4)+'</text>';});
   return svg+'</svg>';
 }
 function codeChart(rows,codes,max){
   const domain=Math.pow(10,Math.ceil(Math.log10(Math.max(10,max)))),ticks=[0,1];for(let v=10;v<=domain;v*=10)ticks.push(v);
   const position=v=>Math.log1p(v)/Math.log1p(domain)*100;
   return '<div class="exec-code-plot"><div class="exec-log-chart" data-scale="log1p" data-scale-max="'+domain+'"><div class="exec-log-axis" aria-hidden="true">'+ticks.map(v=>'<span style="bottom:'+position(v)+'%">'+n(v)+'</span>').join('')+'</div><div class="exec-log-grid" aria-hidden="true">'+ticks.map(v=>'<i style="bottom:'+position(v)+'%"></i>').join('')+'</div><div class="exec-vertical errors">'+rows.map(r=>'<button class="vertical-group" data-rule="'+r.rule+'" title="'+esc(r.label)+' · atual: '+n(r.current)+(r.previous!=null?' · anterior: '+n(r.previous):'')+'"><div class="vertical-bars">'+(previous()?verticalBar(r.previous,domain,true,true):'')+verticalBar(r.current,domain,false,true)+'</div><span>'+codes.get(r.rule)+'</span></button>').join('')+'</div></div></div>';
 }
 function monthComparison(series){
   const before=series[0],now=series[1],metric=(key,title,unit)=>{
     const c=U.changeStats(now[key],before[key]),kind=c.delta<0?'decrease':c.delta>0?'increase':'unchanged',rate=c.rate==null?'Sem base percentual':(c.delta>0?'+':c.delta<0?'-':'')+(Math.abs(c.rate)*100).toLocaleString('pt-BR',{maximumFractionDigits:1,minimumFractionDigits:1})+'%',max=Math.max(1,before[key],now[key]);
     return '<article class="month-compare"><div class="month-compare-heading"><h3>'+title+'</h3><strong class="'+kind+'">'+rate+'</strong></div><div class="month-values"><div><small>'+date(before.photo)+'</small><b>'+n(before[key])+'</b></div><span aria-hidden="true">→</span><div><small>'+date(now.photo)+'</small><b>'+n(now[key])+'</b></div></div><div class="month-mini-bars" aria-hidden="true"><i style="width:'+before[key]/max*100+'%"></i><i style="width:'+now[key]/max*100+'%"></i></div><div class="month-change"><span class="'+kind+'">'+(c.delta<0?'Redução de ':c.delta>0?'Acréscimo de ':'Sem variação: ')+n(Math.abs(c.delta))+' '+unit+'</span>'+(key==='errorOccurrences'?'<button class="quiet" data-open-movements="'+(c.delta<0?'reducao':'aumento')+'">Investigar variação</button>':'')+'</div></article>';
   };
   return '<div class="two-month-grid">'+metric('errorOccurrences','Ocorrências de erro','ocorrências')+metric('fail','Participantes com erro','participantes')+'</div>';
 }
 function evolution(seriesOverride=null){
   const ruleData=D.ruleRows(current(),previous(),filters).filter(r=>r.severity==='Erro'),codes=new Map(B.catalog('Erro').map(r=>[r.id,r.code])),max=Math.max(1,...ruleData.flatMap(r=>[r.current,r.previous||0])),series=seriesOverride||D.series(db,filters,current());
   const compact=series.length===2&&series[0].photo===previous()?.photo&&D.compare(current(),previous(),filters).available&&series.every(d=>Number.isFinite(d.errorOccurrences)&&Number.isFinite(d.fail));
   let sum=0,old=0,complete=true;const table=ruleData.map(r=>{sum+=r.current;if(r.previous==null)complete=false;else old+=r.previous;return '<tr><td><b>'+codes.get(r.rule)+'</b></td><td>'+esc(r.label)+'</td>'+(previous()?'<td>'+ (r.previous==null?'—':n(r.previous))+'</td>':'')+'<td>'+n(r.current)+'</td>'+(previous()?'<td><button class="delta-link '+(r.delta>0?'increase':r.delta<0?'decrease':'')+'" data-movement-rule="'+r.rule+'" data-movement-type="'+(r.delta<0?'reducao':'aumento')+'">'+(r.delta==null?'—':(r.delta>0?'+':'')+n(r.delta))+'</button></td>':'')+'</tr>';}).join('');
   $('#execEvolution').innerHTML=(series.length>1?'<article class="card exec-panel timeline-panel"><div class="exec-panel-head"><h2>'+(compact?'Comparativo mensal':'Evolução dos apontamentos')+'</h2><span>Histórico até '+date(current().photo)+'</span></div>'+(compact?monthComparison(series):'<div class="line-legend"><span>Ocorrências de erro</span><span>Participantes com erro</span></div><div class="trend-scroll">'+lineChart(series)+'</div>')+'<details><summary>Consultar valores por competência</summary><table><thead><tr><th>Fotografia</th><th>Público</th><th>Participantes com erro</th><th>Ocorrências de erro</th></tr></thead><tbody>'+series.map(d=>'<tr><td>'+date(d.photo)+'</td><td>'+(d.identified==null?'—':n(d.identified))+'</td><td>'+(d.fail==null?'—':n(d.fail))+'</td><td>'+(d.errorOccurrences==null?'—':n(d.errorOccurrences))+'</td></tr>').join('')+'</tbody></table></details><small>Meses sem informação e períodos com critérios distintos não são conectados.</small></article>':'')+
     '<div class="exec-comparison-grid"><article class="card exec-panel"><div class="exec-panel-head"><h2>Ocorrências por código</h2><span>'+date(current().photo)+(previous()?' × '+date(previous().photo):'')+'</span></div><div class="exec-chart-legend">'+(previous()?'<span>'+date(previous().photo)+'</span>':'')+'<span class="valid-key">'+date(current().photo)+'</span><span class="exec-scale-note">Escala logarítmica</span></div>'+codeChart(ruleData,codes,max)+'<small>Escala logarítmica log(1 + quantidade): evidencia ocorrências de baixa frequência e preserva o zero sem barra. Os rótulos mostram as quantidades exatas. Selecione um código para consultar os participantes.</small></article>'+
     '<article class="card exec-panel comparison-table"><h2>Comparativo dos apontamentos</h2><div class="scroll-table"><table><thead><tr><th>Código</th><th>Erro identificado</th>'+(previous()?'<th>'+date(previous().photo)+'</th>':'')+'<th>'+date(current().photo)+'</th>'+(previous()?'<th>Variação</th>':'')+'</tr></thead><tbody>'+table+'</tbody><tfoot><tr><th colspan="2">Total de ocorrências</th>'+(previous()?'<th>'+(complete?n(old):'—')+'</th>':'')+'<th>'+n(sum)+'</th>'+(previous()?'<th>'+(complete?(sum-old>0?'+':'')+n(sum-old):'—')+'</th>':'')+'</tr></tfoot></table></div><small>O total representa ocorrências, não participantes distintos. Selecione uma variação para identificar matrículas e evidências.</small></article></div>'+
     '<article class="card exec-panel changes-panel"><div class="exec-panel-head"><div><h2>Investigação das variações</h2><p>Consulte as matrículas, quantidades e chaves relacionadas aos acréscimos ou reduções.</p></div><button id="execInvestigate" class="secondary" '+(!previous()?'disabled':'')+'>Consultar variações</button></div><div id="execChanges"></div></article>';
   if(changesOpen)renderChanges();
 }
 function highlights(ps){
   $('#execHighlights').innerHTML=['EM','CE'].map(type=>{const maximum=ps.reduce((max,p)=>Math.max(max,p.counts[type]),0),ties=maximum?ps.filter(p=>p.counts[type]===maximum).length:0,top=D.leaders(ps,type);return '<article class="card exec-panel"><div class="exec-panel-head"><h2>'+ (type==='EM'?'Maior quantidade de e-mails cadastrados':'Maior quantidade de celulares cadastrados')+'</h2><button class="quiet" data-curiosity="'+(type==='EM'?'leader_email':'leader_mobile')+'" '+(!maximum?'disabled':'')+'>Consultar participantes</button></div><div class="highlight-total"><strong>'+n(maximum)+'</strong><span>maior quantidade de registros por participante<br>'+n(ties)+' participante(s) com essa quantidade</span></div>'+(maximum>1?'<div class="highlight-people">'+top.map(p=>'<button data-person="'+esc(p.matricula)+'"><span>'+esc(p.nome)+'<small>Matrícula Petros: '+esc(D.master(p))+'</small></span><b>'+n(p.counts[type])+'</b></button>').join('')+'</div>':'')+'<small>As quantidades correspondem a registros cadastrados, inclusive repetições, e não a endereços ou números distintos.</small></article>';}).join('');
 }
 function people(ps){
   const pages=Math.max(1,Math.ceil(ps.length/personSize));personPage=Math.max(1,Math.min(personPage,pages));const slice=ps.slice((personPage-1)*personSize,personPage*personSize);
   $('#execPeople').innerHTML='<div class="exec-panel-head"><div><h2>Participantes e evidências</h2><p>'+n(ps.length)+' participantes no recorte selecionado.</p></div><div class="button-row"><button id="execExport" class="secondary" '+(!ps.length?'disabled':'')+'>Exportar recorte Excel</button><button id="execTreat" class="primary" '+(!ps.length?'disabled':'')+'>Abrir fila de tratamento</button></div></div><div class="scroll-table exec-people-table"><table><thead><tr><th>Participante</th><th>Plano / subsituação</th><th>Registros de contato</th><th>Resultado</th><th>Tratamento</th><th></th></tr></thead><tbody>'+slice.map(p=>'<tr><td><b>'+esc(p.nome)+'</b><small>Matrícula Petros: '+esc(D.master(p))+(p.age!=null?' · '+p.age+' anos':'')+'</small></td><td title="'+esc([...new Set(X.bindings(p,filters).map(v=>v.plano))].join(' · '))+'">'+esc([...new Set(X.bindings(p,filters).map(v=>U.shortPlan(v.plano)))].join(' · '))+'<small>'+esc([...new Set(X.bindings(p,filters).map(v=>v.contractSubgroup))].join(' · '))+'</small></td><td>'+p.counts.TL+' fixos · '+p.counts.CE+' celulares · '+p.counts.EM+' e-mails</td><td><span class="badge '+(p.errors?'fail':p.warnings?'warn':'pass')+'">'+esc(p.status)+'</span><small>'+p.errors+' erros · '+p.warnings+' alertas</small></td><td>'+esc(p.treatmentStatus)+'</td><td><button class="quiet" data-person-detail="'+esc(p.id)+'">Consultar</button></td></tr>').join('')+'</tbody></table></div><div class="exec-pagination"><label>Registros por página<select id="execSize"><option value="20" '+(personSize===20?'selected':'')+'>20</option><option value="100" '+(personSize===100?'selected':'')+'>100</option></select></label><span>Página '+n(personPage)+' de '+n(pages)+'</span><button class="secondary" id="execBack" '+(personPage===1?'disabled':'')+'>Anterior</button><button class="secondary" id="execNext" '+(personPage===pages?'disabled':'')+'>Próxima</button></div>';
 }
 function selectedChanges(){return changeRows.filter(r=>(!changeType||r.movement===changeType)&&(!changeRule||r.rule===changeRule));}
 function renderChanges(){
   const el=$('#execChanges');if(!el||!previous())return;
   changeRows=D.movementRows(current(),previous(),filters);const codes=new Map(B.catalog('Erro').map(r=>[r.id,r.code]));
   const rows=selectedChanges(),pages=Math.max(1,Math.ceil(rows.length/20));changePage=Math.max(1,Math.min(changePage,pages));
   el.innerHTML='<div class="change-controls"><label>Classificação<select id="execChangeType">'+[['aumento','Acréscimos'],['reducao','Reduções'],['persistente','Ocorrências mantidas'],['alteracao','Alteração das evidências'],['','Todas as variações']].map(([v,l])=>'<option value="'+v+'" '+(changeType===v?'selected':'')+'>'+l+'</option>').join('')+'</select></label><label>Apontamento<select id="execChangeRule"><option value="">Todos</option>'+B.catalog('Erro').map(r=>'<option value="'+r.id+'" '+(changeRule===r.id?'selected':'')+'>'+r.code+' · '+esc(r.description)+'</option>').join('')+'</select></label><span>'+n(rows.length)+' combinações de matrícula e regra</span><button id="execExportChanges" class="secondary" '+(!rows.length?'disabled':'')+'>Exportar investigação</button></div><div class="scroll-table"><table><thead><tr><th>Participante / código</th><th>Anterior → atual</th><th>Motivo da variação</th><th>Evidências / chaves</th></tr></thead><tbody>'+rows.slice((changePage-1)*20,changePage*20).map(r=>'<tr><td><b>'+esc(r.nome)+'</b><small>'+esc(r.master||r.matricula)+' · '+codes.get(r.rule)+' · '+esc(r.label)+'</small></td><td>'+n(r.previous)+' → '+n(r.current)+'<small class="'+(r.delta>0?'increase':'decrease')+'">'+(r.delta>0?'+':'')+n(r.delta)+'</small></td><td>'+esc(r.reason)+'</td><td><details><summary>Comparar evidências</summary><b>Anterior</b><p>'+esc(r.previousEvidence||'Sem ocorrência no recorte anterior').replace(/\n/g,'<br>')+'</p><b>Atual</b><p>'+esc(r.currentEvidence||'Sem ocorrência no recorte atual').replace(/\n/g,'<br>')+'</p><small>Chave anterior: '+esc(r.previousKeys||'—').replace(/\n/g,'<br>')+'<br>Chave atual: '+esc(r.currentKeys||'—').replace(/\n/g,'<br>')+'</small></details></td></tr>').join('')+'</tbody></table></div><div class="exec-pagination"><span>Página '+n(changePage)+' de '+n(pages)+'</span><button id="execChangeBack" class="secondary" '+(changePage===1?'disabled':'')+'>Anterior</button><button id="execChangeNext" class="secondary" '+(changePage===pages?'disabled':'')+'>Próxima</button></div><p class="hint">A saída do público avaliado ou a alteração de enquadramento não comprova correção cadastral. Consulte a evidência e as quantidades de cada período.</p>';
 }
 async function historicalSeries(f,selectedRun,token=null){
   const list=H.canonical(selectedRun.classification==='demonstration'?{...db,runs:db.runs.filter(r=>r.classification==='demonstration')}:db);
   const runs=[...list.filter(r=>r.photo<selectedRun.photo&&r.photo.slice(0,7)!==selectedRun.photo.slice(0,7)),selectedRun],out=[];
   for(let i=0;i<runs.length;i++){
     const r=runs[i],unsupported=r.migrationNote&&(f.status||f.treatment||f.rule==='shared');let m=unsupported?null:H.measure(r,f);
     if(!m&&!unsupported){await H.expand(r,JSZip);if(token!=null&&token!==renderToken)return [];m=D.metrics(D.filter(r.people,f));if(![selected,priorId,selectedRun.id].includes(r.id))r.people=null;await pause();}
     out.push({id:r.id,photo:r.photo,profile:H.profile(r),...(m||{identified:null,covered:null,coverageRate:null,errorRate:null,errorOccurrences:null,fail:null}),unavailable:!m});
   }return out;
 }
 async function render(changed=''){
   const token=++renderToken;controls();const exists=!!current();$('#execEmpty').hidden=exists;$('#execLoaded').hidden=!exists;if(!exists)return;
   $('#execLoading').hidden=false;await pause();await ensurePair();if(token!==renderToken)return;
   facets(changed);const ps=scope();$('#execScope').textContent=(current().classification==='demonstration'?'Demonstração fictícia · ':'')+'Fotografia '+date(current().photo)+' · '+n(ps.length)+' participantes no recorte';
   $('#execSourceStatus').textContent=origin+(dirty?' · alterações locais pendentes de gravação':'')+(current().migrationNote?' · histórico convertido; evidências anteriores parcialmente disponíveis':'');
   const series=await historicalSeries({...filters},current(),token);if(token!==renderToken)return;overview(ps);evolution(series);highlights(ps);people(ps);$('#execLoading').hidden=true;
 }
 async function comparison(result,f={}){
   await flush();const r=db.runs.find(r=>r.id===result.runId)||H.capture({...ComApp.state,result}),before=H.previous(db,r);
   if(!before)return {previousRun:null,previousPeople:null,historySeries:await historicalSeries(f,r)};
   await H.expand(before,JSZip);const ps=D.filter(H.people(before),f);H.evict(db,[r.id,before.id]);
   return {previousRun:before,previousPeople:ps,comparable:D.compare(r,before,f).available,historySeries:await historicalSeries(f,r)};
 }
 async function exportChanges(){
   const rows=selectedChanges(),codes=new Map(B.catalog('Erro').map(r=>[r.id,r.code]));
   const table=[['Matrícula Petros','Nome','Código','Erro identificado','Quantidade anterior','Quantidade atual','Variação','Classificação','Motivo da variação','Evidência anterior','Evidência atual','Chave anterior','Chave atual','Fotografia anterior','Fotografia atual'],...rows.map(r=>[r.master||r.matricula,r.nome,codes.get(r.rule),r.label,r.previous,r.current,r.delta,r.movement,r.reason,r.previousEvidence,r.currentEvidence,r.previousKeys,r.currentKeys,date(previous().photo),date(current().photo)])];
   const blob=await W.workbook({Investigacao:table},null,{variant:'batch',sheetMeta:{Investigacao:{title:'Investigação das variações de apontamentos',studyDate:new Date(current().photo+'T00:00:00Z'),generatedAt:B.generationDate(new Date()),scope:H.SCOPE}}});U.downloadBlob(blob,'PIC_INVESTIGACAO_'+current().photo+'.xlsx');
 }
 async function init(){
   ComApp.page('portal');
   $('#historyClose').onclick=()=>$('#historyDialog').close();$('#historyOpen').onclick=chooseFile;$('#historyManualOpen').onclick=()=>$('#historyInput').click();$('#historySave').onclick=()=>save();$('#historySaveAs').onclick=()=>save(true);$('#historyDownload').onclick=download;$('#historyReconnect').onclick=reconnect;$('#historyCapture').onclick=()=>work('Registrando fotografia',p=>capture('manual',p));
   $('#historyInput').onchange=async e=>{const file=e.target.files[0];if(!file)return;try{await work('Carregando histórico',p=>accept(file,null,p));}catch(err){message(err.message);}finally{e.target.value='';}};
   for(const id of ['openHistory','portalOpen','execOpen'])$('#'+id).onclick=openHistory;
   $('#portalExecutive').onclick=()=>ComApp.page('executive');
   $('#portalOperational').onclick=async()=>{try{if(current())await activate();ComApp.page(ComApp.state.result?'dashboard':'load');}catch(e){notify(e.message);}};
   $('#newPhoto').onclick=()=>ComApp.newExecution();
   $('#execPhoto').onchange=e=>{selected=e.target.value;priorId='';filters={};$('#execSearch').value='';personPage=1;changesOpen=false;render().catch(e=>notify(e.message));};
   $('#execPrevious').onchange=e=>{priorId=e.target.value;changesOpen=false;render().catch(e=>notify(e.message));};
   $('#execLoaded').onchange=e=>{const key=e.target.dataset.execFilter;if(key){filters[key]=e.target.value;personPage=1;render(key).catch(e=>notify(e.message));}else if(e.target.id==='execCuriosity'){filters.curiosity=e.target.value;personPage=1;render().catch(e=>notify(e.message));}};
   $('#execSearch').oninput=U.debounce(e=>{filters.search=e.target.value;delete filters.person;personPage=1;render().catch(e=>notify(e.message));},250);
   $('#execReset').onclick=()=>{filters={};$('#execSearch').value='';personPage=1;changesOpen=false;render().catch(e=>notify(e.message));};
   $('#page-executive').addEventListener('change',e=>{
     if(e.target.id==='execSize'){personSize=+e.target.value;personPage=1;people(scope());}
     if(e.target.id==='execChangeType'){changeType=e.target.value;changePage=1;renderChanges();}
     if(e.target.id==='execChangeRule'){changeRule=e.target.value;changePage=1;renderChanges();}
   });
   $('#page-executive').addEventListener('click',async e=>{
     const b=e.target.closest('button');if(!b)return;
     try{
       if(b.dataset.dimension){filters[b.dataset.dimension]=b.dataset.value;await render(b.dataset.dimension);}
       else if(b.dataset.rule){filters.rule=b.dataset.rule;personPage=1;await render('rule');$('#execPeople').scrollIntoView?.({behavior:'smooth',block:'start'});}
       else if(b.dataset.coverage){filters.coverage=b.dataset.coverage;await render('coverage');}
       else if(b.dataset.exclusion){filters.exclusion=b.dataset.exclusion;await render('exclusion');}
       else if(b.dataset.quality){filters.status=b.dataset.quality;await render('status');}
       else if(b.dataset.resetQuality){delete filters.status;await render();}
       else if(b.dataset.person){filters.person=b.dataset.person;filters.search='';$('#execSearch').value=b.dataset.person;personPage=1;await render();$('#execPeople').scrollIntoView?.({behavior:'smooth',block:'start'});}
       else if(b.dataset.curiosity){filters.curiosity=b.dataset.curiosity;personPage=1;await render();$('#execPeople').scrollIntoView?.({behavior:'smooth',block:'start'});}
       else if(b.dataset.personDetail){await activate();const p=ComApp.state.result.participantIndex.get(b.dataset.personDetail);ComApp.detail('participant',p.index);}
       else if(b.dataset.movementRule||b.dataset.openMovements||b.id==='execInvestigate'){changesOpen=true;changeRule=b.dataset.movementRule||'';changeType=b.dataset.movementType||b.dataset.openMovements||'aumento';changePage=1;renderChanges();$('#execChanges').scrollIntoView?.({behavior:'smooth',block:'start'});}
       else if(b.id==='execExport'){b.disabled=true;const ps=scope(),blob=await X.treatment(ps,{...filters,includeContext:true},null);U.downloadBlob(blob,'PIC_RECORTE_'+current().photo+'.xlsx');b.disabled=false;}
       else if(b.id==='execTreat'){await activate();ComApp.openQueue(filters);}
       else if(b.id==='execExportChanges'){b.disabled=true;await exportChanges();b.disabled=false;}
       else if(b.id==='execBack'){personPage--;people(scope());}else if(b.id==='execNext'){personPage++;people(scope());}
       else if(b.id==='execChangeBack'){changePage--;renderChanges();}else if(b.id==='execChangeNext'){changePage++;renderChanges();}
     }catch(err){notify(err.message);b.disabled=false;}
   });
   $('#historyTable').addEventListener('click',e=>{const b=e.target.closest('[data-history-run]');if(b){selected=b.dataset.historyRun;priorId='';filters={};$('#historyDialog').close();ComApp.page('executive');}});
   window.addEventListener('beforeunload',e=>{if(dirty){e.preventDefault();e.returnValue='';}});
   try{
     const cached=await P.loadDatabase(async(r,version)=>{if(version===2){const migrated=H.migrate(r);await H.pack(migrated,JSZip);migrated.people=null;return migrated;}return r;});
     if(cached){db=H.validate({...cached,version:H.VERSION});cacheOK=true;dirty=true;origin='Cópia local · arquivo central ainda não conferido';await persist();}
     handle=await P.read('handle')||null;
     if(handle){if(await P.permission(handle)){const file=await handle.getFile();await work('Conferindo histórico vinculado',p=>accept(file,handle,p));}else origin+=' · reautorização de leitura necessária';}
   }catch(e){message('O carregamento automático não foi concluído. '+e.message);}
   controls();if(!db.runs.length)openHistory();
 }
 globalThis.ComHistoryUI={capture,flush,release,comparison,render,openHistory,get database(){return db;},get dirty(){return dirty;}};
 init().catch(e=>notify('A abertura do histórico não foi concluída. '+e.message));
})();

