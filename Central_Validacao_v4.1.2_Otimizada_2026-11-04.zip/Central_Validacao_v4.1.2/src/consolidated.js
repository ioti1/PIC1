(function(root,factory){const node=typeof module==='object'&&module.exports;const api=factory(node?require('./audit.js'):root.ComAudit,node?require('./model.js'):root.ComModel,node?require('./reconcile.js'):root.ComReconcile,node?require('./xlsx-writer.js'):root.ComExport);if(node)module.exports=api;else root.ComConsolidated=api;})(globalThis,function(A,M,R,W){
  'use strict';
  const unique=items=>[...new Set(items.filter(v=>v!==''&&v!=null).map(String))];
  const checked=v=>{const s=String(v??'');if(s.length>32767)throw new Error('Um campo consolidado excede 32.767 caracteres (limite do Excel). Refine o recorte ou revise os contatos dessa matrícula. Nenhum dado foi truncado.');return s;};
  const join=items=>checked(unique(items).join('\n'));
  const date=v=>A.isMissingDate(v)?'':A.date(v)||A.str(v);
  function deaths(p){return unique(p.vinculos.filter(v=>!A.isMissingDate(v.values.obito)).map(v=>A.date(v.values.obito)?.toISOString().slice(0,10)||A.str(v.values.obito)));}
  function bindings(p,f={}){return p.vinculos.filter(v=>(!f.plan||v.plano===f.plan)&&(!f.sponsor||v.patrocinador===f.sponsor)&&(!f.group||v.contractGroup===f.group)&&(!f.subgroup||v.contractSubgroup===f.subgroup));}
  function problems(p,{rule='',problem='',contacts=null,includeContext=true,allRules=false}={}){
    const allowed=f=>f.rule!=='death'&&(!rule||f.rule===rule)&&(!problem||(f.problem||f.message)===problem);
    const cs=contacts||p.channels,items=[];
    if(includeContext)for(const f of (allRules?p.allContextIssues||p.contextIssues:p.contextIssues).filter(allowed))items.push({f,evidence:f.field==='Óbito'?'Data de óbito: '+deaths(p).map(v=>A.date(v)?formatDate(v):v).join('; '):f.field==='Nascimento'||f.field==='Idade'?join(p.vinculos.map(v=>`Nascimento: ${formatDate(v.values.nascimento)}; idade informada: ${A.str(v.values.idade)||'não informada'}`)):['no_registry','no_contact'].includes(f.rule)?p.channels.length?join(p.channels.map(c=>`${c.label}: ${R.evidence(c)}`)):'Telefone, celular e e-mail: nenhum contato cadastrado':f.raw||f.field});
    for(const c of cs)for(const f of (allRules?c.allIssues||c.issues:c.issues).filter(allowed))items.push({f,evidence:`${c.label}: ${R.evidence(c)}${['TL','CE'].includes(c.typeCode)?'; DDD de origem: '+(A.str(c.rawValues.ddd)||'ausente')+'; número de origem: '+(A.str(c.rawValues.numero)||'ausente'):''}${f.rule==='unknown_type'?'; tipo de origem: '+A.str(c.rawValues.tipo):''}${f.rule==='registry_user'?'; usuário: '+c.registrationUser:''}${f.rule==='registry_date'?'; data de cadastro: '+M.formatTimestamp(c.registrationDate||c.rawValues.data_registro):''}`});
    return items;
  }
  function formatDate(v){const d=A.date(v);return d?`${String(d.getUTCDate()).padStart(2,'0')}/${String(d.getUTCMonth()+1).padStart(2,'0')}/${d.getUTCFullYear()}`:A.str(v)||'Não informado';}
  function* treatmentRows(ps,f={},contactScope=null){
    yield ['Matrícula Petros','Nome','Data de Nascimento','Plano','Patrocinadora','Situação Contratual','Sub Situação Contratual','Problema Identificado','Campos relacionados ao problema identificado','Data de Óbito'];
    const byPerson=contactScope?new Map():null;
    if(contactScope)for(const c of contactScope){if(!byPerson.has(c.participantId))byPerson.set(c.participantId,[]);byPerson.get(c.participantId).push(c);}
    for(const p of ps){if(!R.assessable(p))continue;const vs=bindings(p,f),items=problems(p,{...f,contacts:byPerson?.get(p.id)}),births=unique(vs.map(v=>v.birth?.toISOString().slice(0,10)||A.str(v.values.nascimento))),ds=deaths(p);yield [String(p.vinculos.find(v=>String(v.values?.matricula??'').trim())?.values.matricula??p.matricula),p.nome,births.length===1?date(births[0]):join(births.map(formatDate)),join(vs.map(v=>v.plano)),join(vs.map(v=>v.patrocinador)),join(vs.map(v=>v.contractGroup)),join(vs.map(v=>v.contractSubgroup)),join(items.map(({f})=>f.message))||'Sem apontamentos nas regras selecionadas',join(items.map(i=>i.evidence)),ds.length===1?date(ds[0]):join(ds.map(formatDate))];}
  }
  async function treatment(ps,f,cs,onProgress){return W.workbook({Tratamento:treatmentRows(ps,f,cs)},onProgress,{maxRows:1048575,variant:'treatment'});}
  return {formatDate,deaths,bindings,problems,treatmentRows,treatment};
});
