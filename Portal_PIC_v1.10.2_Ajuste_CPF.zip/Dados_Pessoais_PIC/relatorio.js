(function(root,factory){
  const node=typeof module==='object'&&module.exports,base='../Central_Validacao_v4.2.2/';
  const api=factory(node?require(base+'vendor/jspdf.umd.min.js'):root.jspdf,node?require(base+'src/report-brand.js'):root.ComBrand);
  if(node)module.exports=api;else root.PicPessoalReport=api;
})(globalThis,function(Pdf,Brand){
  'use strict';
  const ink='#030413',blue='#0045DE',rose='#FC7397',line='#D7DFF1',soft='#EFF3FC',muted='#4D5B77',white='#FFFFFF';
  const D=s=>s.split('-').reverse().join('/'),num=n=>Number(n).toLocaleString('pt-BR');
  const clean=s=>String(s??'').replace(/[\x00-\x1f\x7f]/g,' ').replace(/[—–‑]/g,'-').replace(/→/g,'>');
  function generate({photo,reference,scope,comparison,metrics,charts,legacy}){
    const {jsPDF}=Pdf,doc=new jsPDF({unit:'mm',format:'a4',compress:true,putOnlyUsedFonts:true});
    const L=17,W=176,R=L+W;
    doc.setProperties({title:'PIC - Relatório de Dados Pessoais',subject:'Fotografia '+D(photo),author:'Núcleo Analytics - GAP/CA'});
    const font=(size,bold=false)=>{doc.setFont('helvetica',bold?'bold':'normal');doc.setFontSize(size);};
    const text=(s,x,y,size=9,bold=false,color=ink,align='left')=>{font(size,bold);doc.setTextColor(color);doc.text(clean(s),x,y,{align});};
    const wrap=(s,width,size,bold=false)=>{font(size,bold);return doc.splitTextToSize(clean(s),width);};
    const fill=(x,y,w,h,color)=>{doc.setFillColor(color);doc.rect(x,y,w,h,'F');};
    const hr=(y,color=line)=>{doc.setDrawColor(color);doc.setLineWidth(.24);doc.line(L,y,R,y);};
    const para=(s,y,width=W,size=8,color=muted)=>{for(const l of wrap(s,width,size)){text(l,L,y,size,false,color);y+=4.1;}return y;};
    const page=(title,sub)=>{
      Brand.draw(doc,L,11,55);
      text('QUALIDADE CADASTRAL',R,17,7.4,true,blue,'right');hr(23);
      text(title,L,36,22,true);text(sub,L,43,8.2,false,muted);
    };
    const short=(s,width,size)=>{font(size);s=clean(s);if(doc.getTextWidth(s)<=width)return s;while(s.length>1&&doc.getTextWidth(s+'...')>width)s=s.slice(0,-1);return s+'...';};
    page('Relatório de Dados Pessoais','Fotografia '+D(photo)+'  ·  Referência '+D(reference));
    let y=51;
    const scopeLines=wrap('Recorte: '+scope,W-8,8.2);
    if(scopeLines.length>4)scopeLines.splice(3,scopeLines.length-3,short(scopeLines[3]+' ...',W-8,8.2));
    fill(L,y,W,6+scopeLines.length*4,soft);
    scopeLines.forEach((l,i)=>text(l,L+4,y+5+i*4,8.2,false,muted));
    y+=12+scopeLines.length*4;
    const tile=(W-12)/4;
    metrics.forEach(([label,value],i)=>{
      const x=L+i*(tile+4);
      fill(x,y,tile,22,soft);fill(x,y,tile,.8,i===2||i===3?rose:blue);
      text(label,x+3,y+7.5,7.5,true,muted);text(num(value),x+3,y+16,15,true);
    });
    y+=33;
    text(comparison.label,L,y,13,true);y+=6;
    const before=Boolean(comparison.previousPhoto);
    const headers=['Código','Apontamento','Pessoas no mês',...(before?[D(comparison.previousPhoto)]:[]),D(photo),...(before?['Entradas','Saídas','Variação']:[])];
    const widths=before?[17,48,18,20,20,15,14,24]:[21,99,27,29];
    const drawHeader=()=>{
      const hs=headers.map((h,i)=>wrap(h,widths[i]-4,7.1,true)),height=Math.max(...hs.map(h=>h.length))*3.3+5;
      fill(L,y,W,height,blue);
      let x=L;
      hs.forEach((ls,i)=>{ls.forEach((s,j)=>text(s,i<2?x+2:x+widths[i]-2,y+4.7+j*3.3,7.1,true,white,i<2?'left':'right'));x+=widths[i];});
      y+=height;
    };
    drawHeader();
    comparison.rows.forEach((row,index)=>{
      const total=index===comparison.rows.length-1,family=comparison.rows.some(other=>other[0].startsWith(row[0]+'.'));
      const cs=row.map((s,i)=>wrap(s,widths[i]-4,7.6,i===0||total||family));
      const height=Math.max(...cs.map(ls=>ls.length))*3.4+3.8;
      if(y+height>264){doc.addPage();page(comparison.label+' (continuação)','Fotografia '+D(photo));y=51;drawHeader();}
      if(total||family||index%2===1)fill(L,y,W,height,total||family?'#DCE7FF':soft);
      let x=L;
      cs.forEach((ls,i)=>{ls.forEach((s,j)=>text(s,i<2?x+2:x+widths[i]-2,y+4.3+j*3.4,7.6,i===0||total||family,i===0&&!total?blue:ink,i<2?'left':'right'));x+=widths[i];});
      y+=height;
    });
    const note=comparison.notice+' As colunas por data, entradas e saídas contam ocorrências. Um traço indica regra não avaliada ou comparação indisponível.';
    const noteFirst=y+5+wrap(note,W,7.6).length*4.1<=277;
    if(noteFirst)para(note,y+5,W,7.6);
    doc.addPage();
    page('Distribuição dos erros','Participantes distintos por categoria. Uma pessoa pode aparecer em mais de uma categoria.');
    const chartW=(W-6)/2,heights=[0,2].map(i=>16+Math.max(2,...charts.slice(i,i+2).map(c=>c[1].length))*8);
    charts.forEach(([title,rows],i)=>{
      const x=L+(i%2)*(chartW+6),top=i<2?53:61+heights[0],chartH=heights[Math.floor(i/2)],max=Math.max(1,...rows.map(r=>r[1]));
      fill(x,top,chartW,chartH,soft);fill(x,top,chartW,.7,blue);
      text(title,x+4,top+9,11,true);
      if(!rows.length)text('Sem ocorrências no recorte.',x+4,top+19,8,false,muted);
      rows.forEach(([label,n],j)=>{
        const yy=top+16+8*j;
        text(short(label,chartW-29,7.7),x+4,yy,7.7);
        text(num(n),x+chartW-4,yy,7.7,true,ink,'right');
        fill(x+4,yy+1.7,chartW-8,1.6,'#D8E3FA');
        fill(x+4,yy+1.7,(chartW-8)*n/max,1.6,blue);
      });
    });
    y=70+heights[0]+heights[1];
    if(!noteFirst)y=para(note,y,W,7.6)+4;
    para('Ex-participantes não integram o estudo. '+(legacy?'Esta competência foi calculada antes da revisão do critério de pensionistas.':'Datas contratuais e TVP não são avaliados nos vínculos de pensionistas.'),y);
    const pages=doc.getNumberOfPages();
    for(let i=1;i<=pages;i++){doc.setPage(i);hr(281);text('Núcleo Analytics - GAP/CA',105,286,8,true,muted,'center');text(i+' / '+pages,R,286,7.5,false,muted,'right');}
    return doc.output('blob');
  }
  return {generate};
});
