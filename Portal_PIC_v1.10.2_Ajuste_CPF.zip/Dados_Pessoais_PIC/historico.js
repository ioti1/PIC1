(function(root,factory){
  const node=typeof module==='object'&&module.exports,api=factory(root,node?require('./regras.js'):root.PicPessoal,node?require('../Central_Validacao_v4.2.2/vendor/jszip.min.js'):root.JSZip);
  if(node)module.exports=api;else root.PicPessoalHistory=api;
})(globalThis,function(root,R,Zip){
  'use strict';
  const dbName='PIC_Dados_Pessoais_1',format='PIC-DADOS-PESSOAIS',maxFile=350*1024*1024;
  const validMonth=v=>/^[0-9]{4}-(0[1-9]|1[0-2])$/.test(v||'');
  const filename=month=>'PIC_Dados_Pessoais_'+month+'.picdp';
  const filePattern=/^PIC_Dados_Pessoais_(\d{4}-(?:0[1-9]|1[0-2]))\.picdp$/i;
  const tick=()=>new Promise(r=>setTimeout(r,0));
  let opening=null;
  function db(){
    if(opening)return opening;
    opening=new Promise((resolve,reject)=>{
      if(!root.indexedDB){reject(Error('Memória local indisponível.'));return;}
      const request=root.indexedDB.open(dbName,1);
      request.onupgradeneeded=()=>{for(const n of ['periods','files','prefs'])if(!request.result.objectStoreNames.contains(n))request.result.createObjectStore(n);};
      request.onsuccess=()=>resolve(request.result);
      request.onerror=()=>reject(request.error);
      request.onblocked=()=>reject(Error('Feche as outras janelas de Dados Pessoais e tente novamente.'));
    });
    return opening;
  }
  async function get(store,key){
    const d=await db();
    return new Promise((ok,fail)=>{const r=key==null?d.transaction(store).objectStore(store).getAll():d.transaction(store).objectStore(store).get(key);r.onsuccess=()=>ok(r.result);r.onerror=()=>fail(r.error);});
  }
  async function write(names,action){
    const d=await db();
    return new Promise((ok,fail)=>{
      const t=d.transaction(names,'readwrite');t.oncomplete=()=>ok();t.onerror=()=>fail(t.error);t.onabort=()=>fail(t.error||Error('Gravação interrompida.'));
      action(t);
    });
  }
  function summary(run){
    const people=new Set(),dead=new Set();
    for(const f of run.issues)people.add(run.rows[f.id].key);
    for(const r of run.rows)if(r.dead)dead.add(r.key);
    return {people:run.meta.people,bindings:run.rows.length,issues:run.issues.length,affected:people.size,dead:dead.size};
  }
  async function encode(run,onProgress=()=>{}){
    const z=new Zip(),rows=[],issues=[],exits=[],size=4000;
    for(const [name,list,parts] of [['vinculos',run.rows,rows],['achados',run.issues,issues],['saidas-cadastrais',run.exits||[],exits]]){
      for(let start=0;start<list.length;start+=size){
        const file=name+'/'+String(parts.length).padStart(5,'0')+'.json';
        z.file(file,JSON.stringify(list.slice(start,start+size)));
        parts.push(file);
        if(parts.length%4===0)await tick();
      }
    }
    const {rows:_,issues:__,exits:___,...header}=run;
    const manifest={format,version:R.VERSION,month:R.monthOf(run.photo),header,summary:summary(run),rows,issues,...(Array.isArray(run.exits)?{exits}:{})};
    z.file('manifest.json',JSON.stringify(manifest));
    const bytes=await z.generateAsync({type:'uint8array',compression:'DEFLATE',compressionOptions:{level:3}},p=>onProgress(Math.round(p.percent)));
    if(bytes.length>maxFile)throw Error('O histórico gerado ultrapassa o tamanho permitido de 350 MB.');
    return {blob:new Blob([bytes],{type:'application/zip'}),manifest};
  }
  async function openBlob(blob){
    if(!blob||blob.size>maxFile)throw Error('Arquivo de histórico inválido ou maior que 350 MB.');
    const z=await Zip.loadAsync(await blob.arrayBuffer());
    const part=z.file('manifest.json');
    if(!part)throw Error('O arquivo não é um histórico de Dados Pessoais (.picdp).');
    let m;
    try{m=JSON.parse(await part.async('string'));}catch{throw Error('Manifesto do histórico inválido.');}
    if(m.format!==format||m.version!==R.VERSION||!validMonth(m.month)||!m.header?.photo||R.monthOf(m.header.photo)!==m.month||
      !R.date(m.header.photo).iso||!R.date(m.header.ref).iso||!R.unitLabel[m.header.unit]||!m.header.meta||!m.summary||
      !Array.isArray(m.rows)||!Array.isArray(m.issues)||m.rows.length>300||m.issues.length>4200||
      !m.rows.every(p=>typeof p==='string'&&/^vinculos\/\d{5}\.json$/.test(p))||!m.issues.every(p=>typeof p==='string'&&/^achados\/\d{5}\.json$/.test(p))||
      (m.exits!==undefined&&(!Array.isArray(m.exits)||m.exits.length>300||!m.exits.every(p=>typeof p==='string'&&/^saidas-cadastrais\/\d{5}\.json$/.test(p)))))
      throw Error('Histórico incompatível com Dados Pessoais PIC.');
    return {z,m};
  }
  async function decode(blob,onProgress=()=>{}){
    const {z,m}=await openBlob(blob),rows=[],issues=[],exits=[];
    for(const [parts,output] of [[m.rows,rows],[m.issues,issues],[m.exits||[],exits]]){
      for(const part of parts){
        const item=z.file(part);if(!item)throw Error('O histórico está incompleto.');
        const array=JSON.parse(await item.async('string'));
        if(!Array.isArray(array)||array.length>4000)throw Error('Bloco inválido no histórico.');
        for(const v of array){
          if(output===issues&&v&&typeof v==='object')v.code=R.canonicalCode(v.code);
          output.push(v);
        }
        onProgress();
      }
    }
    if(rows.length!==m.summary.bindings||issues.length!==m.summary.issues||
      rows.some(r=>!r||typeof r.key!=='string'||!r.key||typeof r.mat!=='string'||typeof r.group!=='string'||typeof r.subgroup!=='string')||
      issues.some(f=>!f||!Object.hasOwn(R.byCode,f.code)||!Number.isInteger(f.id)||!rows[f.id]||!Object.hasOwn(R.labels,f.field))||
      exits.some(r=>!r||typeof r.key!=='string'||!r.key||!R.excluded(r.situation)))
      throw Error('O histórico possui registros ou apontamentos inconsistentes.');
    const compareCounts=Object.fromEntries(Object.entries(m.header.meta.compareCounts||{}).map(([key,value])=>[R.canonicalCode(key),value]));
    return {run:{...m.header,meta:{...m.header.meta,compareCounts},rows,issues,...(m.exits?{exits}:{})},manifest:m};
  }
  function record(m,storedAt=Date.now()){
    return {month:m.month,photo:m.header.photo,ref:m.header.ref,prior:m.header.prior,created:m.header.created,summary:m.summary,storedAt};
  }
  async function put(blob,m,stamp=Date.now()){
    await write(['periods','files'],t=>{
      t.objectStore('periods').put(record(m,stamp),m.month);
      t.objectStore('files').put(blob,m.month);
    });
  }
  function prefs(key,value){
    if(arguments.length===1)return get('prefs',key);
    return write(['prefs'],t=>t.objectStore('prefs').put(value,key));
  }
  async function scan(directory){
    const out=[];
    if(!directory)return out;
    for await(const [name,handle] of directory.entries()){
      const m=name.match(filePattern);
      if(m&&handle.kind==='file')out.push({month:m[1],handle,origin:'Pasta vinculada'});
    }
    return out;
  }
  async function saveFile(directory,month,blob){
    const file=await directory.getFileHandle(filename(month),{create:true});
    const stream=await file.createWritable();
    try{await stream.write(blob);await stream.close();}catch(e){await stream.abort().catch(()=>{});throw e;}
    return file;
  }
  return {encode,decode,openBlob,put,record,prefs,scan,saveFile,filename,summary,
    list:()=>get('periods'),load:month=>get('files',month)};
});
