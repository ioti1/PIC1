if(location.hash==='#painel')location.replace('painel.html');
