(function(root,factory){
  const node=typeof module==='object'&&module.exports;
  const api=factory(node?require('../Central_Validacao_v4.2.2/src/audit.js'):root.ComAudit,node?require('./nomes-ibge.js'):root.PicNomesIBGE);
  if(typeof module==='object'&&module.exports)module.exports=api;else root.PicPessoal=api;
})(globalThis,function(A,reference){
  'use strict';
  const DAY=86400000, VERSION=1;
  const str=v=>v==null?'':String(v).trim();
  const norm=v=>str(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase().replace(/\s+/g,' ');
  const head=v=>norm(v).replace(/[^A-Z0-9]/g,'').replace(/DAT(A)?DE/g,'DATA');
  const filled=v=>!A.isMissing(v);
  const val=v=>filled(v)?str(v):'';
  const key=v=>{const s=val(v);return /^\d+$/.test(s)?s.replace(/^0+(?=\d)/,''):norm(s);};
  const fields=[
    ['mat','Matrícula Petros','Matricula','MP','NR Matricula Petros'],['name','Nome Participante','Nome','Nome do Participante'],
    ['cpf','CPF','CPF Participante'],['sex','Sexo','Sexo do Participante'],['civil','Estado Civil'],
    ['birth','Data Nascimento','Data de Nascimento','DT Nasc'],['admission','Data Admissão','Data de Admissão'],
    ['enrollment','Data Inscrição Plano','Data de Inscrição no Plano'],['tvpDate','Data Atualização TVP','Data de Atualização do TVP'],
    ['sponsorEnd','Data Desligamento Patrocinadora','Data de Desligamento na Patrocinadora'],
    ['planEnd','Data Desligamento Plano','Data de Desligamento no Plano'],['death','Data Óbito','Data de Óbito'],
    ['inss','FG Beneficio INSS','FG Benefício INSS','Benefício INSS','Aposentado INSS'],
    ['exempt','Isencao IR','Isenção IR','Isenção de IR'],['benefitStatus','Situação Benefício','Situação do Benefício'],
    ['tvp','TVP Atual'],['plan','Nome Plano','Plano','Nome do Plano'],
    ['sponsor','Nome Patrocinador','Patrocinadora','Nome Patrocinadora'],['sponsorMat','Matrícula Patrocinadora','Matrícula na Patrocinadora'],
    ['situation','Situação','Situação Contratual'],['benefit','Tipo Benefício','Tipo de Benefício'],
  ].map(([id,label,...aliases])=>({id,label,aliases:[label,...aliases],required:id!=='sponsorMat'}));
  const labels=Object.fromEntries(fields.map(f=>[f.id,f.label]));
  const dates=['birth','admission','enrollment','tvpDate','sponsorEnd','planEnd','death'];
  const enrichable=['name','cpf','sex','civil','birth','death'];
  const catalogVersion=3;
  const families={EDP01:'Erros relacionados a Nome',EDP02:'Inconsistências relacionadas ao CPF',EDP07:'Alteração de datas'};
  const rules=[
    ['EDP01.1','Alteração de nome entre competências','Identidade','Pessoa'],
    ['EDP01.2','Primeiro nome com menos de duas letras','Identidade','Pessoa','Erro',2],
    ['EDP01.3','Possível divergência entre nome e sexo cadastrado','Identidade','Pessoa','Alerta',2],
    ['EDP02.1','Alteração de CPF entre competências','Identidade','Pessoa'],
    ['EDP02.2','CPF com dígitos verificadores inválidos','Identidade','Pessoa','Erro',2],
    ['EDP02.3','CPF sem 11 dígitos ou com formato inválido','Identidade','Pessoa','Erro',2],
    ['EDP02.4','CPF vinculado a mais de uma matrícula Petros','Identidade','Pessoa'],
    ['EDP03','Alteração de sexo entre competências','Identidade','Pessoa'],
    ['EDP04','Transição de estado civil incompatível','Identidade','Pessoa'],
    ['EDP05','Isenção de IR sem confirmação de aposentadoria no INSS','Benefício e INSS','Vínculo'],
    ['EDP06','Benefício ativo com óbito cadastrado','Benefício e INSS','Vínculo'],
    ['EDP07.1','Data de admissão posterior à inscrição no plano','Datas e tempo de empresa','Vínculo'],
    ['EDP07.2','Data futura à referência da avaliação','Datas e tempo de empresa','Vínculo'],
    ['EDP07.3','Data anterior ao nascimento','Datas e tempo de empresa','Vínculo'],
    ['EDP07.4','Data informada em formato inválido','Datas e tempo de empresa','Vínculo'],
    ['EDP07.5','Idade acima de 100 anos na fotografia','Datas e tempo de empresa','Vínculo','Erro',2],
    ['EDP07.6','Idade inferior a 16 anos na fotografia','Datas e tempo de empresa','Vínculo','Erro',2],
    ['EDP07.7','Admissão antes dos 16 anos','Datas e tempo de empresa','Vínculo'],
    ['EDP07.8','Alteração da data de nascimento entre competências','Datas e tempo de empresa','Pessoa','Erro',3],
    ['EDP08','TVP Atual inferior ao tempo de empresa','Datas e tempo de empresa','Vínculo'],
    ['EDP13','Dado pessoal divergente entre vínculos','Identidade','Pessoa'],
    ['EDP15','Campo obrigatório não preenchido','Identidade','Pessoa','Erro',3],
  ].map(([code,title,group,grain,severity='Erro',since=1])=>({code,title,group,grain,severity,since,parent:code.includes('.')?code.split('.')[0]:''}));
  const byCode=Object.fromEntries(rules.map(r=>[r.code,r]));
  const migrated={EDP01:'EDP01.1',EDP02:'EDP02.1',EDP07:'EDP07.1',EDP09:'EDP07.2',EDP11:'EDP07.3',EDP14:'EDP07.4',EDP12:'EDP07.7',EDP10:'EDP02.4'};
  function canonicalCode(code){
    if(typeof code!=='string')return code;
    const normalized=code.replace(/^DP(\d{2}(?:\.\d+)?)$/,'EDP$1');
    return Object.hasOwn(migrated,normalized)?migrated[normalized]:normalized;
  }
  const ruleMatches=(code,filter)=>!filter||filter===code||byCode[code]?.parent===filter;
  const monthlyCodes=['EDP01.1','EDP02.1','EDP03','EDP04','EDP07.8'];
  const mandatoryFields=['cpf','name','birth','sex','civil'];
  const contractDates=new Set(['admission','enrollment','tvpDate','sponsorEnd','planEnd']);
  const contractRuleVersion=2;
  const pensionSensitive=new Set(['EDP07.1','EDP08','EDP07.2','EDP07.3','EDP07.4','EDP07.7']);
  const cpfRuleVersion=2;
  const cpfShapeSensitive=new Set(['EDP02.2','EDP02.3']);
  const unitLabel={months:'meses completos',days:'dias corridos',years:'anos completos'};
  const defaultMarital=['CASADO>SOLTEIRO','DIVORCIADO>SOLTEIRO','VIUVO>SOLTEIRO','SEPARADO>SOLTEIRO'];
  const dateDisplay=v=>/^\d{4}-\d{2}-\d{2}$/.test(v||'')?v.split('-').reverse().join('/'):str(v);
  const monthOf=v=>v.slice(0,7);
  function priorMonth(v){const [y,m]=v.slice(0,7).split('-').map(Number);return m===1?(y-1)+'-12':y+'-'+String(m-1).padStart(2,'0');}
  function today(){const p=new Intl.DateTimeFormat('sv-SE',{timeZone:'America/Sao_Paulo',year:'numeric',month:'2-digit',day:'2-digit'});return p.format(new Date());}
  function iso(y,m,d){
    if(y<1800||y>9999||m<1||m>12||d<1||d>31)return '';
    const dt=new Date(Date.UTC(y,m-1,d));
    return dt.getUTCMonth()===m-1&&dt.getUTCDate()===d?dt.toISOString().slice(0,10):'';
  }
  function date(v,excel1904=false){
    const s=str(v);
    if(A.isMissingDate(v)||s==='0')return {iso:'',invalid:false};
    let m;
    if((m=s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})(?:[T ][\d:.+Z-]+)?$/)))return checked(iso(+m[1],+m[2],+m[3]));
    if((m=s.match(/^(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{4})(?: \d{1,2}:\d{2}(?::\d{2})?)?$/)))return checked(iso(+m[3],+m[2],+m[1]));
    if(/^\d{1,7}(?:\.\d+)?$/.test(s)){
      const n=Math.floor(Number(s));if(n===60&&!excel1904)return checked('');
      const anchor=excel1904?Date.UTC(1904,0,1):Date.UTC(1899,11,n<60?31:30);
      const dt=new Date(anchor+n*DAY);return checked(iso(dt.getUTCFullYear(),dt.getUTCMonth()+1,dt.getUTCDate()));
    }
    return checked('');
  }
  function checked(iso){return {iso,invalid:!iso};}
  function age(d,ref){
    if(!d||!ref||d>ref)return null;
    return +ref.slice(0,4)-+d.slice(0,4)-(ref.slice(5)<d.slice(5)?1:0);
  }
  function ageBand(n){return n==null?'Não disponível':n<=18?'0–18':n<=29?'19–29':n>=90?'90+':Math.floor(n/10)*10+'–'+(Math.floor(n/10)*10+9);}
  function yearsLater(d,years){const y=+d.slice(0,4)+years,m=+d.slice(5,7),day=+d.slice(8);return iso(y,m,day)||iso(y,m,day-1);}
  function tenure(d,ref,unit){
    if(!d||!ref||d>ref)return null;
    if(unit==='days')return (Date.parse(ref)-Date.parse(d))/DAY;
    if(unit==='years')return age(d,ref);
    return (+ref.slice(0,4)-+d.slice(0,4))*12+(+ref.slice(5,7)-+d.slice(5,7))-(+ref.slice(8)<+d.slice(8)?1:0);
  }
  function durationMonths(value){
    const text=norm(value);
    const safe=n=>Number.isSafeInteger(n)?n:null;
    if(/^\d+(?:[.,]0+)?$/.test(text))return safe(Number(text.replace(',','.')));
    const both=text.match(/^(\d+)\s*(?:ANOS?|A)\s*(?:E\s*|,\s*)?(\d{1,2})\s*(?:MESES|MES|M)$/);
    if(both)return safe(Number(both[1])*12+Number(both[2]));
    const one=text.match(/^(\d+)\s*(ANOS?|A|MESES|MES|M)$/);
    if(one)return safe(Number(one[1])*(/^A/.test(one[2])?12:1));
    return null;
  }
  function durationText(value){
    const y=Math.floor(value/12),m=value%12;
    return !y?m+' '+(m===1?'mês':'meses'):y+' '+(y===1?'ano':'anos')+(m?' e '+m+' '+(m===1?'mês':'meses'):'');
  }
  function cpf(v,numeric=false){
    const s=val(v);
    if(!s||!/^\d[\d.\s-]*$/.test(s))return '';
    let d=s.replace(/\D/g,'');
    if(numeric&&d.length<11)d=d.padStart(11,'0');
    return d.length===11?d:'';
  }
  function cpfShape(value){
    const raw=val(value),digits=raw.replace(/\D/g,'');
    return {raw,digits,count:digits.length,correct:/^(?:\d{11}|(?:\d{9}|\d{3}\.\d{3}\.\d{3})-\d{2})$/.test(raw)};
  }
  function validCpf(digits){
    if(!/^\d{11}$/.test(digits)||/^(\d)\1{10}$/.test(digits))return false;
    const check=n=>{let sum=0;for(let i=0;i<n;i++)sum+=Number(digits[i])*(n+1-i);const x=(sum*10)%11;return x===10?0:x;};
    return check(9)===Number(digits[9])&&check(10)===Number(digits[10]);
  }
  const firstName=value=>str(value).split(/\s+/)[0];
  const letterCount=value=>(value.match(/\p{L}/gu)||[]).length;
  function nameSignal(name,sex){
    if(!reference||!['M','F'].includes(sex))return null;
    const first=norm(firstName(name)),sample=Object.hasOwn(reference,first)?reference[first]:null;
    if(!sample)return null;
    const [m,f]=sample,expected=m>f?'M':'F',share=Math.max(m,f)/(m+f);
    return sex!==expected?{first,sex,expected,share}:null;
  }
  function civil(v){
    const n=norm(v).replace(/\(A\)/g,'');
    if(/^(?:S|SOLTEIR[OA])$/.test(n))return 'SOLTEIRO';
    if(/^(?:C|CASAD[OA])$/.test(n))return 'CASADO';
    if(/^(?:V|VIUV[OA])$/.test(n))return 'VIUVO';
    if(/^(?:D|DIVORCIAD[OA])$/.test(n))return 'DIVORCIADO';
    if(/SEPARAD|DESQUITAD/.test(n))return 'SEPARADO';
    if(/UNIAO ESTAVEL/.test(n))return 'UNIAO ESTAVEL';
    return n;
  }
  function exemption(v){
    const n=norm(v);
    if(!filled(v))return 'Não informado';
    if(/^(?:NAO ISENT[OA]|N|NAO|NORMAL|SEM ISENCAO)$/.test(n))return 'Não isento';
    if(/^(?:ISENT[OA]|S|SIM)$|DOENCA|DECISOES? JUDICIA|DECISAO JUDICIAL/.test(n))return 'Isento';
    return 'Não classificado';
  }
  function excluded(v){return /^EX[-\s]*PARTICIPANTES?$/.test(norm(v));}
  function mapHeaders(header){
    const normalized=header.map(head);
    return Object.fromEntries(fields.flatMap(f=>{const aliases=new Set(f.aliases.map(head)),idx=normalized.findIndex(h=>aliases.has(h));return idx<0?[]:[[f.id,idx]];}));
  }
  function materialize(cells,map,src,line,excel1904=false){
    const r={src,line};
    for(const f of fields){
      const x=cells[map[f.id]];
      const raw=x&&typeof x==='object'?x.v:x;
      r[f.id]=val(raw);
      if(f.id==='cpf')r.cpfKey=cpf(raw,x?.num===true);
      if(dates.includes(f.id)){
        const d=date(raw,excel1904);
        r[f.id]=d.iso|| (d.invalid?r[f.id]:'');
        if(d.invalid)(r.invalidDates||(r.invalidDates=[])).push(f.id);
      }
    }
    r.key=key(r.mat);r.ex=excluded(r.situation);
    return r;
  }
  function addEnrichment(rows,values){
    let enriched=0, conflicts=0;
    for(const r of rows){
      if(r.ex)continue;
      const data=values.get(r.key);
      if(!data)continue;
      let changed=false;
      for(const f of enrichable){
        if(!filled(r[f])&&data[f]?.size===1){
          r[f]=data[f].values().next().value;changed=true;
          if(f==='cpf')r.cpfKey=cpf(r.cpf);
        }else if(!filled(r[f])&&data[f]?.size>1)conflicts++;
      }
      if(changed)enriched++;
    }
    return {enriched,conflicts};
  }
  const signature=r=>JSON.stringify([...fields.map(f=>f.id==='mat'?r.key:f.id==='cpf'?(cpfShape(r.cpf).correct?r.cpfKey||r.cpf:r.cpf):r[f.id]),r.invalidDates||[]]);
  function normalizeIdentity(r,id){
    if(id==='cpf')return r.cpfKey||'';
    if(id==='birth')return !r.invalidDates?.includes('birth')&&/^\d{4}-\d\d-\d\d$/.test(r.birth||'')?r.birth:'';
    if(id==='sex'){
      const s=norm(r.sex);return s==='MASCULINO'?'M':s==='FEMININO'?'F':s;
    }
    return id==='civil'?civil(r.civil):norm(r[id]);
  }
  function* personIndex(rows,phase){
    const people=new Map();
    for(let i=0;i<rows.length;i++){
      const r=rows[i];let p=people.get(r.key);
      if(!p){p={ids:[],profile:{}};people.set(r.key,p);}
      p.ids.push(i);
      for(const id of ['name','cpf','sex','civil','birth']){
        const n=normalizeIdentity(r,id);
        if(!n)continue;
        (p.profile[id]||=new Map()).set(n,id==='cpf'?n:r[id]);
      }
      if(i%5000===4999)yield {phase,done:i+1,total:rows.length};
    }
    return people;
  }
  function compareValue(map){return map?.size===1?[...map.entries()][0]:null;}
  function maskCpf(v){
    const {raw,digits}=cpfShape(v);
    return !raw?'':digits.length===11?'***.***.***-'+digits.slice(-2):'CPF informado (mascarado)';
  }
  const shown=(id,v)=>id==='cpf'?maskCpf(v):v;
  function* evaluation(rows,prior=null,options={}){
    const photo=options.photo,ref=options.ref||today(),unit='months';
    if(!/^\d{4}-\d\d-\d\d$/.test(photo||'')||!date(photo).iso||!/^\d{4}-\d\d-\d\d$/.test(ref)||!date(ref).iso||photo>ref||ref>today()||!unitLabel[unit])
      throw Error('Informe uma fotografia válida e uma referência entre a fotografia e a data de hoje.');
    const previous=prior&&monthOf(prior.photo)===priorMonth(photo)?prior:null;
    const marital=(Array.isArray(options.marital)?options.marital:defaultMarital).filter(t=>typeof t==='string'&&/^(?:CASADO|DIVORCIADO|VIUVO|SEPARADO|UNIAO ESTAVEL)>SOLTEIRO$/.test(t)).sort();
    const eligible=[], seen=new Set(), exKeys=new Set(), issues=[], exits=[];
    let removed=0,noKey=0,excludedRows=0,unclassified=0,unknownExempt=0,skippedTvp=0,pensionBindings=0,n=0;
    for(const r of rows){
      if(++n%5000===0)yield {phase:'Separando vínculos elegíveis',done:n,total:rows.length};
      if(r.ex){
        excludedRows++;
        if(r.key){
          exKeys.add(r.key);
          const {key,mat,plan,sponsor,sponsorMat,situation,planEnd,src,line}=r;
          exits.push({key,mat,plan,sponsor,sponsorMat,situation,planEnd,src,line,pension:norm(r.benefit).includes('PENS')});
        }
        continue;
      }
      if(!r.key){noKey++;continue;}
      const sig=signature(r);
      if(seen.has(sig)){removed++;continue;}
      seen.add(sig);
      const c=A.classifyContract(r.situation,r.benefit);
      const group=c.contractGroup,subgroup=/^PENSIONISTA(S)?$/.test(norm(r.situation))?'Pensionista':c.contractSubgroup;
      if(group==='Não classificado')unclassified++;
      r.group=group;r.subgroup=subgroup;r.dead=Boolean(r.death&&!r.invalidDates?.includes('death'));
      r.band=ageBand(age(r.invalidDates?.includes('birth')?'':r.birth,photo));r.exemption=exemption(r.exempt);
      if(r.exemption==='Não classificado')unknownExempt++;
      eligible.push(r);
    }
    const index=yield* personIndex(eligible,'Indexando matrículas');
    const old=previous?yield* personIndex(previous.rows,'Indexando o mês anterior'):null,cpfs=new Map(),compared=new Set(),compareCounts=Object.fromEntries(monthlyCodes.map(c=>[c,0]));
    const add=(code,id,field,detail,before='',after='',facts)=>issues.push({code,id,field,detail,before,after,...(facts?{facts}:{})});
    n=0;
    for(const [mat,p] of index){
      if(++n%5000===0)yield {phase:'Comparando dados pessoais',done:n,total:index.size};
      const id=p.ids[0],prev=old?.get(mat);
      if(prev)compared.add(mat);
      for(const [field,code] of [['name','EDP01.1'],['cpf','EDP02.1'],['sex','EDP03'],['civil','EDP04']]){
        const values=p.profile[field];
        if(values?.size>1){
          const variants=[...values.values()].map(v=>shown(field,v));
          add('EDP13',id,field,'Valores diferentes no mesmo mês: '+variants.slice(0,8).join(' / ')+'.','','',{variants:variants.slice(0,20)});
        }
        const a=compareValue(prev?.profile[field]),b=compareValue(values);
        if(a&&b){
          compareCounts[code]++;
          if(a[0]!==b[0]&&(field!=='civil'||marital.includes(a[0]+'>'+b[0])))
            add(code,id,field,'Comparação com a fotografia de '+dateDisplay(previous.photo)+'.',shown(field,a[1]),shown(field,b[1]));
        }
        if(field==='cpf')for(const d of values?.keys()||[]){
          let group=cpfs.get(d);if(!group){group=[];cpfs.set(d,group);}group.push(id);
        }
      }
      const birthA=compareValue(prev?.profile.birth),birthB=compareValue(p.profile.birth);
      if(birthA&&birthB){
        compareCounts['EDP07.8']++;
        if(birthA[0]!==birthB[0]){
          const rowId=p.ids.find(i=>eligible[i].birth===birthB[0]),priorId=prev.ids.find(i=>previous.rows[i].birth===birthA[0]);
          const priorRow=previous.rows[priorId];
          add('EDP07.8',rowId,'birth','A data de nascimento mudou de '+dateDisplay(birthA[0])+' para '+dateDisplay(birthB[0])+'. Confira a origem e a documentação antes de corrigir.',
            birthA[0],birthB[0],{priorSrc:priorRow.src,priorLine:priorRow.line});
        }
      }
      for(const field of mandatoryFields){
        const missingIds=p.ids.filter(i=>!filled(eligible[i][field]));
        if(missingIds.length)add('EDP15',missingIds[0],field,'Campo obrigatório não preenchido em '+missingIds.length+' de '+p.ids.length+' registro(s) da matrícula.','Preenchimento obrigatório','Ausente',{missing:missingIds.length,total:p.ids.length});
      }
      const checkedNames=new Set(),checkedCpfs=new Set();
      for(const rowId of p.ids){
        const row=eligible[rowId],first=firstName(row.name),nameKey=norm(first);
        if(first&&!checkedNames.has(nameKey)){
          checkedNames.add(nameKey);
          if(letterCount(first)<2)add('EDP01.2',rowId,'name','O primeiro nome contém menos de duas letras. Confira se foi abreviado ou digitado incorretamente.','Pelo menos 2 letras',first,{first,letters:letterCount(first)});
        }
        if(!row.cpf)continue;
        const info=cpfShape(row.cpf),cpfKey=info.correct?info.digits:norm(info.raw);
        if(checkedCpfs.has(cpfKey))continue;
        checkedCpfs.add(cpfKey);
        if(!info.correct)add('EDP02.3',rowId,'cpf',info.count!==11?'O CPF informado tem '+info.count+' dígitos; o esperado é 11. Se a célula estiver numérica, confira se houve perda de zeros à esquerda.':'O CPF tem 11 dígitos, mas contém caracteres ou separadores fora do formato aceito.','11 dígitos',maskCpf(info.raw),{digits:info.count});
        else if(!validCpf(info.digits))add('EDP02.2',rowId,'cpf',/^(\d)\1{10}$/.test(info.digits)?'O CPF contém uma sequência de dígitos repetidos.':'Os dois dígitos verificadores não conferem pelo cálculo de módulo 11.','Dígitos verificadores válidos',maskCpf(info.raw),{digits:info.count});
      }
      const name=compareValue(p.profile.name),sex=compareValue(p.profile.sex),signal=name&&sex&&nameSignal(name[1],sex[0]);
      if(signal){
        const rowId=p.ids.find(i=>normalizeIdentity(eligible[i],'name')===name[0]&&normalizeIdentity(eligible[i],'sex')===sex[0]);
        if(rowId!==undefined)add('EDP01.3',rowId,'sex','O primeiro nome tem predominância estatística no outro sexo nas contagens publicadas pelo IBGE. É um alerta de revisão; o nome não comprova o sexo da pessoa.',signal.expected,signal.sex,signal);
      }
    }
    for(const [d,ids] of cpfs)if(ids.length>1)for(const id of ids)
      add('EDP02.4',id,'cpf',maskCpf(d)+' está associado a '+ids.length+' matrículas avaliadas.','',maskCpf(d),{linked:ids.length});
    for(let id=0;id<eligible.length;id++){
      if(id%5000===4999)yield {phase:'Avaliando regras por vínculo',done:id+1,total:eligible.length};
      const r=eligible[id],isInss=norm(r.inss)==='S',isPension=r.subgroup==='Pensionista';
      if(isPension)pensionBindings++;
      const good=f=>r.invalidDates?.includes(f)?'':r[f],birth=good('birth'),admission=good('admission'),enrollment=good('enrollment');
      if(r.exemption==='Isento'&&!isInss)add('EDP05',id,'inss','Isenção de IR: '+r.exempt+'. O indicador INSS deve estar como S.','',r.inss||'Não informado');
      if(r.group==='Assistidos'&&r.dead&&norm(r.benefitStatus)==='AT')add('EDP06',id,'death','Situação do benefício AT com óbito em '+dateDisplay(r.death)+'.','',dateDisplay(r.death));
      if(!isPension&&admission&&enrollment&&admission>enrollment)
        add('EDP07.1',id,'admission','A admissão na patrocinadora em '+dateDisplay(admission)+' é posterior à inscrição no plano em '+dateDisplay(enrollment)+'. Confira as duas datas do mesmo vínculo.',dateDisplay(enrollment),dateDisplay(admission));
      if(!isPension&&!isInss){
        const company=tenure(admission,ref,'months'),tvp=durationMonths(r.tvp);
        if(tvp===null||company===null)skippedTvp++;
        else if(tvp<company)add('EDP08',id,'tvp','O tempo de empresa apurado na patrocinadora é de '+durationText(company)+' e o TVP cadastrado é de '+durationText(tvp)+'. A apuração usa a data de admissão de '+dateDisplay(admission)+' até '+dateDisplay(ref)+'.',
          durationText(company),durationText(tvp),{company,tvp});
      }
      for(const f of dates){
        if(isPension&&contractDates.has(f))continue;
        const d=good(f);
        if(r.invalidDates?.includes(f))add('EDP07.4',id,f,'Não foi possível interpretar a data informada.','',r[f]);
        if(d&&d>ref)add('EDP07.2',id,f,'A data ultrapassa a referência de '+dateDisplay(ref)+'.',dateDisplay(ref),dateDisplay(d));
        if(f!=='birth'&&d&&birth&&d<birth)add('EDP07.3',id,f,'O campo precede a data de nascimento.',dateDisplay(birth),dateDisplay(d));
      }
      const photoAge=age(birth,photo);
      if(photoAge!==null&&photoAge>100)add('EDP07.5',id,'birth','A idade na fotografia é de '+photoAge+' anos completos, acima do limite de 100. Confira a data de nascimento.','Até 100 anos',dateDisplay(birth));
      if(!isPension&&photoAge!==null&&photoAge<16)add('EDP07.6',id,'birth','A idade na fotografia é de '+photoAge+' anos completos, abaixo do mínimo de 16. A regra não se aplica a pensionistas.','Pelo menos 16 anos',dateDisplay(birth));
      if(!isPension&&birth&&admission&&admission>=birth&&admission<yearsLater(birth,16))add('EDP07.7',id,'admission','Na data de admissão, a idade era de '+age(birth,admission)+' anos. O critério mínimo é de 16 anos completos.',dateDisplay(yearsLater(birth,16)),dateDisplay(admission));
    }
    return {version:VERSION,catalogVersion,contractRuleVersion,cpfRuleVersion,photo,ref,unit,marital,prior:previous?.photo||'',created:new Date().toISOString(),
      rows:eligible,issues,exits,meta:{excludedRows,exOnly:[...exKeys].filter(m=>!index.has(m)).length,noKey,removed,unclassified,unknownExempt,skippedTvp,pensionBindings,
        comparablePeople:compared.size,compareCounts,people:index.size,readRows:rows.length}};
  }
  function validate(...args){const g=evaluation(...args);let step;do{step=g.next();}while(!step.done);return step.value;}
  async function validateAsync(rows,prior,options,progress=()=>{}){
    const g=evaluation(rows,prior,options);let step=g.next();
    while(!step.done){progress(step.value);await new Promise(r=>setTimeout(r,0));step=g.next();}
    return step.value;
  }
  function evidence(run,item){
    const r=run.rows[item.id],code=item.code,f=item.facts||{},field=item.field;
    const cells=(...items)=>items,old=item.before||'',current=item.after||'';
    const storedDate=k=>r[k]||'';
    const commonDate=(heading,k)=>[heading,storedDate(k),'date'];
    if(code==='EDP07.8')return cells(['Fotografia anterior',run.prior,'date'],['Fotografia atual',run.photo,'date'],['Nascimento anterior',old,'date'],
      ['Nascimento atual',current,'date'],['Origem anterior',f.priorSrc],['Linha anterior',f.priorLine]);
    if(monthlyCodes.includes(code))return cells(
      ['Fotografia anterior',run.prior,'date'],['Fotografia atual',run.photo,'date'],
      [labels[field]+' anterior',old],[labels[field]+' na fotografia atual',current]);
    switch(code){
      case 'EDP15':return cells(['Campo obrigatório',labels[field]],['Valor na origem',r[field]||''],['Resultado','Ausente'],
        ['Registros da matrícula sem o campo',f.missing],['Registros da matrícula avaliados',f.total]);
      case 'EDP01.2':return cells(['Nome avaliado',r.name],['Primeiro nome',f.first||current],['Letras no primeiro nome',f.letters??letterCount(f.first||current)],['Mínimo de letras',2]);
      case 'EDP01.3':return cells(['Nome avaliado',r.name],['Primeiro nome',f.first||firstName(r.name)],['Sexo cadastrado',r.sex],['Sexo predominante na amostra',f.expected||old],
        ['Predominância nas contagens publicadas',Number.isFinite(f.share)?(f.share*100).toFixed(1).replace('.',',')+'%':''],['Referência estatística','IBGE · Censo 2010']);
      case 'EDP02.2':
      case 'EDP02.3':
      case 'EDP02.4':return cells(['CPF informado (mascarado)',current||(code==='EDP02.4'?item.detail?.match(/^\*\*\*\.\*\*\*\.\*\*\*-\d{2}/)?.[0]:null)||maskCpf(r.cpf)],
        ['Dígitos informados',f.digits??(code==='EDP02.4'?11:cpfShape(r.cpf).count)],
        ...(code==='EDP02.4'?[['Matrículas vinculadas',f.linked??(Number(item.detail?.match(/associado a (\d+)/)?.[1]||0)||'')]]:[['Dígitos esperados',11]]));
      case 'EDP05':return cells(['Tipo de Isenção',r.exempt],['Flag INSS',r.inss],['Flag INSS esperado','S']);
      case 'EDP06':return cells(commonDate('Data de óbito registrada','death'),['Situação do benefício',r.benefitStatus],['Tipo de benefício',r.benefit]);
      case 'EDP07.1':return cells(commonDate('Data de admissão','admission'),commonDate('Data de inscrição no plano','enrollment'));
      case 'EDP07.2':return cells(['Data avaliada',storedDate(field),'date'],['Data de referência da avaliação',run.ref,'date']);
      case 'EDP07.3':return cells(['Data avaliada',storedDate(field),'date'],commonDate('Data de nascimento de referência','birth'));
      case 'EDP07.4':return cells(['Valor original da data (texto)',current||r[field]],['Formato aceito','DD/MM/AAAA, AAAA-MM-DD ou data do Excel']);
      case 'EDP07.5':
      case 'EDP07.6':return cells(commonDate('Data de nascimento avaliada','birth'),['Data da fotografia',run.photo,'date'],['Idade calculada na fotografia',age(r.birth,run.photo)],
        [code==='EDP07.5'?'Limite máximo (anos)':'Limite mínimo (anos)',code==='EDP07.5'?100:16]);
      case 'EDP07.7':return cells(commonDate('Data de nascimento de referência','birth'),commonDate('Data de admissão avaliada','admission'),
        ['Data em que completou 16 anos',yearsLater(r.birth,16),'date'],['Idade na admissão',age(r.birth,r.admission)],['Idade mínima na admissão',16]);
      case 'EDP08':return cells(commonDate('Data de admissão','admission'),['Data de referência da avaliação',run.ref,'date'],['Flag INSS',r.inss],
        ['TVP da base',r.tvp],['TVP cadastrado (meses)',f.tvp??durationMonths(current)],['Tempo de empresa apurado (meses)',f.company??durationMonths(old)]);
      case 'EDP13':return cells(['Valores diferentes observados',Array.isArray(f.variants)?f.variants.join(' / '):item.detail?.replace(/^Valores diferentes no mesmo mês: /,'')||'']);
      default:return cells(['Valor de referência',old],['Valor avaliado',current]);
    }
  }
  return {VERSION,catalogVersion,fields,labels,dates,enrichable,rules,byCode,families,canonicalCode,ruleMatches,monthlyCodes,contractRuleVersion,pensionSensitive,cpfRuleVersion,cpfShapeSensitive,unitLabel,defaultMarital,str,norm,val,key,date,dateDisplay,monthOf,priorMonth,today,age,tenure,durationMonths,durationText,cpf,cpfShape,validCpf,maskCpf,firstName,letterCount,nameSignal,evidence,civil,exemption,excluded,mapHeaders,materialize,addEnrichment,validate,validateAsync};
});
