(function(root,factory){
  const node=typeof module==='object'&&module.exports,api=factory(node?require('./regras.js'):root.PicPessoal);
  if(node)module.exports=api;else root.PicPessoalQuery=api;
})(globalThis,function(R){
  'use strict';
  const dims=['group','subgroup','plan','sponsor','band','dead','benefitStatus','inss','exemption'];
  function value(r,k){
    if(k==='dead')return r.dead?'Com data de óbito':'Sem data de óbito';
    if(k==='inss')return r.inss||'Não informado';
    return r[k]||'Não informado';
  }
  function searchMatch(r,needle){
    return !needle||R.norm(r.name).includes(needle)||R.norm(r.mat).includes(needle)||/^\d+$/.test(needle)&&r.key.includes(R.key(needle));
  }
  function basic(r,f,skip='',needle=''){
    if(f.person&&r.key!==f.person)return false;
    for(const k of dims)if(k!==skip&&f[k]&&value(r,k)!==f[k])return false;
    return searchMatch(r,needle);
  }
  const matchesIssue=(item,f)=>R.ruleMatches(item.code,f.rule)&&(!f.severity||R.byCode[item.code].severity===f.severity);
  function facets(run,f){
    const needle=R.norm(f.search),sets=Object.fromEntries(dims.map(k=>[k,new Set()])),active=dims.filter(k=>f[k]);
    const hitPeople=new Set(),hitRows=new Set(),constrained=Boolean(f.rule||f.status||f.severity);
    if(constrained)for(const item of run.issues){
      if(!matchesIssue(item,f))continue;
      if(R.byCode[item.code].grain==='Pessoa')hitPeople.add(run.rows[item.id].key);else hitRows.add(item.id);
    }
    for(let id=0;id<run.rows.length;id++){
      const r=run.rows[id];
      if(f.person&&r.key!==f.person||!searchMatch(r,needle))continue;
      if(constrained){
        const has=hitPeople.has(r.key)||hitRows.has(id);
        if(f.status==='Sem achado'?has:!has)continue;
      }
      let mismatched='',outside=false;
      for(const k of active)if(value(r,k)!==f[k]){
        if(mismatched){outside=true;break;}
        mismatched=k;
      }
      if(outside)continue;
      if(mismatched)sets[mismatched].add(value(r,mismatched));
      else for(const k of dims)sets[k].add(value(r,k));
    }
    return Object.fromEntries(dims.map(k=>[k,[...sets[k]].sort((a,b)=>a.localeCompare(b,'pt-BR',{numeric:true}))]));
  }
  function view(run,f={}){
    const rows=run.rows,pass=new Uint8Array(rows.length),representative=new Map(),needle=R.norm(f.search);
    for(let i=0;i<rows.length;i++)if(basic(rows[i],f,'',needle)){
      pass[i]=1;if(!representative.has(rows[i].key))representative.set(rows[i].key,i);
    }
    const list=[],affected=new Set(),affectedError=new Set(),affectedAlert=new Set(),personHits=new Set(),byRule=new Map(),hitRows=new Set(),withErrorRows=new Set(),personErrors=new Set();
    let errors=0,alerts=0;
    for(const item of run.issues){
      if(!matchesIssue(item,f))continue;
      const source=rows[item.id],person=R.byCode[item.code].grain==='Pessoa';
      const id=person?representative.get(source.key):pass[item.id]?item.id:undefined;
      if(id===undefined)continue;
      list.push({item,id});
      affected.add(source.key);
      if(person)personHits.add(source.key);else hitRows.add(id);
      if(R.byCode[item.code].severity==='Alerta'){affectedAlert.add(source.key);alerts++;}
      else{affectedError.add(source.key);errors++;if(person)personErrors.add(source.key);else withErrorRows.add(id);}
      byRule.set(item.code,(byRule.get(item.code)||0)+1);
    }
    const people=new Set(),dead=new Set(),scoped=[],activeCases=f.status==='Sem achado'?[]:list;
    for(let i=0;i<rows.length;i++){
      if(!pass[i])continue;
      const r=rows[i],has=personHits.has(r.key)||hitRows.has(i);
      if((f.rule||f.severity||f.status==='Com achado')&&!has||f.status==='Sem achado'&&has)continue;
      scoped.push(i);people.add(r.key);if(r.dead)dead.add(r.key);
    }
    const outAffected=new Set();
    if(f.status!=='Sem achado')for(const k of affected)if(people.has(k))outAffected.add(k);
    const noIssues=f.status==='Sem achado';
    return {ids:scoped,cases:activeCases,byRule:noIssues?new Map():byRule,people:people.size,bindings:scoped.length,
      affected:outAffected.size,affectedError:noIssues?0:affectedError.size,affectedAlert:noIssues?0:affectedAlert.size,
      errors:noIssues?0:errors,alerts:noIssues?0:alerts,dead:dead.size,issues:activeCases.length,representative,personErrors:noIssues?new Set():personErrors,withErrorRows:noIssues?new Set():withErrorRows};
  }
  function segment(run,v,k){
    const groups=new Map();
    for(const id of v.ids){
      const r=run.rows[id],label=value(r,k);
      let g=groups.get(label);
      if(!g){g={total:new Set(),affected:new Set(),bindings:0};groups.set(label,g);}
      g.total.add(r.key);g.bindings++;
      if(v.personErrors.has(r.key)||v.withErrorRows.has(id))g.affected.add(r.key);
    }
    return [...groups.entries()].map(([label,g])=>({label,people:g.total.size,affected:g.affected.size,bindings:g.bindings}))
      .sort((a,b)=>b.affected-a.affected||b.people-a.people||a.label.localeCompare(b.label,'pt-BR'));
  }
  function evidenceKey(run,item){
    const r=run.rows[item.id];
    const binding=R.byCode[item.code].grain==='Pessoa'?[]:[r.plan,r.sponsor,r.sponsorMat,r.benefit].map(R.norm);
    return JSON.stringify([r.key,...binding,item.code,item.field,item.before,item.after,item.detail]);
  }
  function upgradeMark(key){
    if(typeof key!=='string')return key;
    try{const parts=JSON.parse(key),i=parts.length-5;parts[i]=R.canonicalCode(parts[i]);return JSON.stringify(parts);}catch{return key;}
  }
  function ranking(run,v,limit=8){
    const people=new Map();
    for(const {id,item} of v.cases){
      if(R.byCode[item.code].severity!=='Erro')continue;
      const r=run.rows[id],old=people.get(r.key);
      if(old)old.count++;
      else people.set(r.key,{label:r.mat,title:r.name||'Matrícula '+r.mat,count:1,key:r.key});
    }
    return [...people.values()].sort((a,b)=>b.count-a.count||a.title.localeCompare(b.title,'pt-BR')||a.key.localeCompare(b.key)).slice(0,limit);
  }
  function matchKey(run,item){
    const r=run.rows[item.id];
    const binding=R.byCode[item.code].grain==='Pessoa'?[]:[r.plan,r.sponsor,r.sponsorMat,r.benefit].map(R.norm);
    return JSON.stringify([r.key,...binding,item.code,item.field]);
  }
  function movement(run,v,previous,p){
    const balance=new Map();
    for(const {item} of p.cases){const k=matchKey(previous,item);balance.set(k,(balance.get(k)||0)+1);}
    const incoming=[];
    for(const c of v.cases){
      const k=matchKey(run,c.item),n=balance.get(k)||0;
      if(n)balance.set(k,n-1);else incoming.push(c);
    }
    const outgoing=[];
    for(const c of p.cases){
      const k=matchKey(previous,c.item),n=balance.get(k)||0;
      if(n){outgoing.push(c);balance.set(k,n-1);}
    }
    return {incoming,outgoing,stable:v.cases.length-incoming.length};
  }
  return {dims,value,view,facets,segment,evidenceKey,upgradeMark,movement,ranking};
});
