(function(root,factory){
  const node=typeof module==='object'&&module.exports,api=factory(node?require('./regras.js'):root.PicPessoal);
  if(node)module.exports=api;else root.PicPessoalMoves=api;
})(globalThis,function(R){
  'use strict';
  const dims=['plan','sponsor','situation'];
  const types={entrada:'Entrada na fotografia',saida:'Saída cadastral documentada',situacao:'Mudança de situação',vinculo:'Mudança de vínculos',ausente:'Não localizado no mês atual',pensao:'Pensionista não localizado',ambiguo:'Vínculo não comparável'};
  const text=v=>R.str(v)||'Não informado';
  const code=(r,k)=>R.norm(r[k]);
  const situacao=r=>[r.situation,r.group,r.subgroup].map(R.norm).join('|');
  const pension=r=>r.pension===true||R.norm(r.subgroup)==='PENSIONISTA'||/^PENSIONISTAS?$/.test(R.norm(r.situation));
  const baseKey=r=>code(r,'plan')&&code(r,'sponsor')?JSON.stringify([code(r,'plan'),code(r,'sponsor')]):'';
  const fullKey=r=>baseKey(r)?JSON.stringify([baseKey(r),R.key(r.sponsorMat)]):'';
  const markerKey=r=>fullKey(r)?JSON.stringify([r.key,fullKey(r)]):'';
  function groupBy(rows,key){
    const out=new Map();
    for(const row of rows){const k=key(row),old=out.get(k);if(old)old.push(row);else out.set(k,[row]);}
    return out;
  }
  const flow=(kind,before,after,note,review=false,marker=null)=>({kind,before,after,note,review,marker,key:(after[0]||before[0]).key});
  function compare(current,previous){
    if(!current||!previous||R.priorMonth(current.photo)!==R.monthOf(previous.photo))return null;
    const old=groupBy(previous.rows,r=>r.key),now=groupBy(current.rows,r=>r.key);
    const exitMap=new Map();
    for(const r of current.exits||[]){
      const k=markerKey(r);
      if(!k||!R.excluded(r.situation))continue;
      if(!exitMap.has(k))exitMap.set(k,r);
      else if(!exitMap.get(k)||pension(exitMap.get(k))!==pension(r))exitMap.set(k,null);
    }
    const people=[],bindings=[];
    const inPeriod=d=>d&&/^\d{4}-\d\d-\d\d$/.test(d)&&d>previous.photo&&d<=current.photo;
    for(const id of new Set([...old.keys(),...now.keys()])){
      const a=old.get(id)||[],b=now.get(id)||[],own=[];
      const left=groupBy(a,baseKey),right=groupBy(b,baseKey);
      function handle(before,after){
        if(before.length>1||after.length>1||!fullKey((after[0]||before[0]))){
          own.push(flow('ambiguo',before,after,'Chave de vínculo incompleta ou repetida; não foi inferida entrada, saída ou alteração.',true));return;
        }
        if(!before.length){
          const r=after[0],enrolled=!pension(r)&&!r.invalidDates?.includes('enrollment')&&inPeriod(r.enrollment);
          own.push(flow('entrada',before,after,enrolled?'Inscrição registrada no intervalo: '+R.dateDisplay(r.enrollment)+'.':'Vínculo localizado apenas na fotografia atual, sem evento cadastral confirmado.',!enrolled));
        }else if(!after.length){
          const r=before[0],marker=exitMap.get(markerKey(r));
          if(pension(r))own.push(flow('pensao',before,after,'Vínculo de pensão não localizado. O cadastro não dispõe de situação Ex-Pensionista para confirmar saída.',true));
          else if(marker&&!pension(marker))own.push(flow('saida',before,after,'O mesmo vínculo consta como Ex-Participante na extração atual.',false,marker));
          else own.push(flow('ausente',before,after,'Vínculo não localizado e sem registro Ex-Participante correspondente.',true));
        }else if(situacao(before[0])!==situacao(after[0])){
          own.push(flow('situacao',before,after,'Alteração observada na situação do mesmo vínculo. As fotografias não comprovam o motivo.',true));
        }
      }
      for(const k of new Set([...left.keys(),...right.keys()])){
        const x=left.get(k)||[],y=right.get(k)||[];
        if(!k){handle(x,y);continue;}
        // One row on either side allows a missing sponsor registration to be filled without inventing a movement.
        if(x.length===1&&y.length===1&&(!R.key(x[0].sponsorMat)||!R.key(y[0].sponsorMat))){handle(x,y);continue;}
        if((x.length>1||y.length>1)&&[...x,...y].some(r=>!R.key(r.sponsorMat))){
          own.push(flow('ambiguo',x,y,'Matrícula na patrocinadora ausente em um grupo com mais de um vínculo possível.',true));continue;
        }
        const xx=groupBy(x,fullKey),yy=groupBy(y,fullKey);
        for(const match of new Set([...xx.keys(),...yy.keys()]))handle(xx.get(match)||[],yy.get(match)||[]);
      }
      if(!own.length)continue;
      for(const item of own)bindings.push(item);
      if(!a.length){
        const hasEntry=own.some(e=>e.kind==='entrada'),confirmed=own.some(e=>e.kind==='entrada'&&!e.review);
        people.push(flow('entrada',a,b,confirmed?'Pessoa não localizada na fotografia anterior; há inscrição de vínculo no intervalo.':
          hasEntry?'Pessoa localizada apenas na fotografia atual. Não há evento cadastral confirmado.':'Pessoa localizada apenas na fotografia atual; os vínculos não puderam ser conciliados.',!confirmed));
      }else if(!b.length){
        const allPension=a.every(pension),confirmed=own.every(e=>e.kind==='saida');
        const marker=confirmed?own[0].marker:null;
        people.push(flow(confirmed?'saida':allPension?'pensao':'ausente',a,b,confirmed?'Todos os vínculos anteriores constam como Ex-Participante na extração atual.':
          allPension?'Pessoa com vínculo de pensão não localizada. A saída não pode ser verificada.':'Pessoa não localizada na fotografia atual; nem todos os vínculos têm saída documentada.',!confirmed,marker));
      }else{
        const status=own.some(e=>e.kind==='situacao'),changed=own.some(e=>!['ambiguo','situacao'].includes(e.kind));
        people.push(flow(status?'situacao':changed?'vinculo':'ambiguo',a,b,status?'A pessoa permanece na base; mudou a situação de pelo menos um vínculo conciliado.':
          changed?'A pessoa permanece na base; houve mudança no conjunto de vínculos localizados.':'A pessoa permanece na base, mas há vínculos sem correspondência única.',own.some(e=>e.review)));
      }
    }
    return {previous,current,people,bindings,legacy:!Array.isArray(current.exits)};
  }
  function matches(r,f){
    return dims.every(k=>!f[k]||code(r,k)===f[k]);
  }
  function query(result,grain='people',f={}){
    const list=result[grain],counts={entrada:0,saida:0,situacao:0,review:0,pensao:0};
    const scoped=list.filter(e=>e.before.some(r=>matches(r,f))||e.after.some(r=>matches(r,f)));
    for(const e of scoped){if(Object.hasOwn(counts,e.kind))counts[e.kind]++;if(e.review)counts.review++;}
    const queryText=R.norm(f.search),qkey=/^\d+$/.test(queryText)?R.key(queryText):'';
    const rows=scoped.filter(e=>(!f.kind||(f.kind==='review'?e.review:e.kind===f.kind))&&(!queryText||e.key===qkey||
      [...e.before,...e.after].some(r=>R.norm(r.name).includes(queryText)||R.norm(r.mat).includes(queryText))));
    const stock=run=>{
      if(grain==='bindings')return run.rows.reduce((n,r)=>n+(matches(r,f)?1:0),0);
      return new Set(run.rows.filter(r=>matches(r,f)).map(r=>r.key)).size;
    };
    return {rows,counts,prior:stock(result.previous),current:stock(result.current)};
  }
  function options(result,k){
    const values=new Map();
    for(const run of [result.current,result.previous])for(const r of run.rows){
      const label=text(r[k]),key=code(r,k);if(key&&!values.has(key))values.set(key,label);
    }
    return [...values].sort((a,b)=>a[1].localeCompare(b[1],'pt-BR'));
  }
  return {compare,query,options,types,dims};
});
