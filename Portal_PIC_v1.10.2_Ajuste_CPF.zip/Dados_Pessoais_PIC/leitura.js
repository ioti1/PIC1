(function(root,factory){
  const node=typeof module==='object'&&module.exports,api=factory(node?require('./regras.js'):root.PicPessoal,node?require('../Central_Validacao_v4.2.2/vendor/jszip.min.js'):root.JSZip);
  if(node)module.exports=api;else root.PicPessoalIO=api;
})(globalThis,function(R,Zip){
  'use strict';
  const LIMIT=350*1024*1024;
  const pause=()=>new Promise(r=>setTimeout(r,0));
  function decode(s){
    return String(s??'').replace(/&(#x[0-9a-f]+|#\d+|lt|gt|amp|quot|apos);/gi,(all,x)=>{
      if(x[0]!=='#')return ({lt:'<',gt:'>',amp:'&',quot:'"',apos:"'"})[x]||all;
      const n=x[1].toLowerCase()==='x'?parseInt(x.slice(2),16):Number(x.slice(1));
      return n>=0&&n<=0x10ffff?String.fromCodePoint(n):all;
    });
  }
  function attr(s,key){return decode(s.match(new RegExp('(?:^|\\s)'+key+'=["\']([^"\']*)["\']'))?.[1]||'');}
  function text(xml){return [...xml.matchAll(/<(?:\w+:)?t\b[^>]*>([\s\S]*?)<\/(?:\w+:)?t>/g)].map(m=>decode(m[1])).join('');}
  function col(ref){let n=0;for(const ch of ref.match(/^[A-Z]+/)?.[0]||'A')n=n*26+ch.charCodeAt(0)-64;return n-1;}
  function cells(xml,strings){
    const out=[];
    for(const [,attrs,body=''] of xml.matchAll(/<(?:\w+:)?c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/(?:\w+:)?c>)/g)){
      const ref=attr(attrs,'r');if(!ref)continue;
      const t=attr(attrs,'t'),v=decode(body.match(/<(?:\w+:)?v\b[^>]*>([\s\S]*?)<\/(?:\w+:)?v>/)?.[1]||'');
      const value=t==='inlineStr'?text(body):t==='s'?(strings[+v]||''):v;
      if(value!=='')out[col(ref)]={v:value,num:!t||t==='n'};
    }
    return out;
  }
  // JSZip streams decoded XML in chunks. Only a partial row and the current
  // file's shared strings are retained, not a duplicate worksheet matrix.
  function streamElements(entry,name,handle){
    return new Promise((resolve,reject)=>{
      const start=new RegExp('<(?:\\w+:)?'+name+'(?=[\\s/>])');
      const end=new RegExp('<\\/(?:\\w+:)?'+name+'\\s*>');
      const stream=entry.internalStream('string');
      let buf='',failed=false;
      stream.on('data',(chunk,info)=>{
        if(failed)return;
        try{
          buf+=chunk;
          let p=0;
          while(p<buf.length){
            const ix=buf.slice(p).search(start);
            if(ix<0){p=Math.max(p,buf.length-128);break;}
            const begin=p+ix,gt=buf.indexOf('>',begin);
            if(gt<0){p=begin;break;}
            const empty=buf[gt-1]==='/';
            const closing=empty?null:end.exec(buf.slice(gt+1));
            if(!empty&&!closing){p=begin;break;}
            const stop=empty?gt+1:gt+1+closing.index+closing[0].length;
            handle(buf.slice(begin,gt+1),empty?'':buf.slice(gt+1,gt+1+closing.index),info.percent);
            p=stop;
          }
          buf=buf.slice(p);
          if(buf.length>8*1024*1024)throw Error('Linha ou texto XLSX excede o limite de leitura.');
        }catch(error){failed=true;stream.pause();reject(error);}
      });
      stream.on('error',reject).on('end',()=>{if(!failed)resolve();}).resume();
    });
  }
  async function read(file,role,onRow,onProgress=()=>{}){
    if(!/\.xlsx$/i.test(file.name)||file.size>LIMIT)throw Error('Selecione um arquivo XLSX de até 350 MB por parte.');
    const zip=await Zip.loadAsync(await file.arrayBuffer());
    const workbook=zip.file('xl/workbook.xml'),rels=zip.file('xl/_rels/workbook.xml.rels');
    if(!workbook||!rels)throw Error('Estrutura XLSX inválida: '+file.name);
    const [w,r]=await Promise.all([workbook.async('string'),rels.async('string')]);
    const excel1904=/<(?:\w+:)?workbookPr\b[^>]*\bdate1904=["'](?:1|true)["']/i.test(w);
    const lookup=new Map([...r.matchAll(/<(?:\w+:)?Relationship\b[^>]*>/g)].map(m=>[attr(m[0],'Id'),attr(m[0],'Target')]));
    const sheets=[...w.matchAll(/<(?:\w+:)?sheet\b[^>]*>/g)].map(m=>({name:attr(m[0],'name'),target:lookup.get(attr(m[0],'r:id'))||''}));
    const strings=[],shared=zip.file('xl/sharedStrings.xml');
    if(shared)await streamElements(shared,'si',(_,body)=>{if(strings.length>=2500000)throw Error('O catálogo de textos excede o limite. Divida a base em mais partes.');strings.push(text(body));});
    let total=0,matched=0,best=[],descriptions=[];
    for(const sheet of sheets){
      const target=sheet.target.startsWith('/')?sheet.target.slice(1):sheet.target.startsWith('xl/')?sheet.target:'xl/'+sheet.target;
      const entry=zip.file(target);
      if(!entry)continue;
      let map=null,n=0,rows=0;
      await streamElements(entry,'row',(attrs,xml,percent)=>{
        n++;
        if(!map&&n>30)return;
        const raw=cells(xml,strings);
        if(!map){
          const candidate=R.mapHeaders(Array.from(raw,c=>c?.v||''));
          if(Object.keys(candidate).length>best.length)best=Object.keys(candidate);
          const valid=role==='base'?R.fields.every(f=>!f.required||candidate[f.id]!=null):
            candidate.mat!=null&&R.enrichable.some(f=>candidate[f]!=null);
          if(valid){map=candidate;matched++;descriptions.push({sheet:sheet.name,map});}
          return;
        }
        if(!raw.some(c=>c?.v?.trim()))return;
        if(++total>1200000)throw Error('O arquivo ultrapassa 1.200.000 linhas úteis. Divida a base em partes.');
        rows++;
        onRow(R.materialize(raw,map,file.name+' / '+sheet.name,Number(attr(attrs,'r'))||n,excel1904));
        if(rows%4000===0)onProgress({file:file.name,sheet:sheet.name,rows,percent:Math.round(percent||0)});
      });
      if(map)onProgress({file:file.name,sheet:sheet.name,rows,percent:100});
      await pause();
    }
    if(!matched){
      const missing=R.fields.filter(f=>f.required&&!best.includes(f.id)).map(f=>f.label);
      throw Error(role==='base'?'Nenhuma aba de '+file.name+' tem o cabeçalho da base principal. Campos ausentes: '+missing.join(', ')+'.':
        'O complemento '+file.name+' precisa de Matrícula Petros e ao menos um campo pessoal reconhecido.');
    }
    return {total,sheets:descriptions};
  }
  async function combine(files,extras,onProgress=()=>{}){
    const rows=[], sources=[],links=new Map(),extrasSources=[];
    for(const file of files){
      const data=await read(file,'base',row=>{if(rows.length>=1200000)throw Error('O processamento atingiu o limite de 1.200.000 linhas úteis.');rows.push(row);},onProgress);
      sources.push({name:file.name,total:data.total,sheets:data.sheets.map(s=>s.sheet)});
    }
    if(!rows.length)throw Error('Nenhuma linha de dados foi encontrada nas bases selecionadas.');
    let enrichment={enriched:0,conflicts:0};
    if(extras.length){
      const keys=new Set(rows.filter(r=>r.key&&!r.ex).map(r=>r.key));
      let unmatched=0;
      for(const file of extras){
        const data=await read(file,'extra',r=>{
          if(!r.key||!keys.has(r.key)){unmatched++;return;}
          let m=links.get(r.key);if(!m){m={};links.set(r.key,m);}
          for(const f of R.enrichable)if(r[f]&&!r.invalidDates?.includes(f)&&(f!=='cpf'||r.cpfKey)){
            const v=f==='cpf'?r.cpfKey:r[f];
            const set=(m[f]||=new Set());if(set.size<2)set.add(v);
          }
        },onProgress);
        extrasSources.push({name:file.name,total:data.total});
      }
      enrichment={...R.addEnrichment(rows,links),unmatched};
    }
    return {rows,sources,extrasSources,enrichment};
  }
  return {read,combine,streamElements};
});
