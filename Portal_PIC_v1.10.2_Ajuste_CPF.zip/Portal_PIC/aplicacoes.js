(function(root){
  'use strict';
  const KEY='pic.portal.cards.v1',MAX=24,DEFAULT_FILE='PIC_Atalhos.json',LOADER_FILE='atalhos-padrao.js';
  const builtIn={"version":2,"revision":"pic-v17","cards":[{"id":"pessoais","name":"Dados Pessoais","bi":"../Dados_Pessoais_PIC/painel.html","operational":"../Dados_Pessoais_PIC/index.html","icon":"personal"},{"id":"comunicacao","name":"Meios de Comunicação","bi":"../Painel_Comunicacao_PIC/index.html","operational":"../Central_Validacao_v4.2.2/index.html","icon":"communication"},{"id":"futuro-1","name":"A criar","bi":"","operational":"","icon":"pending"},{"id":"futuro-2","name":"A criar","bi":"","operational":"","icon":"pending"}]};
  const defaults=builtIn.cards;
  const icons={
    personal:'<rect x="4.5" y="6" width="23" height="20" rx="3"/><circle cx="12" cy="13" r="2.4"/><path d="M7.7 21a4.4 4.4 0 0 1 8.6 0m3-8h4.6m-4.6 5h4.6"/>',
    communication:'<rect x="4.7" y="9.1" width="22.6" height="15.5" rx="3"/><path d="m6.2 11 8.2 6.6a2.5 2.5 0 0 0 3.2 0l8.2-6.6m-18.6 9.9 3.5-3m14.1 3-3.5-3"/><path d="M12.7 5.8a7.2 7.2 0 0 1 6.6 0"/>',
    pending:'<path d="M16 7v18M7 16h18"/>',
    generic:'<rect x="6" y="6" width="20" height="20" rx="4"/><path d="M10 14h12m-12 4h12m-12 4h7"/>',
    pencil:'<path d="m19.6 6.8 5.6 5.6M6 26l6-1.4L26.4 10a3.9 3.9 0 0 0-5.5-5.5L7.4 19.9 6 26Z"/>'
  };
  const svg=type=>'<svg viewBox="0 0 32 32" aria-hidden="true">'+icons[type]+'</svg>';
  const covers=Object.freeze({personal:'assets/card-dados-pessoais.png',communication:'assets/card-meios-comunicacao.png'});
  const pathname=path=>path.split('/').map(part=>part==='.'||part==='..'?part:encodeURIComponent(part).replace(/%25([0-9a-f]{2})/ig,'%$1')).join('/');
  function destination(path,base){
    const s=String(path??'').trim().replace(/^"(.*)"$/,'$1');
    if(!s)return '';
    if(s.length>1024||/[\u0000-\u001F\u007F]/.test(s))throw Error('Informe um caminho local de até 1.024 caracteres.');
    const clean=s.replaceAll('\\','/');
    let url;
    if(/^file:\/\//i.test(clean))url=new URL(clean);
    else if(/^[A-Za-z]:\//.test(clean))url=new URL('file:///'+clean.slice(0,2)+pathname(clean.slice(2)));
    else if(clean.startsWith('//'))url=new URL('file:'+pathname(clean));
    else{
      if(/^[A-Za-z][A-Za-z\d+.-]*:/.test(clean))throw Error('Use um arquivo HTML local. Endereços externos não são aceitos.');
      url=new URL(pathname(clean),base);
    }
    const pathText=decodeURIComponent(url.pathname);
    if(url.protocol!=='file:'||url.username||url.password||url.search||url.hash||!/\.html?$/i.test(pathText)||/[\u0000-\u001F\u007F]/.test(pathText))throw Error('O caminho deve apontar para um arquivo local .html ou .htm.');
    return url.href;
  }
  function parseConfig(raw,base){
    if(![1,2].includes(raw?.version)||!Array.isArray(raw.cards)||!raw.cards.length||raw.cards.length>MAX)throw Error('Configuração PIC inválida.');
    const seen=new Set(),cards=raw.cards.map(c=>{
      if(!c||typeof c.id!=='string'||!/^[a-z\d-]{1,60}$/.test(c.id)||seen.has(c.id)||typeof c.name!=='string'||!c.name.trim()||c.name.trim().length>65)throw Error('Há um cartão inválido ou duplicado na configuração.');
      const bi=raw.version===1?(defaults.find(d=>d.id===c.id)?.bi||''):c.bi,operational=raw.version===1?c.path:c.operational;
      for(const path of [bi,operational]){
        if(typeof path!=='string'||path.length>1024)throw Error('Há um caminho inválido na configuração.');
        destination(path,base);
      }
      seen.add(c.id);
      return {id:c.id,name:c.name.trim(),bi:bi.trim(),operational:operational.trim(),icon:['personal','communication','pending','generic'].includes(c.icon)?c.icon:'generic'};
    });
    return {version:2,revision:typeof raw.revision==='string'&&/^[a-z0-9_-]{1,80}$/i.test(raw.revision)?raw.revision:'importado-v1',cards};
  }
  const json=config=>JSON.stringify(config,null,2)+'\n';
  const loader=config=>'/* Gerado a partir de PIC_Atalhos.json. Carregado como script local, sem fetch. */\nglobalThis.PIC_ATALHOS_PADRAO='+JSON.stringify(config,null,2)+';\n';
  if(typeof module==='object'&&module.exports){module.exports={defaults,destination,parseConfig,json,loader};return;}

  const doc=root.document,$=id=>doc.getElementById(id),base=root.location.href;
  const editor=$('editor'),choice=$('card-choice'),name=$('card-name'),bi=$('card-bi'),operational=$('card-operational'),error=$('editor-error');
  const access=$('access'),accessBI=$('access-bi'),accessOperational=$('access-operational');
  let shared=builtIn,config=builtIn,editorTrigger=null,accessTrigger=null,stale=false;
  let accessCloseTimer=0,backdropPressed=false;
  const uid=()=>root.crypto?.randomUUID?.()||Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,10);
  const status=s=>{$('status').textContent=s;};
  function load(){
    try{if(root.PIC_ATALHOS_PADRAO)shared=parseConfig(root.PIC_ATALHOS_PADRAO,base);}
    catch{status('Padrão da pasta inválido. Os atalhos originais foram mantidos.');}
    config=shared;
    try{
      const raw=root.localStorage.getItem(KEY);if(!raw)return;
      const saved=JSON.parse(raw);
      if(saved.baseRevision===shared.revision||saved.version===1&&shared.revision===builtIn.revision)config=parseConfig(saved,base);
      else if(saved.baseRevision==='pic-v13'&&shared.revision==='pic-v17'){
        const updated=parseConfig(saved,base);
        const dp=shared.cards.find(c=>c.id==='pessoais');
        if(dp)updated.cards=updated.cards.map(c=>c.id==='pessoais'&&!c.bi&&!c.operational?{...c,bi:dp.bi,operational:dp.operational}:c);
        config=updated;persist();
      }
      else stale=true;
    }catch{status('Não foi possível ler os atalhos locais. O padrão da pasta foi mantido.');}
  }
  function persist(){
    try{root.localStorage.setItem(KEY,JSON.stringify({...config,baseRevision:shared.revision}));return true;}
    catch{return false;}
  }
  const el=(tag,cls,text)=>{const node=doc.createElement(tag);if(cls)node.className=cls;if(text!=null)node.textContent=text;return node;};
  function download(filename,data,type){
    const href=URL.createObjectURL(new Blob([data],{type})),a=el('a');a.href=href;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(href),1000);
  }
  const downloadJSON=()=>download(DEFAULT_FILE,json(config),'application/json');
  const downloadLoader=()=>download(LOADER_FILE,loader(config),'text/javascript');
  function openAccess(label,biHref,operationalHref,opener){
    if(access.open)return;
    accessTrigger=opener;
    backdropPressed=false;
    $('access-title').textContent=label;
    accessBI.href=biHref;
    accessOperational.href=operationalHref;
    access.showModal();
  }
  function closeAccess(){
    if(!access.open||access.classList.contains('is-closing'))return;
    if(root.matchMedia?.('(prefers-reduced-motion: reduce)').matches){access.close();return;}
    access.classList.add('is-closing');
    // Keep the native modal and focus trap active during the exit animation.
    accessCloseTimer=setTimeout(()=>{if(access.open)access.close();},240);
  }
  function onAccessBackdrop(event){
    if(event.target!==access)return false;
    const rect=access.getBoundingClientRect();
    return event.clientX<rect.left||event.clientX>rect.right||event.clientY<rect.top||event.clientY>rect.bottom;
  }
  function render(){
    const frag=doc.createDocumentFragment();
    for(const [i,c] of config.cards.entries()){
      const card=el('article','app-card'),biHref=destination(c.bi,base),opHref=destination(c.operational,base),primary=biHref||opHref;
      const available=Boolean(primary),hasChoice=Boolean(biHref&&opHref&&biHref!==opHref);
      const link=el(hasChoice?'button':available?'a':'div','app-link');
      if(hasChoice){
        link.type='button';
        link.setAttribute('aria-haspopup','dialog');
        link.setAttribute('aria-controls','access');
        link.addEventListener('click',()=>openAccess(c.name,biHref,opHref,link));
      }else if(available)link.href=primary;
      const icon=c.icon==='pending'&&available?'generic':c.icon,visual=el('span','tile '+icon);
      visual.innerHTML=svg(icon);
      if(covers[icon]){
        const cover=el('img','tile-cover');cover.alt='';cover.decoding='async';cover.width=1254;cover.height=1254;
        cover.addEventListener('error',()=>cover.remove());cover.src=covers[icon];visual.append(cover);
      }
      link.append(visual,el('span','app-name',c.name));
      card.append(link);
      if(!available){
        const edit=el('button','icon-btn card-edit');edit.type='button';edit.title='Configurar cartão';edit.setAttribute('aria-label','Configurar '+c.name+' ('+(i+1)+')');edit.innerHTML=svg('pencil');
        edit.addEventListener('click',()=>openEditor(c.id,edit));card.append(edit);
      }
      frag.append(card);
    }
    $('cards').replaceChildren(frag);
  }
  function options(id){
    choice.replaceChildren(...config.cards.map((c,i)=>{const o=el('option','',(i+1)+'. '+c.name);o.value=c.id;return o;}));
    if(config.cards.length<MAX){const o=el('option','','Novo cartão');o.value='';choice.append(o);}
    choice.value=id;
  }
  function populate(){
    const c=config.cards.find(item=>item.id===choice.value);
    name.value=c?.name||'';bi.value=c?.bi||'';operational.value=c?.operational||'';error.hidden=true;
    $('new-card').disabled=config.cards.length>=MAX;
  }
  function openEditor(id,opener){editorTrigger=opener;options(id);populate();editor.showModal();choice.focus();}
  function fail(e){error.textContent=e.message;error.hidden=false;}
  function draft(){
    const existing=config.cards.find(c=>c.id===choice.value);
    if(!existing&&config.cards.length>=MAX)throw Error('O limite é de 24 cartões.');
    const card={id:existing?.id||'app-'+uid(),name:name.value,bi:bi.value,operational:operational.value,icon:existing?.icon||'generic'};
    const cards=existing?config.cards.map(c=>c.id===existing.id?card:c):[...config.cards,card];
    return parseConfig({version:2,revision:uid(),cards},base);
  }
  async function write(dir,filename,data){
    const handle=await dir.getFileHandle(filename,{create:true}),stream=await handle.createWritable();
    try{await stream.write(data);await stream.close();}catch(e){await stream.abort().catch(()=>{});throw e;}
  }
  async function shareDefault(){
    error.hidden=true;
    if(!root.showDirectoryPicker){fail(Error('Neste navegador, baixe o JSON e o inicializador e coloque os dois na pasta Portal_PIC.'));return;}
    try{
      const next=draft();
      const dir=await root.showDirectoryPicker({mode:'readwrite',id:'pic-atalhos'});
      try{await dir.getFileHandle('aplicacoes.html');await dir.getFileHandle(LOADER_FILE);}
      catch{throw Error('Selecione a pasta Portal_PIC que contém aplicacoes.html e atalhos-padrao.js.');}
      await write(dir,DEFAULT_FILE,json(next));await write(dir,LOADER_FILE,loader(next));
      shared=config=next;persist();render();status('Padrão da pasta atualizado para as próximas aberturas.');editor.close();
    }catch(e){if(e.name!=='AbortError')fail(e);}
  }
  $('manage').addEventListener('click',()=>openEditor(config.cards[0]?.id||'',$('manage')));
  choice.addEventListener('change',populate);
  $('close-editor').addEventListener('click',()=>editor.close());
  editor.addEventListener('close',()=>{(editorTrigger?.isConnected?editorTrigger:$('manage')).focus();});
  $('close-access').addEventListener('click',closeAccess);
  access.addEventListener('cancel',event=>{event.preventDefault();closeAccess();});
  access.addEventListener('pointerdown',event=>{backdropPressed=event.button===0&&onAccessBackdrop(event);});
  access.addEventListener('pointercancel',()=>{backdropPressed=false;});
  access.addEventListener('click',event=>{
    if(backdropPressed&&onAccessBackdrop(event))closeAccess();
    backdropPressed=false;
  });
  access.addEventListener('animationend',event=>{
    if(event.target===access&&event.animationName==='access-out'&&access.open)access.close();
  });
  for(const link of [accessBI,accessOperational])link.addEventListener('click',event=>{
    if(event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;
    if(access.open)access.close();
  });
  access.addEventListener('close',()=>{
    clearTimeout(accessCloseTimer);accessCloseTimer=0;backdropPressed=false;
    access.classList.remove('is-closing');
    if(accessTrigger?.isConnected)accessTrigger.focus();accessTrigger=null;
  });
  $('new-card').addEventListener('click',()=>{choice.value='';populate();name.focus();});
  $('app-form').addEventListener('submit',event=>{
    event.preventDefault();error.hidden=true;
    try{
      config=draft();
      const saved=persist();render();downloadJSON();editor.close();
      status(saved?'Cartão salvo neste navegador. JSON gerado.':'JSON gerado. O navegador não guardou os atalhos; salve o padrão da pasta para reutilizá-los.');
    }catch(e){fail(e);}
  });
  $('save-default').addEventListener('click',shareDefault);
  $('download-loader').addEventListener('click',downloadLoader);
  $('download-config').addEventListener('click',downloadJSON);
  $('load-config').addEventListener('click',()=>$('config-file').click());
  $('config-file').addEventListener('change',async e=>{
    const file=e.target.files[0];if(!file)return;
    try{
      if(file.size>160*1024)throw Error('A configuração excede o tamanho esperado.');
      const next=parseConfig(JSON.parse(await file.text()),base);
      if(!root.confirm('Substituir os atalhos atuais pelos do arquivo selecionado?'))return;
      config=next;const saved=persist();render();options(config.cards[0].id);populate();
      status(saved?'JSON importado neste navegador.':'JSON importado nesta sessão. Salve o padrão da pasta para reutilizá-lo.');
    }catch(err){fail(err);}finally{e.target.value='';}
  });
  load();render();
  if(stale)status('Padrão da pasta atualizado.');
  setTimeout(()=>{
    const intro=$('launcher-intro');
    intro.classList.add('intro-fading');intro.setAttribute('aria-hidden','true');
    setTimeout(()=>intro.classList.add('intro-expired'),root.matchMedia?.('(prefers-reduced-motion: reduce)').matches?0:360);
  },7000);
})(globalThis);
