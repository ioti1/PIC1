/* Gerado a partir de PIC_Atalhos.json. Carregado como script local, sem fetch. */
globalThis.PIC_ATALHOS_PADRAO={
  "version": 2,
  "revision": "pic-v17",
  "cards": [
    {
      "id": "pessoais",
      "name": "Dados Pessoais",
      "bi": "../Dados_Pessoais_PIC/painel.html",
      "operational": "../Dados_Pessoais_PIC/index.html",
      "icon": "personal"
    },
    {
      "id": "comunicacao",
      "name": "Meios de Comunicação",
      "bi": "../Painel_Comunicacao_PIC/index.html",
      "operational": "../Central_Validacao_v4.2.2/index.html",
      "icon": "communication"
    },
    {
      "id": "futuro-1",
      "name": "A criar",
      "bi": "",
      "operational": "",
      "icon": "pending"
    },
    {
      "id": "futuro-2",
      "name": "A criar",
      "bi": "",
      "operational": "",
      "icon": "pending"
    }
  ]
};
