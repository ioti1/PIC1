(function(root){
  'use strict';
  const RAD=Math.PI/180,PERIOD=20000,FLIGHT=980,SPIN=7,PITCH_LIMIT=85;
  const clamp=(v,min,max)=>Math.min(max,Math.max(min,v)),wrap=v=>((v+180)%360+360)%360-180;
  const surface=(lat,lon)=>{const a=lat*RAD,b=lon*RAD;return [Math.cos(a)*Math.sin(b),Math.sin(a),Math.cos(a)*Math.cos(b)];};
  const yawAt=(turns,reduced=false)=>(-42+(reduced?0:turns%360))*RAD;
  function project([x,y,z],yaw,pitch=12*RAD){
    const a=x*Math.cos(yaw)-z*Math.sin(yaw),b=x*Math.sin(yaw)+z*Math.cos(yaw);
    return [a,y*Math.cos(pitch)-b*Math.sin(pitch),y*Math.sin(pitch)+b*Math.cos(pitch)];
  }
  function dragView(view,dx,dy){return {yaw:wrap(view.yaw-dx*.58),pitch:clamp(view.pitch+dy*.50,-PITCH_LIMIT,PITCH_LIMIT)};}
  function meteorAt(elapsed){
    if(elapsed<PERIOD||elapsed%PERIOD>=FLIGHT)return null;
    const t=(elapsed%PERIOD)/FLIGHT;
    return {x:1.12-2.20*t,y:-.56+.94*t,alpha:Math.min(1,t*10,(1-t)*7)*.76};
  }
  const wheelTurn=(e,overflow=false)=>overflow||e.ctrlKey?0:clamp(e.deltaY*(e.deltaMode===1?16:e.deltaMode===2?280:1)*.15,-35,35);
  function expandLand({bands=[],rings=[]}={}){
    const points=[],coasts=[];
    for(const [lat,slots,...runs] of bands)for(let i=0;i<runs.length;i+=2)
      for(let j=runs[i];j<=runs[i+1];j++)points.push(surface(lat,-180+(j+.5)*360/slots));
    for(const ring of rings){
      let line=[];
      for(let i=0;i<ring.length;i+=2){
        const lon=ring[i],lat=ring[i+1],prev=ring[i-2],prevLat=ring[i-1];
        // Polygon closure edges on the date line are not real coastlines.
        if(i&&(Math.abs(lon-prev)>180||Math.abs(lon)>=179.99&&Math.abs(prev)>=179.99||lat===-90&&prevLat===-90)){
          if(line.length>1)coasts.push(line);line=[];
        }
        line.push(surface(lat,lon));
      }
      if(line.length>1)coasts.push(line);
    }
    return {points,coasts};
  }
  if(typeof module==='object'&&module.exports){module.exports={yawAt,project,surface,dragView,wheelTurn,meteorAt,expandLand};return;}

  const doc=root.document;
  let modalOpen=false,resetTiming=()=>{};
  for(const button of doc.querySelectorAll('[data-info]')){
    const dialog=doc.getElementById(button.dataset.info);
    button.addEventListener('click',()=>{dialog.showModal();modalOpen=true;resetTiming();});
    dialog.addEventListener('close',()=>{modalOpen=false;resetTiming();button.focus();});
  }
  const canvas=doc.getElementById('planet'),ctx=canvas?.getContext('2d');
  if(!ctx)return;
  const motion=root.matchMedia('(prefers-reduced-motion: reduce)'),grid=[];
  const {points,coasts}=expandLand(root.PICGlobeLand);
  for(let lat=-75;lat<=75;lat+=15)grid.push(Array.from({length:121},(_,i)=>surface(lat,-180+i*3)));
  for(let lon=-180;lon<180;lon+=20)grid.push(Array.from({length:61},(_,i)=>surface(-90+i*3,lon)));
  const nodes=[[[-23,-46],[40,-74]],[[-23,-46],[38,-9]],[[38,-9],[52,13]],[[52,13],[35,139]],[[35,139],[-34,151]],[[-34,151],[1,104]]];
  const arcs=nodes.map(pair=>{const [a,b]=pair.map(([lat,lon])=>surface(lat,lon));return Array.from({length:43},(_,i)=>{
    const t=i/42,v=a.map((x,j)=>x+(b[j]-x)*t),scale=(1+Math.sin(t*Math.PI)*.065)/Math.hypot(...v);
    return v.map(x=>x*scale);
  });});
  const anchors=[...new Set(nodes.flat().map(p=>p.join(',')))].map(v=>surface(...v.split(',').map(Number)));
  const shades=['#6295f268','#75a6ff93','#88b3ffd6','#9cc3ffe0'];
  const initial=()=>({yaw:-42,pitch:12});
  let view=initial(),hovered=false,drag=null,frame=null,last=null,lastDraw=-Infinity,elapsed=0,dirty=true,wasMeteor=false;

  function drawMeteor(effect,center,r){
    const x=center+effect.x*r,y=center+effect.y*r,tx=x+.23*r,ty=y-.099*r;
    const glow=ctx.createLinearGradient(x,y,tx,ty);
    glow.addColorStop(0,'#fff8ff');glow.addColorStop(.33,'#f1a6dbbb');glow.addColorStop(1,'#7c9aff00');
    ctx.save();ctx.globalAlpha=effect.alpha;ctx.fillStyle=glow;
    ctx.beginPath();ctx.moveTo(x-.3,y-.7);ctx.lineTo(tx,ty);ctx.lineTo(x+.3,y+.7);ctx.closePath();ctx.fill();
    ctx.beginPath();ctx.arc(x,y,1.55,0,Math.PI*2);ctx.fillStyle='#fff4fa';ctx.fill();
    ctx.restore();
  }
  function paint(meteor){
    const size=Math.min(canvas.clientWidth,canvas.clientHeight);
    if(!size)return;
    const dpr=Math.min(root.devicePixelRatio||1,2),pixels=Math.round(size*dpr);
    if(canvas.width!==pixels||canvas.height!==pixels)canvas.width=canvas.height=pixels;
    ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,size,size);
    const center=size/2,r=size*.419,co=Math.cos(view.yaw*RAD),si=Math.sin(view.yaw*RAD),ct=Math.cos(view.pitch*RAD),st=Math.sin(view.pitch*RAD);
    let x,y,z;
    function point(v){
      const a=v[0]*co-v[2]*si,b=v[0]*si+v[2]*co;
      x=center+a*r;y=center-(v[1]*ct-b*st)*r;z=v[1]*st+b*ct;
    }
    function stroke(paths,color,width){
      ctx.beginPath();
      for(const path of paths){
        let ox=0,oy=0,oz=-1,first=true;
        for(const v of path){
          point(v);
          if(!first&&(z>=0||oz>=0)){
            if((z>=0)!==(oz>=0)){
              const t=oz/(oz-z),edgeX=ox+(x-ox)*t,edgeY=oy+(y-oy)*t;
              if(z>=0){ctx.moveTo(edgeX,edgeY);ctx.lineTo(x,y);}
              else ctx.lineTo(edgeX,edgeY);
            }else ctx.lineTo(x,y);
          }else if(first&&z>=0)ctx.moveTo(x,y);
          ox=x;oy=y;oz=z;first=false;
        }
      }
      ctx.lineWidth=width;ctx.strokeStyle=color;ctx.stroke();
    }
    const sphere=ctx.createRadialGradient(center-r*.28,center-r*.38,r*.05,center,center,r);
    sphere.addColorStop(0,'#142d69');sphere.addColorStop(.72,'#091533');sphere.addColorStop(1,'#0f2354');
    ctx.beginPath();ctx.arc(center,center,r,0,Math.PI*2);ctx.fillStyle=sphere;ctx.fill();
    ctx.strokeStyle='#6291ff';ctx.lineWidth=1.05;ctx.stroke();
    stroke(grid,'#729eff38',.6);
    let shade=-1;
    for(const v of points){
      point(v);if(z<.06)continue;
      const band=Math.min(3,Math.floor(z*4));
      if(band!==shade){ctx.fillStyle=shades[band];shade=band;}
      const w=Math.max(.7,size*.0032)*(.65+z*.35);ctx.fillRect(x-w/2,y-w/2,w,w);
    }
    stroke(coasts,'#8bb4ff80',.65);
    stroke(arcs,'#fb92b79c',.85);
    for(const v of anchors){
      point(v);if(z<.04)continue;
      ctx.beginPath();ctx.arc(x,y,4.7,0,Math.PI*2);ctx.fillStyle='#fc739744';ctx.fill();
      ctx.beginPath();ctx.arc(x,y,1.9,0,Math.PI*2);ctx.fillStyle='#ffd1df';ctx.fill();
    }
    if(meteor)drawMeteor(meteor,center,r);
  }
  function schedule(){if(frame===null&&!doc.hidden)frame=root.requestAnimationFrame(tick);}
  function invalidate(){dirty=true;schedule();}
  function tick(now){
    frame=null;
    if(doc.hidden){last=null;return;}
    const animate=!motion.matches&&!modalOpen,dt=last===null?0:Math.max(0,now-last);
    last=animate?now:null;
    if(animate){
      elapsed+=dt;
      if(!hovered&&!drag&&dt){view.yaw=wrap(view.yaw+Math.min(80,dt)*SPIN/1000);dirty=true;}
    }
    const meteor=animate?meteorAt(elapsed):null;
    if((dirty||meteor||wasMeteor)&&(now-lastDraw>=31||!animate)){
      paint(meteor);dirty=false;lastDraw=now;wasMeteor=Boolean(meteor);
    }
    if(animate||dirty)schedule();
  }
  resetTiming=()=>{last=null;invalidate();};
  root.addEventListener('wheel',e=>{
    if(motion.matches||modalOpen)return;
    const page=doc.scrollingElement||doc.documentElement,delta=wheelTurn(e,page.scrollHeight>page.clientHeight+2);
    if(delta){view.yaw=wrap(view.yaw+delta);invalidate();}
  },{passive:true});
  canvas.addEventListener('pointerenter',e=>{if(e.pointerType==='mouse'||e.pointerType==='pen')hovered=true;});
  canvas.addEventListener('pointerleave',e=>{if(e.pointerType==='mouse'||e.pointerType==='pen'){hovered=false;last=null;}});
  canvas.addEventListener('pointerdown',e=>{
    if(motion.matches||modalOpen||!e.isPrimary||e.button!==0)return;
    drag={id:e.pointerId,x:e.clientX,y:e.clientY};
    canvas.setPointerCapture(e.pointerId);
  });
  canvas.addEventListener('pointermove',e=>{
    if(drag?.id!==e.pointerId)return;
    const dx=e.clientX-drag.x,dy=e.clientY-drag.y;
    if(dx||dy){view=dragView(view,dx,dy);drag.x=e.clientX;drag.y=e.clientY;invalidate();}
  });
  function endDrag(e){
    if(drag?.id!==e.pointerId)return;
    drag=null;last=null;
    if(e.pointerType==='mouse'||e.pointerType==='pen'){
      const rect=canvas.getBoundingClientRect();
      hovered=e.clientX>=rect.left&&e.clientX<=rect.right&&e.clientY>=rect.top&&e.clientY<=rect.bottom;
    }
  }
  canvas.addEventListener('lostpointercapture',endDrag);
  canvas.addEventListener('pointerup',endDrag);
  canvas.addEventListener('pointercancel',endDrag);
  motion.addEventListener('change',()=>{if(motion.matches){drag=null;view=initial();elapsed=0;}resetTiming();});
  doc.addEventListener('visibilitychange',()=>{
    last=null;
    if(doc.hidden){if(frame!==null)root.cancelAnimationFrame(frame);frame=null;drag=null;hovered=false;}
    else invalidate();
  });
  root.addEventListener('resize',invalidate,{passive:true});
  invalidate();
})(globalThis);
