(() => {
  'use strict';
  const titles=['Capa do portal','Capa alternativa','Agenda','Abertura de seção','Branco com assinatura PIC','Mensagem principal','Contexto da análise','Comparação de cenários','Indicadores da revisão','Distribuição dos apontamentos','Evolução da qualidade cadastral','Quadro de apontamentos','Ciclo de revisão cadastral','Demonstração da aplicação','Documentos e orientações','Trabalho de análise','Discussão dos resultados','Plano de trabalho','Indicador em destaque','Encerramento'];
  const byId=id=>document.getElementById(id);
  const image=byId('slide-image'),caption=byId('slide-caption'),select=byId('slide-select'),prev=byId('slide-prev'),next=byId('slide-next');
  let index=0;
  for(const [i,title] of titles.entries())select.add(new Option(String(i+1).padStart(2,'0')+' · '+title,i));
  function src(i){return 'materiais/previews/slide-'+String(i+1).padStart(2,'0')+'.jpg';}
  function show(i){
    index=Math.min(Math.max(i,0),titles.length-1);
    const title='Slide '+(index+1)+': '+titles[index];
    image.alt=title;image.src=src(index);
    caption.textContent='Slide '+(index+1)+' de '+titles.length+' · '+titles[index];
    select.value=String(index);prev.disabled=index===0;next.disabled=index===titles.length-1;
  }
  prev.addEventListener('click',()=>{show(index-1);if(prev.disabled)next.focus();});
  next.addEventListener('click',()=>{show(index+1);if(next.disabled)prev.focus();});
  select.addEventListener('change',()=>show(Number(select.value)));
  document.addEventListener('keydown',e=>{
    if(e.altKey||e.ctrlKey||e.metaKey||e.shiftKey||e.target.closest?.('input,select,textarea,[contenteditable]'))return;
    if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();show(index+(e.key==='ArrowRight'?1:-1));}
  });
  show(0);byId('viewer-controls').hidden=false;
})();
