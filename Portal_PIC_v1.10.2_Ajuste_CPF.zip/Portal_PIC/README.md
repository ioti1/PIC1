# Portal PIC · Dados Pessoais e Meios de Comunicação · 1.7

No seletor, a apresentação perde opacidade no lugar após sete segundos; depois os cartões sobem suavemente até o centro. O fundo cinza destaca o cartão sob o cursor ou com foco de teclado. O logo PIC na Central Operacional retorna à abertura do portal.

## Capas dos cartões

As capas `assets/card-dados-pessoais.png` e `assets/card-meios-comunicacao.png` foram criadas com ImageGen no modo integrado. Prompts:

- Dados Pessoais: Use case: photorealistic-natural. Asset: square 1:1 cover tile for a refined Portuguese offline internal data quality portal; remain legible at 150 pixels. Reference: first user attachment, for the biometric/identity motif only; generate a new fictional portrait. Midnight Black (#030413) studio background. Head-and-shoulders portrait of an adult Black male analyst, on the center-right, calmly looking at a handheld tablet at bottom edge. Face clearly lit by deep azure (#0045DE) and ice blue, sparse fine facial landmark mesh drawn over one side, three tiny coral (#FC7397) control points. On the left a single large translucent identity shield and a small fingerprint, gently glowing with thin clean lines. Minimal, balanced, premium high contrast editorial photography with technology overlays, clearly recognizable face and shield, not crowded. Keep all key content in center 78% square. No words, letters, numbers, logos, watermark, frame, UI labels or real data. Solid dark background, not transparent.
- Meios de Comunicação: Use case: photorealistic-natural. Asset: square 1:1 cover tile for a refined Portuguese offline internal data quality portal; remain legible at 150 pixels. Reference: second user attachment, for the hands, smartphone and holographic validation motif; generate a new image. Tight editorial close-up of a hand holding a smartphone and the other hand reaching naturally toward the interface, phone lower right, one large unmistakable glowing document outline with checkmark in the center, small envelope and phone glyphs as quiet secondary details. Deep midnight blue (#030413) background with strong Coral Rose (#FC7397) and rose-copper illumination centered around the check, cool Deep Azure (#0045DE) rim lighting, calm premium cinematic color grade. Realistic hands with natural anatomy, phone clean and unbranded, readable simple composition. Keep the document/check within center 78% square. No words, letters, digits, logos, watermark, frame, UI labels or real data. Solid dark background, not transparent.

Abra **index.html** no Explorador. O botão **Explorar** e o menu **Aplicações** abrem o seletor. **Dados Pessoais** e **Meios de Comunicação** abrem uma janela para escolher entre **Painel de BI** e **Área Operacional**. Os cartões já configurados não têm lápis sobre a imagem: edite-os pelo lápis do cabeçalho. Se só houver um destino configurado, o cartão abre esse destino diretamente. Mantenha as quatro pastas extraídas lado a lado. O histórico de Dados Pessoais (.picdp) é separado do histórico de Meios de Comunicação (.pic). Os erros são identificados por **EDP** em Dados Pessoais e por **EMC** em Meios de Comunicação.

## Material e Conceito

**Material** reúne o modelo editável do PowerPoint com 20 slides e a capa de relatório em Word. **Visualizar slides** abre em outra aba as imagens dos slides renderizados a partir do PowerPoint, sem enviar o arquivo a serviços externos. Use **Anterior**, **Próximo**, as setas do teclado ou o seletor de slide. Para editar, use **Baixar PPTX**. Se o PPTX da pasta for substituído no futuro, gere novamente as imagens da prévia para que correspondam à nova versão.

No Word, substitua os textos entre colchetes. O cabeçalho e o rodapé são áreas do próprio documento e se repetem nas novas páginas. O rodapé inclui um campo automático de número de página. A capa tipográfica, sem foto central, também é usada no PDF gerencial de Meios de Comunicação. O PDF preenche os dados da fotografia automaticamente.

Em **Material → Logos do PIC**, consulte as prévias e baixe os arquivos individualmente ou em **Baixar kit PNG**. São oito versões em alta resolução (300 dpi): horizontal com o nome completo, compacta só com a sigla, monocromática e quadrada para avatares. As versões horizontal, compacta e monocromática têm fundo transparente; as quadradas têm fundo sólido.

**Conceito** explica a iniciativa, o fluxo de validação e a identidade visual.

### Imagens do PowerPoint

As três imagens abaixo foram criadas com o modo integrado do ImageGen e estão incorporadas ao PPTX. Prompts:

**`assets/apresentacao/capa-globo-pic.jpg`**

> Use case: stylized-concept. Asset: edge-to-edge 16:9 widescreen PowerPoint cover artwork for Programa de Inteligência Cadastral. Input image 1 is the portal's hands, a style and gesture reference only. Recreate the same diagonal two-hand arrangement, with a single luminous geospatial globe exactly at the horizontal center and around 60% down the image. Show the Americas using a delicate point mesh, thin azure arcs and a few coral points. One hand extends from the lower left edge and gently cradles the globe, the other extends from the right edge and touches it with the index finger. The hands should span the outer edges, natural human anatomy, blue rim light. Full bleed midnight-black studio atmosphere with restrained deep azure #0045DE and coral #FC7397. Keep the upper 29% in the center uncluttered near-black for an editable heading added later. Sophisticated photographic lighting, quiet glow, fine detail, clean silhouette. No words, no logos, no pictograms, no border, no watermark.

**`assets/apresentacao/analise-cadastral-pic.jpg`**

> Use case: photorealistic-natural. Asset: vertical editorial photo filling a half-slide to the edges, portrait aspect 8:9. A Brazilian woman data analyst in a navy blazer calmly inspecting a clean desktop monitor in a contemporary office. Candid side angle, dark navy setting, restrained cool azure screen light and faint coral reflection. Real texture, balanced and quiet. A few soft-focus abstract data columns on monitor, not readable personal data. Single subject at frame center, enough breathing room around face. Palette Midnight Black #030413, Deep Azure #0045DE, touches of Coral Rose #FC7397. No text, no logos, no HUD over the person, no watermark.

**`assets/apresentacao/equipe-cadastral-pic.jpg`**

> Use case: photorealistic-natural. Asset: editorial portrait-oriented photograph for a full-height left half of a corporate widescreen slide, 8:9 or portrait. Three Brazilian colleagues with varied skin tones and ages around a table reviewing a data-quality issue together. Contemporary workplace, candid interaction, real hands and expressions, dark navy clothing and a cool soft daylight blue cast, small coral reflection or object. Monitor in the background unobtrusive with no readable details. Subjects fit in a compact centered group for a narrow full-height crop. Polished editorial, grounded and human, not staged stock photography. Midnight Black #030413, Deep Azure #0045DE, subtle Coral Rose #FC7397. No lettering, no logos, no watermark.

A arte editorial `assets/pic-editorial.jpg` foi criada no modo integrado do ImageGen e usada também nos modelos. Prompt:

> Use case: stylized-concept. Asset: landscape cover art for Brazil's internal Programa de Inteligência Cadastral, to be cropped for web and Word. Wide cinematic 16:9 composition. Across the left 49 percent leave uninterrupted near-solid Midnight Black (#030413), completely clean negative space for separate white slide text. On the right half, photoreal natural hands gently supporting a luminous glass globe of connected data points with a geographic outline, with a few translucent identity and verification panels etched with abstract pictograms only. Human judgment guides the data. Editorial, refined, clean depth and precise light, coherent with PIC portal aesthetics. Deep Azure #0045DE as main light, restrained Coral Rose #FC7397 at key nodes and white glints. Very dark edge at left, no green or gold, no letters, no numbers, no branding, no watermark. All main subject detail within x=54–92% and y=15–85%.

## Atalhos

O lápis no cabeçalho gerencia todos os cartões. Edite os dois caminhos HTML de forma independente ou selecione **Novo cartão**. Aceita caminho relativo, caminho local do Windows ou arquivo HTML em pasta corporativa sincronizada. O portal não verifica se o destino existe até a abertura.

**Salvar cartão** aplica a alteração no navegador e gera `PIC_Atalhos.json`. Para tornar esses atalhos o padrão de todos os usuários da mesma pasta, abra **Padrão compartilhado da pasta → Salvar padrão na pasta** e selecione **Portal_PIC**. Essa opção grava o JSON e o arquivo `atalhos-padrao.js`, que carrega os mesmos dados ao abrir o HTML offline, sem tentar buscar o JSON por rede. Se o navegador não autorizar a gravação, use **Baixar JSON** e **Baixar inicializador**, e substitua os dois arquivos na pasta do portal. Um novo padrão compartilhado prevalece sobre ajustes locais de uma revisão anterior.

As configurações anteriores com um único caminho podem ser importadas como destino operacional. A configuração guarda nomes e caminhos, não bases de participantes. Não há conexão externa.

A abertura tem uma única composição com o crédito **Núcleo Analytics - GAP/CA**. O globo gira sozinho, pausa com o cursor sobre ele e pode ser arrastado na horizontal e na vertical, inclusive por toque. As mãos permanecem fixas. A cada 20 segundos com a abertura ativa, um meteoro cruza o globo. Em uma janela muito baixa ou com zoom alto, a roda continua disponível para rolar o conteúdo. A preferência de movimento reduzido mantém o globo estático e desativa o meteoro e a animação do botão.

O mapa é desenhado em Canvas, com a camada de terras e costas em escala 1:110 milhões do [Natural Earth](https://www.naturalearthdata.com/downloads/110m-physical-vectors/110m-land/), v5.1.2. O arquivo `assets/globo-terras.js` já está no pacote: nenhuma geometria é baixada ao abrir o portal. O compilador está em `tools/central-v41-qa/prepare-globe-land.cjs` no workspace.

## Arte da abertura

Imagem `assets/maos-pic.png`, gerada com ImageGen (modo integrado). Prompt utilizado:

> Use case: stylized-concept
> Asset type: transparent foreground compositing layer for the PIC offline website hero.
> Primary request: two stationary human hands reaching around an empty space where a separate animated globe will go.
> Composition: ultra-wide landscape canvas, wrists entering/cropped at the lower left edge and at the upper right edge. The left hand reaches diagonally upward toward the center, palm slightly raised, fingers loosely cupped; right hand reaches diagonally downward toward the center, index extended naturally. Hands in outer thirds only; the middle 40% of the canvas is COMPLETELY empty and genuinely transparent. Both hands do not touch. Natural anatomy. Lighting like an editorial photograph of two hands rendered almost in silhouette: Midnight Black #030413 shadowed bodies, luminous Deep Azure #0045DE rim light, restrained fine Coral Rose #FC7397 reflections on fingertips, visible contours and soft volume. Crisp edges, premium editorial technology art. Transparent alpha everywhere outside the hands and wrist forms, including all of the center. No sphere, no globe, no graphical nodes, no text, no logos, no watermark, no background, no UI.
