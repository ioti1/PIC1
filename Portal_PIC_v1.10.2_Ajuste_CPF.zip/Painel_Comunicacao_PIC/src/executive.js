(function(){
 'use strict';
 const H=ComHistory,D=ComExecutiveData,P=ComHistoryPersistence,M=ComModel,R=ComReconcile,U=CVCUtils,X=ComConsolidated,W=ComExport,B=ComBatchExport;
 const $=s=>document.querySelector(s),esc=U.escapeHtml,n=U.formatNumber,pct=v=>v==null?'—':U.formatPercent(v),date=U.formatDate;
 const pause=()=>new Promise(resolve=>setTimeout(resolve,0));
 let db=H.fresh(),handle=null,selected='',priorId='',loading=false,origin='Nenhum histórico carregado',renderToken=0;
 let filters={},peopleExpanded=false,personPage=1,personSize=20,changesOpen=false,changeType='aumento',changeRule='',changePage=1,changeRows=[];
 const defs={group:'Situação contratual',subgroup:'Subsituação contratual',plan:'Plano',sponsor:'Patrocinadora',ageBand:'Faixa etária',status:'Qualidade cadastral',treatment:'Tratamento',coverage:'Validade dos canais',exclusion:'Disponibilidade de canais',rule:'Apontamento'};
 const current=()=>db.runs.find(r=>r.id===selected);
 const previous=()=>db.runs.find(r=>r.id===priorId)||null;
 const label=(key,v)=>{if(key==='plan')return U.shortPlan(v);if(key==='rule'){const r=M.rules.find(r=>r.id===v);return r?[r.code,r.label].filter(Boolean).join(' · '):v;}return Object.fromEntries(M.exclusions)[v]||v;};
 function notify(s){$('#toast').textContent=s;$('#toast').hidden=false;clearTimeout(notify.timer);notify.timer=setTimeout(()=>$('#toast').hidden=true,8000);}
 function message(s){$('#historyMessage').textContent=s;$('#historyMessage').hidden=!s;}
 function progress(p){$('#historyWorkTitle').textContent=p.phase||'Atualizando histórico';$('#historyWorkDetail').textContent=p.detail||'Aguarde a conclusão da operação.';$('#historyWorkBar').value=p.percent||0;$('#historyWorkPercent').textContent=Math.round(p.percent||0)+'%';}
 async function work(title,fn){
   loading=true;controls();progress({phase:title,percent:1});if(!$('#historyWorkDialog').open)$('#historyWorkDialog').showModal();await pause();
   try{return await fn(progress);}finally{loading=false;$('#historyWorkDialog').close();controls();}
 }
 function choose(){
   const list=H.canonical(db);if(!db.runs.some(r=>r.id===selected))selected=list.at(-1)?.id||'';
   if(!db.runs.some(r=>r.id===priorId)||priorId===selected)priorId=current()?H.previous(db,current())?.id||'':'';
 }
 function controls(){
   choose();const sorted=[...db.runs].sort((a,b)=>b.photo.localeCompare(a.photo)),refs=new Set(H.canonical(db).map(r=>r.id));
   for(const [id,value,placeholder]of [['execPhoto',selected,'Selecione a fotografia'],['execPrevious',priorId,'Sem período anterior']]){
     $('#'+id).innerHTML='<option value="">'+placeholder+'</option>'+sorted.filter(r=>id!=='execPrevious'||r.photo<current()?.photo&&r.classification===current()?.classification).map(r=>'<option value="'+esc(r.id)+'">'+date(r.photo)+(r.classification==='demonstration'?' · demonstração':'')+'</option>').join('');$('#'+id).value=value;
   }
   $('#historyOrigin').textContent=origin;
   $('#historyStatus').textContent=n(db.runs.length)+' competências registradas';
   for(const id of ['historyOpen','historyManualOpen','execEmptyOpen','execOpen'])$('#'+id).disabled=loading;
   $('#historyReconnect').hidden=!handle;
   $('#historyTable').innerHTML='<table><thead><tr><th>Fotografia</th><th>Público avaliado</th><th>Processamento</th><th></th></tr></thead><tbody>'+sorted.map(r=>'<tr><td><b>'+date(r.photo)+'</b></td><td>'+n(r.personCount)+'</td><td>'+esc(new Date(r.result.processedAt).toLocaleString('pt-BR'))+(r.migrationNote?'<small>Histórico convertido para o formato reduzido</small>':'')+'</td><td><button class="quiet" data-history-run="'+esc(r.id)+'">Consultar</button></td></tr>').join('')+'</tbody></table>';
 }
 async function ensurePair(onProgress){
   choose();if(!current())return;await H.expand(current(),JSZip,onProgress);if(previous())await H.expand(previous(),JSZip,onProgress);H.evict(db,[selected,priorId]);
 }
 async function accept(file,h=null,onProgress,keepLocal=false){
   const incoming=await H.decode(file,JSZip,onProgress);
   const merge=keepLocal&&db.id===incoming.id&&db.runs.some(r=>!incoming.runs.some(v=>v.id===r.id&&v.savedAt>=r.savedAt));
   db=merge?H.merge(incoming,db):incoming;handle=h;
   origin=(h?'Arquivo vinculado: ':'Arquivo aberto: ')+file.name+(merge?' · inclui execuções locais mais recentes':'');
   if(h)await P.write('panel-handle',h).catch(()=>{});
   selected='';priorId='';filters={};$('#execSearch').value='';changesOpen=false;personPage=1;
   await render();
   if($('#historyDialog').open)$('#historyDialog').close();
 }
 async function chooseFile(){
   if(loading)return;try{if(window.showOpenFilePicker){const [h]=await window.showOpenFilePicker({multiple:false,types:[{description:'Histórico cadastral PIC',accept:{'application/zip':['.pic']}}]});const file=await h.getFile();await work('Carregando histórico',p=>accept(file,h,p));}else $('#historyInput').click();}catch(e){if(e.name!=='AbortError')message('Não foi possível abrir o arquivo. '+e.message);}
 }
 async function reconnect(){if(!handle||loading)return;try{if(!await P.permission(handle,false,true))throw Error('Autorize a leitura ou selecione o arquivo novamente.');const file=await handle.getFile();await work('Conferindo arquivo vinculado',p=>accept(file,handle,p));}catch(e){message(e.message);}}
 function openHistory(){controls();if(!$('#historyDialog').open)$('#historyDialog').showModal();}
 function showPerson(id){
   const p=sourceRows().find(v=>v.id===id);if(!p)throw Error('Participante não encontrado no recorte.');
   $('#detailTitle').textContent=p.nome;$('#detailSubtitle').textContent='Matrícula Petros: '+D.master(p)+' · Fotografia '+date(p.snapshotDate);
   const item=i=>'<li><strong>'+esc([M.rules.find(r=>r.id===i.rule)?.code,i.problem||i.ruleLabel||i.rule].filter(Boolean).join(' · '))+'</strong> · '+esc(i.severity)+'<br>'+esc(i.message||'')+'</li>';
   const bindings=p.vinculos.map(v=>'<li><strong>'+esc(v.plano)+'</strong> · '+esc(v.patrocinador)+' · '+esc(v.contractSubgroup)+'</li>').join('');
   const channels=(p.channels||[]).filter(c=>c.issues.length).map(c=>'<article class="card evidence-card"><h3>'+esc(c.label)+'</h3><p>'+esc(R.evidence(c))+' · '+esc(c.registrationUser||'Usuário não informado')+'</p><ul>'+c.issues.map(item).join('')+'</ul></article>').join('');
   $('#detailBody').innerHTML='<p><strong>'+esc(p.status)+'</strong> · '+esc(p.treatmentStatus)+'</p><h3>Vínculos oficiais</h3><ul>'+bindings+'</ul>'+(p.contextIssues.length?'<h3>Apontamentos do público</h3><ul>'+p.contextIssues.map(item).join('')+'</ul>':'')+'<h3>Evidências dos contatos</h3>'+(channels||'<p>Não há evidências de contato nas regras selecionadas.</p>');
   $('#detailDialog').showModal();
 }
 function sourceRows(){return current()?.people||[];}
 function scope(){return D.filter(sourceRows(),filters);}
 function facets(changed){
   const ps=sourceRows();
   if(changed&&filters[changed])for(const key of Object.keys(defs))if(key!==changed&&filters[key]&&!D.filter(ps,{[key]:filters[key],[changed]:filters[changed]}).length)delete filters[key];
   for(const key of Object.keys(defs)){const values=D.facets(ps,filters,key),el=$('#exec-'+key);if(filters[key]&&!values.includes(filters[key]))delete filters[key];el.innerHTML='<option value="">Todos</option>'+values.map(v=>'<option value="'+esc(v)+'" title="'+esc(v)+'">'+esc(label(key,v))+'</option>').join('');el.value=filters[key]||'';el.title=key==='plan'?(filters[key]||'Todos os planos'):'';el.disabled=!values.length;}$('#execCuriosity').value=filters.curiosity||'';
 }
 function kpi(title,value,note,action=''){return '<'+(action?'button':'article')+' class="exec-metric" '+action+'><span>'+esc(title)+'</span><strong>'+esc(typeof value==='number'?n(value):value)+'</strong><small>'+esc(note)+'</small></'+(action?'button':'article')+'>';}
 function horizontal(groups,key,dimension,scaleMax){
   const max=scaleMax||Math.max(1,...groups.map(g=>g[key]));return groups.length?groups.map(g=>'<button class="exec-horizontal" data-dimension="'+dimension+'" data-value="'+esc(g.label)+'" title="'+esc(g.label)+': '+n(g[key])+' de '+n(g.identified)+' participantes"><span>'+esc(dimension==='plan'?U.shortPlan(g.label):g.label)+'</span><i aria-hidden="true"><b style="width:'+g[key]/max*100+'%"></b></i><strong>'+n(g[key])+'</strong></button>').join(''):'<p class="exec-chart-empty">Não há participantes neste recorte.</p>';
 }
 function verticalBar(value,max,prior=false,log=false,label=true){const height=Math.max(0,Math.min(100,(log?Math.log1p(value||0)/Math.log1p(max):(value||0)/max)*100));return '<div class="vertical-track" style="--bar-height:'+height+'%">'+(label?'<b>'+(value==null?'—':typeof value==='string'?esc(value):n(value))+'</b>':'')+'<i'+(prior?' class="prior-fill"':'')+' style="height:'+height+'%;'+(value>0?'':'display:none')+'" aria-hidden="true"></i></div>';}
 function overview(ps){
   const m=D.metrics(ps),cmp=D.compare(current(),previous(),filters),delta=cmp.available?m.errorOccurrences-cmp.previous.errorOccurrences:null;
   const channelMax=Math.max(1,m.identified);
   const planGroups=D.segments(ps,filters,'plan'),sponsorGroups=D.segments(ps,filters,'sponsor'),subgroups=D.segments(ps,filters,'subgroup'),segmentMax=Math.max(1,...planGroups.map(g=>g.fail),...sponsorGroups.map(g=>g.fail),...subgroups.map(g=>g.fail)),segmentHeight=Math.min(6,Math.max(3,planGroups.length,sponsorGroups.length,subgroups.length))*44;
   $('#execOverview').innerHTML='<div class="exec-metrics">'+
     kpi('Público avaliado',m.identified,'Pessoas sem registro de óbito','data-reset-quality="yes"')+
     kpi('Excluídos Digitais',m.digitallyExcluded,'Sem e-mail válido e sem celular válido','data-exclusion="sem_digital_valido" aria-pressed="'+(filters.exclusion==='sem_digital_valido')+'"')+
     kpi('Sem canal válido',m.uncovered,'Sem telefone fixo, celular ou e-mail válido','data-coverage="Sem canal válido" aria-pressed="'+(filters.coverage==='Sem canal válido')+'"')+
     kpi('Participantes com erro',m.fail,U.coveragePercent(m.fail,m.identified)+' do público avaliado','data-quality="Inconsistente"')+
     kpi('Ocorrências de erro',m.errorOccurrences,'Um participante pode ter várias ocorrências',previous()?'data-open-movements="aumento"':'data-quality="Inconsistente"')+
     kpi('Variação de ocorrências',delta==null?'—':(delta>0?'+':'')+n(delta),previous()?'Em relação a '+date(previous().photo):'Sem fotografia do mês anterior',previous()?'data-open-movements="aumento"':'')+
     '</div><div class="exec-grid" style="--segment-height:'+segmentHeight+'px">'+
     '<article class="card exec-panel subgroup-panel"><div class="exec-panel-head"><h2>Participantes por Situação</h2><span>Pessoas com erro</span></div><div class="exec-scroll-bars">'+horizontal(subgroups,'fail','subgroup',segmentMax)+'</div><small class="exec-panel-footer">Distribuição dos participantes com erro por subsituação contratual. Selecione uma barra para filtrar.</small></article>'+
     '<article class="card exec-panel channel-panel"><div class="exec-panel-head"><h2>Presença e validade dos canais</h2><span>Participantes distintos</span></div><div class="exec-chart-legend"><span>Cadastrado</span><span class="valid-key">Estrutura válida</span></div><div class="exec-vertical channels">'+Object.entries(M.types).map(([type,t])=>{const a=ps.filter(p=>p.counts[type]>0).length,b=ps.filter(p=>p.validCounts[type]>0).length;return '<div class="vertical-group" title="'+esc(t.label)+': '+n(a)+' com cadastro; '+n(b)+' com estrutura válida"><div class="vertical-bars">'+verticalBar(a,channelMax,true,false,false)+verticalBar(b,channelMax,false,false,false)+'</div><strong>'+esc(t.label)+'</strong><div class="channel-counts"><span><i aria-hidden="true"></i><span class="sr-only">Cadastrado: </span>'+n(a)+'</span><span class="valid-key"><i aria-hidden="true"></i><span class="sr-only">Estrutura válida: </span>'+n(b)+'</span></div></div>';}).join('')+'</div><div class="absence-chips exec-panel-footer">'+[['sem_email','Sem e-mail',m.withoutEmail],['sem_celular','Sem celular',m.withoutMobile],['sem_fixo','Sem telefone fixo',m.withoutPhone],['sem_todos','Sem canais cadastrados',m.withoutAny]].map(([id,label,v])=>'<button data-exclusion="'+id+'"><span>'+label+'</span><b>'+n(v)+'</b></button>').join('')+'</div></article>'+
     '</div><div class="exec-segment-grid" style="--segment-height:'+segmentHeight+'px">'+
     '<article class="card exec-panel plan-panel"><div class="exec-panel-head"><h2>Participantes com erro por plano</h2><span>Participantes distintos</span></div><div class="exec-scroll-bars">'+horizontal(planGroups,'fail','plan',segmentMax)+'</div><small class="exec-panel-footer">Pessoas com múltiplos vínculos podem integrar mais de um plano. As quantidades não são aditivas.</small></article>'+
     sponsorChart(sponsorGroups,segmentMax)+'</div>';
 }
 function sponsorChart(groups,scaleMax){
   return '<article class="card exec-panel exec-sponsor-panel"><div class="exec-panel-head"><h2>Participantes com erro por patrocinadora</h2><span>Participantes distintos</span></div><div class="exec-scroll-bars">'+horizontal(groups,'fail','sponsor',scaleMax)+'</div><small class="exec-panel-footer">Selecione uma barra para filtrar a patrocinadora. Pessoas com múltiplos vínculos podem integrar mais de uma categoria.</small></article>';
 }
 function demographicChart(ps){
   const context=D.errorPeople(filters.ageBand?D.filter(sourceRows(),{...filters,ageBand:''}):ps),all=D.demographics(context),missing=all.find(r=>r.label==='Não disponível')?.total||0,rows=all.filter(r=>r.label!=='Não disponível'),total=rows.reduce((s,r)=>s+r.total,0),known=rows.reduce((s,r)=>s+r.F+r.M,0),series=[...(known?[['F','Mulheres'],['M','Homens']]:[]),...(rows.some(r=>r.N)?[['N','Não informado / não reconhecido']]:[]),...(rows.some(r=>r.D)?[['D','Divergente entre vínculos']]:[])],max=Math.max(1,...rows.flatMap(r=>series.map(([key])=>r[key]))),table=rows.map(r=>'<tr><td>'+r.label+'</td>'+series.map(([key])=>'<td>'+n(r[key])+'</td>').join('')+'<td>'+n(r.total)+'</td></tr>').join('');
   const bars=rows.map(r=>'<button class="age-horizontal-row'+(filters.ageBand===r.label?' is-selected':'')+'" data-age-band="'+r.label+'" aria-pressed="'+(filters.ageBand===r.label?'true':'false')+'" '+(!r.total&&filters.ageBand!==r.label?'disabled':'')+' title="'+esc('Faixa '+r.label+' · '+n(r.total)+' participantes com erro. '+(filters.ageBand===r.label?'Clique para limpar a faixa.':'Clique para filtrar o painel.'))+'"><strong class="age-range">'+r.label+'</strong><span class="age-sex-series">'+series.map(([key,title])=>'<span class="age-sex-row sex-'+key+'" title="'+esc(r.label+' · '+title+': '+n(r[key]))+'"><span class="age-sex-code" aria-label="'+esc(title)+'">'+(key==='N'?'NI':key)+'</span><i class="age-bar-track" aria-hidden="true"><b style="width:'+r[key]/max*100+'%;'+(r[key]>0?'':'display:none')+'"></b></i><strong>'+n(r[key])+'</strong></span>').join('')+'</span></button>').join('');
   $('#execDemographics').innerHTML='<div class="exec-panel-head"><h2>Perfil etário por sexo</h2><span>'+n(total)+(total===1?' participante com erro e idade disponível':' participantes com erro e idade disponível')+'</span></div>'+(!known&&total?'<p class="notice">Sexo não disponível nesta fotografia. Reprocesse a base oficial e mapeie Sexo (M/F) para obter a separação.</p>':'')+(filters.ageBand?'<div class="age-filter-selection"><strong>Faixa selecionada: '+esc(filters.ageBand)+'</strong><button class="quiet" data-age-band="'+esc(filters.ageBand)+'">Limpar faixa</button></div><small class="age-chart-scope">Distribuição dos participantes com erro antes da seleção da faixa etária.</small>':'')+'<div class="exec-chart-legend demographic-legend">'+series.map(([key,title])=>'<span class="sex-'+key+'" title="'+esc(title)+'">'+(key==='N'?'Não informado':key==='D'?'Divergente':title)+'</span>').join('')+'</div><div class="demographic-horizontal">'+(total?bars:'<p class="exec-chart-empty">'+(context.length?'Nenhum participante com erro tem idade válida neste recorte.':'Não há participantes com erro neste recorte.')+'</p>')+'</div><details><summary>Consultar valores por faixa etária</summary><div class="scroll-table"><table><thead><tr><th>Faixa etária</th>'+series.map(([,title])=>'<th>'+title+'</th>').join('')+'<th>Total</th></tr></thead><tbody>'+table+'</tbody></table></div></details><small class="exec-panel-footer">Idade na fotografia do estudo. Clique em uma faixa para filtrar o painel e clique novamente para limpar. Sexo sem inferência pelo nome.'+(missing?' '+n(missing)+(missing===1?' participante sem idade válida não aparece no gráfico, mas continua no total de participantes com erro.':' participantes sem idade válida não aparecem no gráfico, mas continuam no total de participantes com erro.'):'')+'</small>';
 }
 function registrationCard(ps){
   const {rows,withoutUser,withoutContact}=D.registrationErrors(ps,filters.rule);
   const item=(count,singular,plural)=>n(count)+' '+(count===1?singular:plural);
   const counts=rows.map(({user,occurrences,contacts,people})=>'<li class="driver-entry"><strong>'+esc(user)+'</strong><span><b>'+n(occurrences)+'</b> '+(occurrences===1?'erro':'erros')+'</span><small>'+item(contacts,'contato','contatos')+' · '+item(people,'participante','participantes')+'</small></li>').join('');
   const excluded=[withoutUser?item(withoutUser,'erro sem usuário informado','erros sem usuário informado'):'',withoutContact?item(withoutContact,'erro sem evidência de contato','erros sem evidência de contato'):''].filter(Boolean);
   const empty=current().migrationNote?'Esta fotografia não preservou o usuário de cadastro nas evidências.':excluded.length?'Nenhum erro deste recorte tem usuário de cadastro identificado.':'Não há erros de contato para os filtros aplicados.';
   return '<article id="execDrivers" class="card exec-panel exec-driver-panel"><div class="exec-panel-head"><div><h2>Principais chaves com erro</h2><p>Usuário de cadastro do contato</p></div></div>'+(counts?'<ol class="driver-list">'+counts+'</ol>':'<p class="exec-chart-empty">'+empty+'</p>')+'<small class="exec-highlight-note">Até cinco chaves por número de erros nas regras selecionadas. A chave identifica o cadastro do contato, não a causa do erro.'+(excluded.length?'<br><strong>Fora do ranking:</strong> '+excluded.join(' · ')+'.':'')+'</small></article>';
 }
 function lineChart(data){
   const series=[{key:'errorOccurrences',label:'Ocorrências de erro',color:'var(--exec-primary)'},{key:'fail',label:'Participantes com erro',color:'var(--exec-secondary)'}],Wv=1000,Hv=260,L=65,T=30,Rv=40,Bv=42,max=Math.max(1,...data.flatMap(d=>series.map(s=>d[s.key]||0))),start=new Date(data[0].photo.slice(0,7)+'-01').getTime(),end=new Date(data.at(-1).photo.slice(0,7)+'-01').getTime();
   const xx=d=>L+(new Date(d.photo.slice(0,7)+'-01').getTime()-start)/Math.max(1,end-start)*(Wv-L-Rv),yy=v=>T+(1-v/max)*(Hv-T-Bv);
   let svg='<svg viewBox="0 0 '+Wv+' '+Hv+'" role="img" aria-label="Evolução mensal de ocorrências de erro e participantes com erro. Valores disponíveis na tabela de apoio." class="exec-line">';
   for(const f of [0,.5,1])svg+='<line x1="'+L+'" x2="'+(Wv-Rv)+'" y1="'+yy(max*f)+'" y2="'+yy(max*f)+'" class="chart-grid"/><text x="'+(L-10)+'" y="'+(yy(max*f)+4)+'" text-anchor="end">'+n(Math.round(max*f))+'</text>';
   for(const s of series)for(let i=0;i<data.length;i++){const d=data[i],v=d[s.key],a=data[i-1];if(v==null)continue;if(a&&a[s.key]!=null&&a.profile===d.profile){const da=new Date(a.photo.slice(0,7)+'-01'),dd=new Date(d.photo.slice(0,7)+'-01'),gap=dd.getUTCFullYear()*12+dd.getUTCMonth()-da.getUTCFullYear()*12-da.getUTCMonth();if(gap===1)svg+='<line x1="'+xx(a)+'" y1="'+yy(a[s.key])+'" x2="'+xx(d)+'" y2="'+yy(v)+'" stroke="'+s.color+'" stroke-width="2.5"'+(s.key==='fail'?' stroke-dasharray="6 4"':'')+'/>';}svg+='<circle cx="'+xx(d)+'" cy="'+yy(v)+'" r="4.5" fill="'+s.color+'"><title>'+date(d.photo)+' · '+s.label+': '+n(v)+'</title></circle>';if(s.key==='errorOccurrences'&&(data.length<=12||i%2===0||i===data.length-1))svg+='<text x="'+xx(d)+'" y="'+Math.max(13,yy(v)-10)+'" text-anchor="middle">'+n(v)+'</text>';}
   data.forEach((d,i)=>{if(data.length<=12||i%2===0||i===data.length-1)svg+='<text x="'+xx(d)+'" y="'+(Hv-13)+'" text-anchor="middle">'+d.photo.slice(5,7)+'/'+d.photo.slice(2,4)+'</text>';});
   return svg+'</svg>';
 }
 function codeChart(rows,codes,max){
   const domain=Math.pow(10,Math.ceil(Math.log10(Math.max(10,max)))),ticks=[0,1];for(let v=10;v<=domain;v*=10)ticks.push(v);
   const position=v=>Math.log1p(v)/Math.log1p(domain)*100;
   return '<div class="exec-code-plot"><div class="exec-log-chart" data-scale="log1p" data-scale-max="'+domain+'"><div class="exec-log-axis" aria-hidden="true">'+ticks.map(v=>'<span style="bottom:'+position(v)+'%">'+n(v)+'</span>').join('')+'</div><div class="exec-log-grid" aria-hidden="true">'+ticks.map(v=>'<i style="bottom:'+position(v)+'%"></i>').join('')+'</div><div class="exec-vertical errors">'+rows.map(r=>'<button class="vertical-group" data-rule="'+r.rule+'" title="'+esc(r.label)+' · atual: '+n(r.current)+(r.previous!=null?' · anterior: '+n(r.previous):'')+'"><div class="vertical-bars">'+(previous()?verticalBar(r.previous,domain,true,true):'')+verticalBar(r.current,domain,false,true)+'</div><span>'+codes.get(r.rule)+'</span></button>').join('')+'</div></div></div>';
 }
 function monthComparison(series){
   const before=series[0],now=series[1],metric=(key,title,unit)=>{
     const c=U.changeStats(now[key],before[key]),kind=c.delta<0?'decrease':c.delta>0?'increase':'unchanged',rate=c.rate==null?'Sem base percentual':(c.delta>0?'+':c.delta<0?'-':'')+(Math.abs(c.rate)*100).toLocaleString('pt-BR',{maximumFractionDigits:1,minimumFractionDigits:1})+'%',max=Math.max(1,before[key],now[key]);
     return '<article class="month-compare"><div class="month-compare-heading"><h3>'+title+'</h3><strong class="'+kind+'">'+rate+'</strong></div><div class="month-values"><div><small>'+date(before.photo)+'</small><b>'+n(before[key])+'</b></div><span aria-hidden="true">→</span><div><small>'+date(now.photo)+'</small><b>'+n(now[key])+'</b></div></div><div class="month-mini-bars" aria-hidden="true"><i style="width:'+before[key]/max*100+'%"></i><i style="width:'+now[key]/max*100+'%"></i></div><div class="month-change"><span class="'+kind+'">'+(c.delta<0?'Redução de ':c.delta>0?'Acréscimo de ':'Sem variação: ')+n(Math.abs(c.delta))+' '+unit+'</span>'+(key==='errorOccurrences'?'<button class="quiet" data-open-movements="'+(c.delta<0?'reducao':'aumento')+'">Investigar variação</button>':'')+'</div></article>';
   };
   return '<div class="two-month-grid">'+metric('errorOccurrences','Ocorrências de erro','ocorrências')+metric('fail','Participantes com erro','participantes')+'</div>';
 }
 function evolution(){
   const ruleData=D.ruleRows(current(),previous(),filters).filter(r=>r.severity==='Erro'),codes=new Map(B.catalog('Erro').map(r=>[r.id,r.code]));
   let sum=0,old=0,entered=0,exited=0,complete=true,flowComplete=true;const table=ruleData.map(r=>{sum+=r.current;if(r.previous==null)complete=false;else old+=r.previous;if(r.entered==null||r.exited==null)flowComplete=false;else{entered+=r.entered;exited+=r.exited;}const action=(value,type)=>value==null?'<span>—</span>':'<button class="delta-link" data-movement-rule="'+r.rule+'" data-movement-type="'+type+'">'+(value==null?'—':typeof value==='string'?esc(value):n(value))+'</button>';return '<tr><td><b>'+codes.get(r.rule)+'</b></td><td>'+esc(r.label)+'</td>'+(previous()?'<td>'+(r.previous==null?'—':n(r.previous))+'</td>':'')+'<td>'+n(r.current)+'</td>'+(previous()?'<td>'+action(r.entered,'entradas')+'</td><td>'+action(r.exited,'saidas')+'</td><td>'+action(r.delta==null?null:U.formatVariation(r.current,r.previous),r.delta<0?'reducao':'aumento')+'</td>':'')+'</tr>';}).join('');
   $('#execEvolution').innerHTML=
     '<div class="exec-comparison-grid exec-age-comparison-grid"><div class="exec-profile-stack"><article id="execDemographics" class="card exec-panel exec-demographic-panel"></article></div>'+
     '<article class="card exec-panel comparison-table"><h2>Comparativo dos apontamentos</h2><div class="scroll-table"><table><thead><tr><th>Código</th><th>Erro identificado</th>'+(previous()?'<th>'+date(previous().photo)+'</th>':'')+'<th>'+date(current().photo)+'</th>'+(previous()?'<th>Entradas</th><th>Saídas</th><th>Variação líquida</th>':'')+'</tr></thead><tbody>'+table+'</tbody><tfoot><tr><th colspan="2">Total de ocorrências</th>'+(previous()?'<th>'+(complete?n(old):'—')+'</th>':'')+'<th>'+n(sum)+'</th>'+(previous()?'<th>'+(flowComplete?n(entered):'—')+'</th><th>'+(flowComplete?n(exited):'—')+'</th><th>'+(complete?U.formatVariation(sum,old):'—')+'</th>':'')+'</tr></tfoot></table></div><small>Entradas e saídas comparam matrícula, regra e chave da evidência, incluindo multiplicidade. Saída não comprova correção: também pode refletir alteração de contato, público ou filtro. Percentual sobre o mês anterior. Históricos sem evidências suficientes exibem —. Selecione uma quantidade para investigar.</small></article></div>'+

     '<div id="execHighlights" class="exec-highlights"></div><article class="card exec-panel changes-panel"><div class="exec-panel-head"><div><h2>Investigação das variações</h2><p>Consulte as matrículas, quantidades e chaves relacionadas aos acréscimos ou reduções.</p></div><button id="execInvestigate" class="secondary" '+(!previous()?'disabled':'')+'>Consultar variações</button></div><div id="execChanges"></div></article>';
   if(changesOpen)renderChanges();
 }
 function highlights(ps){
   $('#execHighlights').innerHTML=registrationCard(ps)+['EM','CE'].map(type=>{const maximum=ps.reduce((max,p)=>Math.max(max,p.counts[type]),0),ties=maximum?ps.filter(p=>p.counts[type]===maximum).length:0,top=D.leaders(ps,type);return '<article class="card exec-panel"><div class="exec-panel-head"><h2>'+ (type==='EM'?'Maior quantidade de e-mails cadastrados':'Maior quantidade de celulares cadastrados')+'</h2><button class="quiet" data-curiosity="'+(type==='EM'?'leader_email':'leader_mobile')+'" '+(!maximum?'disabled':'')+'>Consultar participantes</button></div><div class="highlight-total"><strong>'+n(maximum)+'</strong><span>maior quantidade de registros por participante<br>'+n(ties)+' participante(s) com essa quantidade</span></div>'+(maximum>1?'<div class="highlight-people">'+top.map(p=>'<button data-person="'+esc(p.matricula)+'"><span>'+esc(p.nome)+'<small>Matrícula Petros: '+esc(D.master(p))+'</small></span><b>'+n(p.counts[type])+'</b></button>').join('')+'</div>':'')+'<small class="exec-highlight-note">As quantidades correspondem a registros cadastrados, inclusive repetições, e não a endereços ou números distintos.</small></article>';}).join('');
 }
 function people(ps){
   const pages=Math.max(1,Math.ceil(ps.length/personSize));personPage=Math.max(1,Math.min(personPage,pages));const slice=ps.slice((personPage-1)*personSize,personPage*personSize);
   $('#execPeople').innerHTML='<div class="exec-panel-head"><div><h2>Participantes e evidências</h2><p>'+n(ps.length)+' participantes no recorte selecionado.</p></div><div class="button-row"><button id="execPeopleToggle" class="secondary" aria-expanded="'+(peopleExpanded?'true':'false')+'" aria-controls="execPeopleBody">'+(peopleExpanded?'− Recolher':'+ Expandir')+'</button><button id="execExport" class="secondary" '+(!ps.length?'disabled':'')+'>Exportar recorte Excel</button></div></div><div id="execPeopleBody"'+(peopleExpanded?'':' hidden')+'><div class="scroll-table exec-people-table"><table><thead><tr><th>Participante</th><th>Plano / subsituação</th><th>Registros de contato</th><th>Resultado</th><th>Tratamento</th><th></th></tr></thead><tbody>'+slice.map(p=>'<tr><td><b>'+esc(p.nome)+'</b><small>Matrícula Petros: '+esc(D.master(p))+(p.age!=null?' · '+p.age+' anos':'')+'</small></td><td title="'+esc([...new Set(X.bindings(p,filters).map(v=>v.plano))].join(' · '))+'">'+esc([...new Set(X.bindings(p,filters).map(v=>U.shortPlan(v.plano)))].join(' · '))+'<small>'+esc([...new Set(X.bindings(p,filters).map(v=>v.contractSubgroup))].join(' · '))+'</small></td><td>'+p.counts.TL+' fixos · '+p.counts.CE+' celulares · '+p.counts.EM+' e-mails</td><td><span class="badge '+(p.errors?'fail':p.warnings?'warn':'pass')+'">'+esc(p.status)+'</span><small>'+p.errors+' erros · '+p.warnings+' alertas</small></td><td>'+esc(p.treatmentStatus)+'</td><td><button class="quiet" data-person-detail="'+esc(p.id)+'">Consultar</button></td></tr>').join('')+'</tbody></table></div><div class="exec-pagination"><label>Registros por página<select id="execSize"><option value="20" '+(personSize===20?'selected':'')+'>20</option><option value="100" '+(personSize===100?'selected':'')+'>100</option></select></label><span>Página '+n(personPage)+' de '+n(pages)+'</span><button class="secondary" id="execBack" '+(personPage===1?'disabled':'')+'>Anterior</button><button class="secondary" id="execNext" '+(personPage===pages?'disabled':'')+'>Próxima</button></div></div>';
 }
 function selectedChanges(){return changeRows.filter(r=>(!changeType||(changeType==='entradas'?r.entered>0:changeType==='saidas'?r.exited>0:r.movement===changeType))&&(!changeRule||r.rule===changeRule));}
 function renderChanges(){
   const el=$('#execChanges');if(!el||!previous())return;
   changeRows=D.movementRows(current(),previous(),filters);const codes=new Map(B.catalog('Erro').map(r=>[r.id,r.code]));
   const rows=selectedChanges(),pages=Math.max(1,Math.ceil(rows.length/20));changePage=Math.max(1,Math.min(changePage,pages));
   el.innerHTML='<div class="change-controls"><label>Classificação<select id="execChangeType">'+[['entradas','Com entradas'],['saidas','Com saídas'],['aumento','Acréscimos líquidos'],['reducao','Reduções líquidas'],['persistente','Ocorrências mantidas'],['alteracao','Alteração das evidências'],['','Todas as variações']].map(([v,l])=>'<option value="'+v+'" '+(changeType===v?'selected':'')+'>'+l+'</option>').join('')+'</select></label><label>Apontamento<select id="execChangeRule"><option value="">Todos</option>'+B.catalog('Erro').map(r=>'<option value="'+r.id+'" '+(changeRule===r.id?'selected':'')+'>'+r.code+' · '+esc(r.description)+'</option>').join('')+'</select></label><span>'+n(rows.length)+' combinações de matrícula e regra</span><button id="execExportChanges" class="secondary" '+(!rows.length?'disabled':'')+'>Exportar investigação</button></div><div class="scroll-table"><table><thead><tr><th>Participante / código</th><th>Anterior → atual / entradas e saídas</th><th>Motivo da variação</th><th>Evidências / chaves</th></tr></thead><tbody>'+rows.slice((changePage-1)*20,changePage*20).map(r=>'<tr><td><b>'+esc(r.nome)+'</b><small>'+esc(r.master||r.matricula)+' · '+codes.get(r.rule)+' · '+esc(r.label)+'</small></td><td>'+n(r.previous)+' → '+n(r.current)+'<small class="'+(r.delta>0?'increase':'decrease')+'">'+(r.delta>0?'+':'')+n(r.delta)+'</small><small>Entradas: '+(r.entered==null?'—':n(r.entered))+' · Saídas: '+(r.exited==null?'—':n(r.exited))+'</small></td><td>'+esc(r.reason)+'</td><td><details><summary>Comparar evidências</summary><b>Anterior</b><p>'+esc(r.previousEvidence||'Sem ocorrência no recorte anterior').replace(/\n/g,'<br>')+'</p><b>Atual</b><p>'+esc(r.currentEvidence||'Sem ocorrência no recorte atual').replace(/\n/g,'<br>')+'</p><small>Chave anterior: '+esc(r.previousKeys||'—').replace(/\n/g,'<br>')+'<br>Chave atual: '+esc(r.currentKeys||'—').replace(/\n/g,'<br>')+'</small></details></td></tr>').join('')+'</tbody></table></div><div class="exec-pagination"><span>Página '+n(changePage)+' de '+n(pages)+'</span><button id="execChangeBack" class="secondary" '+(changePage===1?'disabled':'')+'>Anterior</button><button id="execChangeNext" class="secondary" '+(changePage===pages?'disabled':'')+'>Próxima</button></div><p class="hint">A saída do público avaliado ou a alteração de enquadramento não comprova correção cadastral. Consulte a evidência e as quantidades de cada período.</p>';
 }
 async function render(changed=''){
   const token=++renderToken;controls();const exists=!!current();$('#execEmpty').hidden=exists;$('#execLoaded').hidden=!exists;if(!exists)return;
   $('#execLoading').hidden=false;await pause();await ensurePair();if(token!==renderToken)return;
   facets(changed);const ps=scope();$('#execScope').textContent=(current().classification==='demonstration'?'Demonstração fictícia · ':'')+'Fotografia '+date(current().photo)+' · '+n(ps.length)+' participantes no recorte';
   $('#execSourceStatus').textContent=origin+(current().migrationNote?' · histórico convertido; evidências anteriores parcialmente disponíveis':'');
   if(token!==renderToken)return;overview(ps);evolution();highlights(ps);people(ps);demographicChart(ps);$('#execFilterCaption').textContent='Filtros do painel'+(Object.values(filters).some(Boolean)?' · '+Object.values(filters).filter(Boolean).length+' aplicado(s)':'');$('#execLoading').hidden=true;
 }
 async function exportChanges(){
   const rows=selectedChanges(),codes=new Map(B.catalog('Erro').map(r=>[r.id,r.code]));
   const table=[['Matrícula Petros','Nome','Código','Erro identificado','Quantidade anterior','Quantidade atual','Entradas','Saídas','Variação','Classificação','Motivo da variação','Evidência anterior','Evidência atual','Chave anterior','Chave atual','Fotografia anterior','Fotografia atual'],...rows.map(r=>[r.master||r.matricula,r.nome,codes.get(r.rule),r.label,r.previous,r.current,r.entered,r.exited,r.delta,r.movement,r.reason,r.previousEvidence,r.currentEvidence,r.previousKeys,r.currentKeys,date(previous().photo),date(current().photo)])];
   const blob=await W.workbook({Investigacao:table},null,{variant:'batch',sheetMeta:{Investigacao:{title:'Investigação das variações de apontamentos',studyDate:new Date(current().photo+'T00:00:00Z'),generatedAt:B.generationDate(new Date()),scope:H.SCOPE}}});U.downloadBlob(blob,'PIC_INVESTIGACAO_'+current().photo+'.xlsx');
 }
 async function init(){
   $('#themeBtn').onclick=()=>document.body.classList.toggle('dark');
   $('#closeDetail').onclick=()=>$('#detailDialog').close();
   $('#historyClose').onclick=()=>$('#historyDialog').close();$('#historyOpen').onclick=chooseFile;$('#historyManualOpen').onclick=()=>$('#historyInput').click();
   $('#historyReconnect').onclick=reconnect;$('#execOpen').onclick=openHistory;$('#execEmptyOpen').onclick=openHistory;
   $('#historyInput').onchange=async e=>{const file=e.target.files[0];if(!file)return;try{await work('Carregando histórico',p=>accept(file,null,p));}catch(err){message(err.message);}finally{e.target.value='';}};
   $('#execPhoto').onchange=e=>{selected=e.target.value;priorId='';filters={};$('#execSearch').value='';personPage=1;changesOpen=false;render().catch(e=>notify(e.message));};
   $('#execPrevious').onchange=e=>{priorId=e.target.value;changesOpen=false;render().catch(e=>notify(e.message));};
   $('#execLoaded').onchange=e=>{const key=e.target.dataset.execFilter;if(key){filters[key]=e.target.value;personPage=1;render(key).catch(e=>notify(e.message));}else if(e.target.id==='execCuriosity'){filters.curiosity=e.target.value;personPage=1;render().catch(e=>notify(e.message));}};
   $('#execSearch').oninput=U.debounce(e=>{filters.search=e.target.value;delete filters.person;personPage=1;render().catch(e=>notify(e.message));},250);
   const reset=()=>{filters={};$('#execSearch').value='';personPage=1;changesOpen=false;return render().catch(e=>notify(e.message));};$('#execStickyReset').onclick=reset;
   $('#execFilterToggle').onclick=()=>{const body=$('#execFilterBody'),collapsed=!body.hidden;body.hidden=collapsed;$('#execFilterToggle').textContent=collapsed?'+ Expandir':'− Recolher';$('#execFilterToggle').setAttribute('aria-expanded',String(!collapsed));};
   $('#page-executive').addEventListener('change',e=>{
     if(e.target.id==='execSize'){personSize=+e.target.value;personPage=1;people(scope());}
     if(e.target.id==='execChangeType'){changeType=e.target.value;changePage=1;renderChanges();}
     if(e.target.id==='execChangeRule'){changeRule=e.target.value;changePage=1;renderChanges();}
   });
   $('#page-executive').addEventListener('click',async e=>{
     const b=e.target.closest('button');if(!b)return;
     try{
       if(b.dataset.ageBand){filters.ageBand=filters.ageBand===b.dataset.ageBand?'':b.dataset.ageBand;personPage=1;changesOpen=false;await render('ageBand');}
       else if(b.dataset.dimension){filters[b.dataset.dimension]=b.dataset.value;await render(b.dataset.dimension);}
       else if(b.dataset.rule){filters.rule=b.dataset.rule;personPage=1;peopleExpanded=true;await render('rule');$('#execPeople').scrollIntoView?.({behavior:'smooth',block:'start'});}
       else if(b.dataset.coverage){filters.coverage=filters.coverage===b.dataset.coverage?'':b.dataset.coverage;personPage=1;await render('coverage');}
       else if(b.dataset.exclusion){filters.exclusion=filters.exclusion===b.dataset.exclusion?'':b.dataset.exclusion;personPage=1;await render('exclusion');}
       else if(b.dataset.quality){filters.status=b.dataset.quality;await render('status');}
       else if(b.dataset.resetQuality){delete filters.status;await render();}
       else if(b.dataset.person){filters.person=b.dataset.person;filters.search='';$('#execSearch').value=b.dataset.person;personPage=1;peopleExpanded=true;await render();$('#execPeople').scrollIntoView?.({behavior:'smooth',block:'start'});}
       else if(b.dataset.curiosity){filters.curiosity=b.dataset.curiosity;personPage=1;peopleExpanded=true;await render();$('#execPeople').scrollIntoView?.({behavior:'smooth',block:'start'});}
       else if(b.dataset.personDetail){showPerson(b.dataset.personDetail); }
       else if(b.dataset.movementRule||b.dataset.openMovements||b.id==='execInvestigate'){changesOpen=true;changeRule=b.dataset.movementRule||'';changeType=b.dataset.movementType||b.dataset.openMovements||'aumento';changePage=1;renderChanges();$('#execChanges').scrollIntoView?.({behavior:'smooth',block:'start'});}
       else if(b.id==='execPeopleToggle'){peopleExpanded=!peopleExpanded;$('#execPeopleBody').hidden=!peopleExpanded;b.textContent=peopleExpanded?'− Recolher':'+ Expandir';b.setAttribute('aria-expanded',String(peopleExpanded));}
       else if(b.id==='execExport'){b.disabled=true;const ps=scope(),blob=await X.treatment(ps,{...filters,includeContext:true},null);U.downloadBlob(blob,'PIC_RECORTE_'+current().photo+'.xlsx');b.disabled=false;}
       else if(b.id==='execExportChanges'){b.disabled=true;await exportChanges();b.disabled=false;}
       else if(b.id==='execBack'){personPage--;people(scope());}else if(b.id==='execNext'){personPage++;people(scope());}
       else if(b.id==='execChangeBack'){changePage--;renderChanges();}else if(b.id==='execChangeNext'){changePage++;renderChanges();}
     }catch(err){notify(err.message);b.disabled=false;}
   });
   $('#historyTable').addEventListener('click',e=>{const b=e.target.closest('[data-history-run]');if(b){selected=b.dataset.historyRun;priorId='';filters={};$('#historyDialog').close();return render().catch(e=>notify(e.message));}});

   loading=true;controls();
   try{
     const cached=await P.loadDatabase(async(r,version)=>{if(version===2){const migrated=H.migrate(r);await H.pack(migrated,JSZip);migrated.people=null;return migrated;}return r;});
     if(cached){db=H.validate({...cached,version:H.VERSION});origin='Histórico local de Comunicação';}
   }catch(e){message('Cópia local indisponível. Abra o arquivo .pic. '+e.message);}
   try{
     handle=await P.read('panel-handle')||await P.read('handle')||null;
     if(handle){
       if(await P.permission(handle)){const file=await handle.getFile();await accept(file,handle,null,true);}
       else origin+=' · reautorize o arquivo vinculado para conferir a versão central';
     }
   }catch(e){message('O arquivo vinculado não pôde ser conferido. '+e.message);}
   finally{loading=false;$('#execBoot').hidden=true;await render();}
 }
 const ready=init().catch(e=>notify('O histórico não pôde ser carregado. '+e.message));
 globalThis.ComHistoryUI={render,openHistory,ready,get database(){return db;}};
})();
