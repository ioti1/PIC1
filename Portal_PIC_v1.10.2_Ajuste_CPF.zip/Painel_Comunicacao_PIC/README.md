# PIC · Painel de Indicadores de Meios de Comunicação

Abra `index.html` diretamente ou clique no cartão **Meios de Comunicação** no Portal PIC. A fotografia mais recente é selecionada automaticamente quando o histórico operacional local está disponível ou o arquivo vinculado pode ser lido com a autorização existente.

Se não houver histórico acessível, use **Abrir histórico** e selecione o mesmo arquivo `.pic` da Central Operacional. O navegador pode pedir permissão de leitura, especialmente em uma instalação nova. Não é necessário reprocessar as planilhas. Este painel não grava alterações no histórico central, não processa bases e não altera o tratamento.

**Excluídos Digitais** conta pessoas elegíveis no recorte que não têm e-mail válido nem celular válido; um telefone fixo válido não retira a pessoa desse grupo. **Sem canal válido** também verifica o telefone fixo. A validade é estrutural, não confirma entrega nem titularidade. Os dois cartões aplicam o filtro correspondente.

**Participantes por Situação** mantém a contagem de pessoas com erro por subsituação contratual. Quem tem múltiplos vínculos pode integrar mais de uma categoria. A Central 4.2.2 continua independente.
