# Manutenção · Central Operacional 4.2.2

O ponto de entrada é page-load. Foram retirados os HTML, CSS e eventos da Visão Executiva e do antigo menu de dois ambientes. history-ui.js mantém captura, gravação, retomada, verificação do arquivo vinculado e comparação mensal para os relatórios. history.css contém somente o estilo da operação de histórico. executive-data.js continua como módulo analítico interno dos relatórios, sem montar telas.

As regras, o esquema do histórico PIC v3, a persistência e os formatos dos relatórios foram mantidos. A Central independente fica nesta pasta, com os mesmos arquivos no módulo de Comunicação do HUB legado. O pacote com o Portal PIC contém esta pasta como irmã do portal; assim o atalho relativo funciona offline.

Validação sintética: tools/central-v41-qa/separation-v422.cjs. Nenhuma base de produção faz parte dos pacotes.
