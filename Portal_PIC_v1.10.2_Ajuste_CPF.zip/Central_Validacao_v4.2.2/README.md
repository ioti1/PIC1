# PIC · Central Operacional de Comunicação · 4.2.2

Esta versão abre em **Preparar bases** e reúne o processamento mensal, a análise operacional, a fila de tratamento e a geração de relatórios. A Visão Executiva interativa não faz parte desta versão. A edição 4.2.1 foi preservada em seu pacote anterior.

1. Abra `index.html` pelo Explorador. Importe o público oficial, revise o mapeamento e informe a data da fotografia.
2. Processe o público e adicione a base de contatos. A data é herdada do público oficial.
3. Valide, examine o universo e trate os apontamentos. Gere o PDF gerencial ou os lotes de evidências (HTML e Excel).
4. Use **Histórico & base** para abrir, salvar ou retomar uma fotografia já processada. **Retomar** leva ao universo e à fila daquele período, sem reprocessar as planilhas. Relatórios usam o mês anterior quando houver histórico comparável.

Os formatos de entrada e do histórico `.pic` não mudaram. Se a nova pasta não carregar a cópia local do navegador, abra seu arquivo `PIC_Historico.pic` pelo botão de histórico. As bases continuam locais; não há envio, hospedagem nem login na aplicação. Mantenha o arquivo de histórico em uma pasta restrita.
