(function(root,factory){
  const node=typeof module==='object'&&module.exports;
  const api=factory(node?require('./model.js'):root.ComModel,node?require('./reconcile.js'):root.ComReconcile,node?require('./audit.js'):root.ComAudit);
  if(node)module.exports=api;else root.ComHistory=api;
})(globalThis,function(M,R,A){
  'use strict';
  const FORMAT='PIC-HISTORICO',VERSION=3,POLICY='publico-sem-obito-v1',MAX_RUNS=240;
  const SCOPE='Este estudo não contempla participantes e pensionistas com morte presumida, nem a base corporativa do I-Petros.';
  const omit=(o,keys)=>Object.fromEntries(Object.entries(o).filter(([k])=>!keys.includes(k)));
  const pause=()=>new Promise(resolve=>setTimeout(resolve,0));
  const fresh=()=>({format:FORMAT,version:VERSION,id:crypto.randomUUID(),revision:0,updatedAt:new Date().toISOString(),runs:[]});
  const stringify=o=>JSON.stringify(o,function(k,v){return this[k] instanceof Date?{$picDate:this[k].toISOString()}:v;});
  function parse(text){return JSON.parse(text,(k,v)=>{
    if(['__proto__','constructor','prototype'].includes(k))throw Error('O arquivo contém uma estrutura não permitida.');
    if(v&&typeof v==='object'&&Object.keys(v).length===1&&typeof v.$picDate==='string'){
      const d=new Date(v.$picDate);if(!Number.isFinite(+d))throw Error('O arquivo contém uma data inválida.');return d;
    }return v;
  });}
  function dateOK(s){if(typeof s!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(s))return false;const d=new Date(s+'T00:00:00Z');return Number.isFinite(+d)&&d.toISOString().slice(0,10)===s;}
  function cleanIssue(i){const keys=['rule','ruleLabel','severity','risk','problem','problemCode','field','message','suggestion','raw','contactId','bindingId','migrationNote','observedDigits','expectedDigits','digitDelta','digitsMissing','digitsExcess'];return Object.fromEntries(keys.filter(k=>i[k]!==undefined).map(k=>[k,i[k]]));}
  function contact(c){return {
    id:c.id,participantId:c.participantId,typeCode:c.typeCode,type:c.type,label:c.label,raw:c.raw,normalized:c.normalized,ddd:c.ddd,
    present:c.present,valid:c.valid,valuePresent:c.valuePresent,sequence:c.sequence,registrationDate:c.registrationDate,
    registrationUser:c.registrationUser,registrationDay:c.registrationDay,sourceRow:c.sourceRow,sourceFile:c.sourceFile,
    sourceSheet:c.sourceSheet,snapshotDate:c.snapshotDate,matchState:'No público oficial',treatedAt:c.treatedAt||'',
    rawValues:{tipo:c.rawValues?.tipo,ddd:c.rawValues?.ddd,numero:c.rawValues?.numero,email:c.rawValues?.email,data_registro:c.rawValues?.data_registro,usuario_registro:c.rawValues?.usuario_registro},
    allIssues:(c.allIssues||c.issues||[]).map(cleanIssue)
  };}
  function binding(v){return {
    plano:v.plano,patrocinador:v.patrocinador,contractGroup:v.contractGroup,contractSubgroup:v.contractSubgroup,
    situacao:v.situacao||'',beneficio:v.beneficio||'',sex:M.normalizeSex(v.values?.sexo||v.sex),birth:v.birth||null,age:v.age,sourceFile:v.sourceFile||'',
    sourceSheet:v.sourceSheet||'',sourceRow:v.sourceRow||0,
    values:{matricula:v.values?.matricula,nascimento:v.values?.nascimento||'',sexo:M.normalizeSex(v.values?.sexo||v.sex),obito:''}
  };}
  function project(p){
    const cs=p.channels||[],seen=new Set(),vinculos=[];
    for(const v of p.vinculos){const b=binding(v),key=stringify([b.plano,b.patrocinador,b.contractGroup,b.contractSubgroup,b.values.matricula,b.values.nascimento,b.sex,b.age]);if(!seen.has(key)){seen.add(key);vinculos.push(b);}}
    return {
      id:p.id,matricula:p.matricula,nome:p.nome,snapshotDate:p.snapshotDate,eligible:true,age:p.age??null,ageBand:p.ageBand,
      ageSource:p.ageSource||'',sex:M.participantSex(p),vinculos,counts:{...p.counts},validCounts:{...p.validCounts},registryCount:p.registryCount??null,
      presentChannels:p.presentChannels,validChannels:p.validChannels,coverage:p.coverage,exclusions:{...p.exclusions},
      contextTreatedAt:p.contextTreatedAt||'',allContextIssues:(p.allContextIssues||p.contextIssues||[]).map(cleanIssue),
      evidenceContacts:cs.filter(c=>(c.allIssues||c.issues||[]).length).map(contact)
    };
  }
  function makePeople(run){
    if(!run.people)throw Error('A fotografia está compactada. Aguarde o carregamento do período.');
    return run.people;
  }
  function attach(run){
    const requested=new Set(run.result.selection),ps=run.people;
    for(let index=0;index<ps.length;index++){
      const p=ps[index];p.index=index;p.minimal=true;p.channels=p.evidenceContacts||[];
      p.allContextIssues=p.allContextIssues||[];p.contextIssues=p.allContextIssues.filter(i=>requested.has(i.rule));
      for(const c of p.channels){c.participant=p;c.participantId=p.id;c.matricula=p.matricula;c.nome=p.nome;c.issues=(c.allIssues||[]).filter(i=>requested.has(i.rule));c.errors=c.issues.filter(i=>i.severity==='Erro').length;c.warnings=c.issues.length-c.errors;c.status=c.errors?'Inconsistente':c.warnings?'Com ressalvas':requested.size?'Consistente':'Não avaliado';c.treatmentStatus=c.issues.length?(c.treatedAt?'Tratado':'Pendente'):'Sem pendência';}
    }
    const contacts=ps.flatMap(p=>p.channels);contacts.forEach((c,i)=>c.index=i);
    const result={...run.result,participants:ps,records:ps,contacts,bindings:ps.flatMap(p=>p.vinculos),minimal:true,policy:POLICY,
      migrationNote:run.migrationNote||'',sourceModelVersion:run.sourceModelVersion||M.version,participantIndex:new Map(ps.map(p=>[p.id,p])),contactIndex:new Map(contacts.map(c=>[c.id,c]))};
    R.refresh(result);return result;
  }
  function wirePerson(p){return {...omit(p,['channels','issues','contextIssues','index','minimal']),evidenceContacts:(p.evidenceContacts||p.channels||[]).map(c=>omit(c,['participant','issues','errors','warnings','status','treatmentStatus','index','nome','matricula']))};}
  function capture(state){
    const r=state.result;if(!r||r.photos.length!==1)throw Error('Conclua a validação antes de registrar a fotografia.');
    const ps=r.participants.filter(R.assessable).map(project);
    const run={id:r.runId,photo:r.photos[0],savedAt:new Date().toISOString(),modelVersion:M.version,policy:POLICY,minimal:true,
      migrationNote:r.migrationNote||'',sourceModelVersion:r.sourceModelVersion||M.version,
      classification:state.sources?.length&&state.sources.every(s=>s.id.startsWith('demo-'))?'demonstration':'user-data',
      sourceSummary:(state.sources||[]).map(s=>({filename:s.filename,role:s.role,sheet:s.sheet,rows:s.rowCount??s.rows?.length??0,snapshotDate:s.snapshotDate})),
      result:{version:M.version,runId:r.runId,processedAt:r.processedAt,referenceDate:r.referenceDate,scope:r.scope,officialScope:r.officialScope,
        selection:[...r.selection],evaluatedRules:r.evaluatedRules||[...r.selection],photos:[...r.photos],totalContacts:r.totalContacts===undefined?r.contacts.length:r.totalContacts,
        officialInputRows:r.officialInputRows,contactInputRows:r.contactInputRows},
      people:ps,data:null,personCount:ps.length};
    attach(run);run.summary=R.summarize(ps);run.cube=makeCube(run);return run;
  }
  function makeCube(run){
    const groups=new Map();
    for(const p of run.people){
      const profiles=[...new Map(p.vinculos.map(v=>[stringify([v.plano,v.patrocinador,v.contractGroup,v.contractSubgroup]),{plano:v.plano,patrocinador:v.patrocinador,contractGroup:v.contractGroup,contractSubgroup:v.contractSubgroup,values:{obito:''}}])).values()];
      const rules=[...new Set(p.issues.map(i=>i.rule))].sort();
      const prototype={eligible:true,matricula:'',nome:'',snapshotDate:run.photo,ageBand:p.ageBand,status:p.status,treatmentStatus:p.treatmentStatus,coverage:p.coverage,exclusions:p.exclusions,counts:Object.fromEntries(Object.entries(p.counts).map(([k,v])=>[k,v>0?1:0])),validCounts:Object.fromEntries(Object.entries(p.validCounts).map(([k,v])=>[k,v>0?1:0])),vinculos:profiles,issues:rules.map(rule=>({rule}))};
      const key=stringify(prototype),m=R.summarize([p]);m.withoutMobile=p.exclusions.sem_celular?1:0;m.withoutPhone=p.exclusions.sem_fixo?1:0;
      if(!groups.has(key))groups.set(key,{p:prototype,m});else{const g=groups.get(key);for(const k of Object.keys(m))g.m[k]=(g.m[k]||0)+m[k];}
    }return [...groups.values()];
  }
  function assertRun(run){
    if(!run||typeof run.id!=='string'||!dateOK(run.photo)||run.policy!==POLICY||run.modelVersion!==M.version||!run.result||run.result.runId!==run.id||!Array.isArray(run.result.selection)||!Number.isInteger(run.personCount)||run.personCount<0||!Array.isArray(run.cube))throw Error('A fotografia não é compatível com esta versão.');
    if(run.people){const ids=new Set();for(const p of run.people){
      if(typeof p.id!=='string'||ids.has(p.id)||typeof p.matricula!=='string'||typeof p.nome!=='string'||!R.assessable(p)||p.snapshotDate!==run.photo||!Array.isArray(p.evidenceContacts)||!Array.isArray(p.allContextIssues))throw Error('O histórico contém um cadastro incompatível.');ids.add(p.id);
      for(const t of ['TL','CE','EM'])if(!Number.isInteger(p.counts?.[t])||p.counts[t]<0||!Number.isInteger(p.validCounts?.[t])||p.validCounts[t]<0)throw Error('O histórico contém uma contagem de canais inválida.');
    }if(run.people.length!==run.personCount)throw Error('O total do histórico diverge do índice.');}
    else if(!(run.data instanceof Uint8Array))throw Error('Os registros compactados da fotografia não estão disponíveis.');
    if(!Number.isFinite(Date.parse(run.savedAt))||!Number.isFinite(Date.parse(run.result.processedAt))||!Array.isArray(run.result.evaluatedRules)||run.result.selection.some(id=>!M.rules.some(r=>r.id===id)))throw Error('Os critérios da fotografia estão inválidos.');let cubeTotal=0;for(const g of run.cube){if(!g?.p||!Array.isArray(g.p.vinculos)||!g.m||Object.values(g.m).some(v=>typeof v!=='number'||!Number.isFinite(v)||v<0))throw Error('O índice executivo contém valores inválidos.');cubeTotal+=g.m.identified||0;}if(cubeTotal!==run.personCount)throw Error('O índice executivo diverge do público avaliado.');
    return run;
  }
  function validate(db){if(!db||db.format!==FORMAT||db.version!==VERSION||typeof db.id!=='string'||!Array.isArray(db.runs)||db.runs.length>MAX_RUNS)throw Error('O arquivo não é um histórico PIC compatível.');db.runs.forEach(assertRun);return db;}
  function canonical(db){const real=db.runs.filter(r=>r.classification!=='demonstration'),months=new Map();for(const r of real.length?real:db.runs){const old=months.get(r.photo.slice(0,7));if(!old||r.photo>old.photo||r.photo===old.photo&&r.result.processedAt>old.result.processedAt)months.set(r.photo.slice(0,7),r);}return [...months.values()].sort((a,b)=>a.photo.localeCompare(b.photo));}
  function put(db,run){assertRun(run);db.runs=db.runs.filter(r=>r.photo.slice(0,7)!==run.photo.slice(0,7)||r.classification!==run.classification);db.runs.push(run);if(db.runs.length>MAX_RUNS)throw Error('O histórico atingiu 240 competências. Utilize um arquivo separado por exercício.');db.updatedAt=new Date().toISOString();return run;}
  function merge(a,b){validate(a);validate(b);const out={...a,runs:[...a.runs]};for(const r of b.runs){const old=out.runs.find(v=>v.photo.slice(0,7)===r.photo.slice(0,7)&&v.classification===r.classification);if(!old||r.photo>old.photo||r.photo===old.photo&&r.savedAt>old.savedAt)put(out,r);}return out;}
  const profile=r=>POLICY+'|'+(r.classification||'user-data')+'|'+[...r.result.selection].sort().join(';');
  function previous(db,current){const d=new Date(current.photo.slice(0,7)+'-01T00:00:00Z');d.setUTCMonth(d.getUTCMonth()-1);return canonical(db).find(r=>r.photo.slice(0,7)===d.toISOString().slice(0,7)&&r.classification===current.classification)||null;}
  function measure(run,f={}){
    if(f.search||f.person||f.curiosity||f.movement||f.ageBand)return null;
    const out={total:0,errorOccurrences:0,warningOccurrences:0,identified:0,pass:0,warn:0,fail:0,covered:0,uncovered:0,issues:0,pending:0,treated:0,pendingIssues:0,withoutRegistry:0,withoutEmail:0,withoutAny:0,withoutMobile:0,withoutPhone:0};
    for(const g of run.cube)if(R.participantMatch(g.p,f)&&(!f.rule||g.p.issues.some(i=>i.rule===f.rule))&&(!f.channel||(f.channel.endsWith(':valid')?g.p.validCounts[f.channel.split(':')[0]]>0:g.p.counts[f.channel.split(':')[0]]>0)))for(const k of Object.keys(out))out[k]+=g.m[k]||0;
    out.coverageRate=out.identified?out.covered/out.identified:null;out.errorRate=out.identified?out.fail/out.identified:null;return out;
  }
  async function pack(run,Zip,onProgress){
    if(run.data)return run;
    assertRun(run);const zip=new Zip(),parts=[],chunk=1000;
    for(let i=0;i<run.people.length;i+=chunk){
      const path='p'+parts.length+'.json',text=stringify(run.people.slice(i,i+chunk).map(wirePerson));
      if(new TextEncoder().encode(text).length>32*1024*1024)throw Error('Um bloco de evidências excede o limite de 32 MB. Nenhum dado foi reduzido.');
      zip.file(path,text);parts.push(path);onProgress?.({percent:10+Math.round(i/Math.max(run.personCount,1)*35),phase:'Organizando histórico',detail:(i+1).toLocaleString('pt-BR')+' de '+run.personCount.toLocaleString('pt-BR')+' participantes'});await pause();
    }
    zip.file('index.json',JSON.stringify({parts,personCount:run.personCount}));
    run.data=await zip.generateAsync({type:'uint8array',streamFiles:true,compression:'DEFLATE',compressionOptions:{level:1}},p=>onProgress?.({percent:45+Math.round(p.percent*.45),phase:'Compactando histórico',detail:Math.round(p.percent)+'% da fotografia'}));
    return run;
  }
  const crcTable=Array.from({length:256},(_,i)=>{for(let j=0;j<8;j++)i=i&1?0xedb88320^(i>>>1):i>>>1;return i>>>0;});
  function crc32(bytes){let n=0xffffffff;for(const b of bytes)n=crcTable[(n^b)&255]^(n>>>8);return(n^0xffffffff)>>>0;}
  async function readEntry(zip,path,max=256*1024*1024){const e=zip.file(path);if(!e||e._data?.uncompressedSize>max)throw Error('O arquivo está incompleto ou excede o limite de segurança.');const b=await e.async('uint8array');if(b.length>max||crc32(b)!==(e._data.crc32>>>0))throw Error('A conferência de integridade do arquivo falhou.');return b;}
  const readJSON=async(zip,path,max)=>parse(new TextDecoder('utf-8',{fatal:true}).decode(await readEntry(zip,path,max)));
  async function expand(run,Zip,onProgress){
    if(run.people)return run;
    const zip=await Zip.loadAsync(run.data),index=await readJSON(zip,'index.json',1024*1024);
    if(!Array.isArray(index.parts)||index.parts.length>2000||index.personCount!==run.personCount)throw Error('O índice da fotografia está inválido.');
    const ps=[];
    for(let i=0;i<index.parts.length;i++){const path=index.parts[i];if(path!=='p'+i+'.json')throw Error('O índice contém uma parte não reconhecida.');const rows=await readJSON(zip,path,32*1024*1024);if(!Array.isArray(rows)||rows.length>1000)throw Error('O bloco de participantes está inválido.');ps.push(...rows);if(i%5===0){onProgress?.({percent:Math.round(i/Math.max(1,index.parts.length)*100),phase:'Carregando fotografia',detail:run.photo});await pause();}}
    run.people=ps;attach(run);assertRun(run);return run;
  }
  function evict(db,keep=[]){for(const r of db.runs)if(!keep.includes(r.id)&&r.data)r.people=null;}
  function hydrate(run){
    assertRun(run);if(!run.people)throw Error('Carregue a fotografia antes de iniciar a consulta.');
    // Clone only audit facts and evidence. Source workbooks and valid contact values are never reconstructed.
    const ps=run.people.map(p=>({...p,vinculos:p.vinculos.map(v=>({...v,values:{...v.values}})),allContextIssues:p.allContextIssues.map(i=>({...i})),evidenceContacts:p.evidenceContacts.map(c=>({...c,rawValues:{...c.rawValues},allIssues:c.allIssues.map(i=>({...i}))}))}));
    const temp={...run,people:ps},result=attach(temp),sources=run.sourceSummary.map((s,i)=>({...s,id:'historico-'+i,headers:[],mapping:{},headerRow:1,book:{[s.sheet||'Histórico']:[]},rows:{length:s.rows||0},rowCount:s.rows||0,archived:true}));
    return {result,official:{scope:run.result.officialScope||run.result.scope,photos:[run.photo],identified:run.personCount,bindings:result.bindings,participants:ps},sources,selection:[...result.selection],marks:{}};
  }
  async function encode(db,Zip,onProgress){
    validate(db);const zip=new Zip(),runs=[];
    for(let i=0;i<db.runs.length;i++){
      const r=await pack(db.runs[i],Zip,onProgress);const path='m'+i+'.bin';zip.file(path,r.data,{compression:'STORE'});runs.push({...omit(r,['people','data']),path});onProgress?.({percent:90+Math.round((i+1)/Math.max(1,db.runs.length)*5),phase:'Preparando arquivo de histórico',detail:(i+1)+' de '+db.runs.length+' competências'});await pause();
    }
    zip.file('manifest.json',stringify({...omit(db,['runs']),runs}));
    const blob=await zip.generateAsync({type:'blob',streamFiles:true,compression:'DEFLATE',compressionOptions:{level:1}},p=>onProgress?.({percent:95+Math.round(p.percent*.04),phase:'Concluindo arquivo',detail:Math.round(p.percent)+'%'}));
    if(blob.size>512*1024*1024)throw Error('O histórico excede 512 MB compactados. Utilize um arquivo por exercício.');return blob;
  }
  async function decode(file,Zip,onProgress){
    if(file.size>1024*1024*1024)throw Error('O arquivo excede 1 GB.');
    const zip=await Zip.loadAsync(await file.arrayBuffer()),manifest=await readJSON(zip,'manifest.json',32*1024*1024);
    if(manifest.format!==FORMAT||!Array.isArray(manifest.runs)||manifest.runs.length>600||manifest.version===VERSION&&manifest.runs.length>MAX_RUNS)throw Error('O arquivo não é um histórico PIC reconhecido.');
    if(manifest.version===2){
      const out={...manifest,version:VERSION,runs:[]};
      for(let i=0;i<manifest.runs.length;i++){
        const r=manifest.runs[i];if(r.path!=='runs/'+i+'/')throw Error('O histórico anterior contém um caminho inválido.');
        const facts=legacyFacts(await readJSON(zip,r.path+'facts.json'),r.photo);
        const migrated=migrate({...r,people:facts});await pack(migrated,Zip,onProgress);migrated.people=null;put(out,migrated);await pause();
      }out.migrated=true;return validate(out);
    }
    if(manifest.version!==VERSION)throw Error('A versão deste histórico não é compatível.');
    const expected=new Set(['manifest.json']);
    for(let i=0;i<manifest.runs.length;i++){const r=manifest.runs[i];if(r.path!=='m'+i+'.bin')throw Error('O índice do histórico contém um caminho inválido.');expected.add(r.path);r.data=await readEntry(zip,r.path);r.people=null;delete r.path;onProgress?.({percent:Math.round((i+1)/manifest.runs.length*100),phase:'Lendo histórico',detail:(i+1)+' de '+manifest.runs.length+' competências'});await pause();}
    if(Object.keys(zip.files).some(k=>!zip.files[k].dir&&!expected.has(k)))throw Error('O histórico contém arquivos não reconhecidos.');
    return validate(manifest);
  }
  function migrate(old){
    if(old.minimal&&old.policy===POLICY)return old;
    const available=old.result.selection||[],ps=[];
    for(const original of old.people||[]){const p=original.vinculos?original:{...original,vinculos:(original.bindingRefs||[]).map(i=>old.bindings[i]),issues:[...(original.contextIssues||[]),...(original.contactRefs||[]).flatMap(i=>old.contacts[i].issues||[])]};
      if(!R.assessable(p))continue;
      const context=(p.issues||[]).filter(i=>i.rule!=='death').map(i=>({...cleanIssue(i),migrationNote:true}));
      ps.push({...p,vinculos:p.vinculos.map(binding),allContextIssues:context,evidenceContacts:[],contextTreatedAt:p.treatmentStatus==='Tratado'?p.treatedAt||old.savedAt:'',minimal:true});
    }
    const r={id:old.id,photo:old.photo,savedAt:old.savedAt,modelVersion:M.version,sourceModelVersion:old.modelVersion,policy:POLICY,minimal:true,
      classification:old.classification||'user-data',sourceSummary:old.sourceSummary||[],result:{...old.result,version:M.version,evaluatedRules:available.filter(id=>id!=='shared'),totalContacts:null},
      people:ps,personCount:ps.length,data:null,migrationNote:'Histórico anterior: perfil e contagens preservados; detalhes de origem não foram copiados.'};
    attach(r);r.summary=R.summarize(ps);r.cube=makeCube(r);return r;
  }
  function legacyFacts(data,photo){if(data?.factsFormat!==1||!Array.isArray(data.rows)||data.rows.length>2000000||!Array.isArray(data.texts)||data.texts.some(v=>typeof v!=='string')||!Array.isArray(data.eKeys)||data.eKeys.length>30||data.eKeys.some(k=>typeof k!=='string')||!Array.isArray(data.profiles)||!Array.isArray(data.issues))throw Error('Índice executivo incompatível.');return data.rows.map(r=>{if(!Array.isArray(r)||r.length!==18||!Array.isArray(r[10])||r[10].length!==3||!Array.isArray(r[11])||r[11].length!==3||!Array.isArray(r[15])||!Array.isArray(r[16])||r[15].some(i=>!Number.isInteger(i)||!data.profiles[i])||r[16].some(i=>!Number.isInteger(i)||!data.issues[i]))throw Error('Linha executiva inválida.');return {id:r[0],matricula:r[1],nome:r[2],age:r[3],snapshotDate:photo,ageBand:data.texts[r[4]],errors:r[5],warnings:r[6],status:data.texts[r[7]],treatmentStatus:data.texts[r[8]],pendingIssues:r[9],counts:{TL:r[10][0],CE:r[10][1],EM:r[10][2]},validCounts:{TL:r[11][0],CE:r[11][1],EM:r[11][2]},validChannels:r[12],coverage:data.texts[r[13]],exclusions:Object.fromEntries(data.eKeys.map((k,i)=>[k,!!(r[14]&1<<i)])),vinculos:r[15].map(i=>data.profiles[i]),issues:r[16].map(i=>data.issues[i]),channels:[],eligible:r[17]};});}
  async function migrateDatabase(db,Zip,onProgress){if(db.version===VERSION)return validate(db);if(db.version!==2)throw Error('Abra o arquivo de histórico compatível para continuar.');const out={...db,version:VERSION,runs:[]};for(const r of db.runs){const migrated=migrate(r);await pack(migrated,Zip,onProgress);migrated.people=null;put(out,migrated);}out.migrated=true;return validate(out);}
  return {FORMAT,VERSION,POLICY,SCOPE,fresh,capture,captureTreatment:(_old,state)=>capture(state),validate,assertRun,people:makePeople,put,merge,canonical,previous,profile,measure,hydrate,pack,seal:pack,expand,materialize:expand,evict,encode,decode,migrate,migrateDatabase,stringify,parse,wirePerson};
});

