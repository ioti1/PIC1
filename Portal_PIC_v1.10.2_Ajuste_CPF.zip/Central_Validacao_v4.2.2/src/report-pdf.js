(function(root,factory){const node=typeof module==='object'&&module.exports;const api=factory(root,node?require('./reconcile.js'):root.ComReconcile,node?require('./model.js'):root.ComModel,node?require('./utils.js'):root.CVCUtils,()=>node?require('./executive-data.js'):root.ComExecutiveData,node?require('./report-brand.js'):root.ComBrand);if(node)module.exports=api;else root.ComReportPDF=api;})(globalThis,function(root,R,M,U,getData,Brand){
  'use strict';
  async function generate(state,ps,filters={},comparison=null){
    ps=ps.filter(R.assessable);const D=getData();
    const {jsPDF}=root.jspdf,doc=new jsPDF({unit:'mm',format:'a4',compress:true});
    const W=210,H=297,left=17,right=193,bottom=274,navy=Brand.midnight,teal=Brand.azure,gold=Brand.coral,muted='#505C76',line='#D7DFF1',bg='#F0F3FC';
    function segments(dimension,source=ps){const scoped=source.map(p=>({...p,vinculos:p.vinculos.filter(v=>(!filters.plan||v.plano===filters.plan)&&(!filters.sponsor||v.patrocinador===filters.sponsor)&&(!filters.group||v.contractGroup===filters.group)&&(!filters.subgroup||v.contractSubgroup===filters.subgroup))}));return R.segments(scoped,dimension);}
    const s=R.summarize(ps),photo=state.result.photos[0],num=n=>Number(n).toLocaleString('pt-BR'),date=v=>v.split('-').reverse().join('/');let y=0;
    const clean=t=>String(t??'').replace(/[\x00-\x08\x0b\x0c\x0e-\x1f]/g,'').replace(/→|↗/g,'>').replace(/[—–‑]/g,'-');
    function text(t,x,yy,size=9,bold=false,color=navy,align='left'){doc.setFont('helvetica',bold?'bold':'normal');doc.setFontSize(size);doc.setTextColor(color);doc.text(clean(t),x,yy,{align});}
    function wrap(t,width,size=9,bold=false){doc.setFont('helvetica',bold?'bold':'normal');doc.setFontSize(size);return doc.splitTextToSize(clean(t),width);}
    function rule(yy,color=line,width=.2){doc.setDrawColor(color);doc.setLineWidth(width);doc.line(left,yy,right,yy);}
    function newPage(title='Qualidade cadastral'){
      doc.addPage();Brand.draw(doc,left,11,58);text('RELATÓRIO DE QUALIDADE CADASTRAL',right,17,7,true,muted,'right');rule(23);
      text(title,left,35,20,true);text('Fotografia '+date(photo)+' · Público oficial',left,42,8,false,muted);y=53;
    }
    function ensure(h,title){if(y+h>bottom)newPage(title);}
    function paragraph(t,size=8.5){for(const l of wrap(t,176,size)){ensure(5);text(l,left,y,size,false,muted);y+=4.4;}y+=4;}
    function table(title,headers,rows,widths,aligns=[]){
      const grid=()=>{
        text(title,left,y,12,true);y+=7;
        let x=left;const hs=headers.map((h,i)=>wrap(h,widths[i]-3,7.5,true)),hh=Math.max(...hs.map(v=>v.length))*3.5+4;
        headers.forEach((h,i)=>{hs[i].forEach((l,j)=>text(l,(aligns[i]|| (i?'right':'left'))==='right'?x+widths[i]-1:x,y+3+j*3.5,7.5,true,teal,aligns[i]||(i?'right':'left')));x+=widths[i];});y+=hh;rule(y,teal,.35);y+=2;
      };
      ensure(30,'Recortes e prioridades');grid();
      const data=rows.length?rows:[['Sem registros neste recorte',...headers.slice(1).map(()=> '—')]];
      for(const row of data){
        const cells=row.map((v,i)=>wrap(v,widths[i]-4,8.5));let offset=0,max=Math.max(...cells.map(c=>c.length));
        while(offset<max){
          let capacity=Math.floor((bottom-y-6)/4.1);
          if(capacity<1){newPage(title+' | continuação');grid();capacity=Math.floor((bottom-y-6)/4.1);}
          const take=Math.min(max-offset,capacity),height=take*4.1+4;let x=left;
          cells.forEach((ls,i)=>{ls.slice(offset,offset+take).forEach((l,j)=>text(l,(aligns[i]||(i?'right':'left'))==='right'?x+widths[i]-1:x,y+3+j*4.1,8.5,i>1,navy,aligns[i]||(i?'right':'left')));x+=widths[i];});
          y+=height;rule(y);y+=1;offset+=take;
          if(offset<max){newPage(title+' | continuação');grid();}
        }
      }
      y+=8;
    }
    function compactChange(x,top,width,previousValue,currentValue,previousPhoto,currentPhoto,unit){
      const c=U.changeStats(currentValue,previousValue),max=Math.max(1,previousValue,currentValue),color=c.delta>0?'#9F1846':teal;
      text(date(previousPhoto),x+3,top+3,7,false,muted);text(date(currentPhoto),x+width-3,top+3,7,false,muted,'right');
      text(num(previousValue),x+3,top+14,17,true,muted);text(num(currentValue),x+width-3,top+14,17,true,teal,'right');doc.setDrawColor(muted);doc.setLineWidth(.35);const ax=x+width/2,ay=top+11;doc.line(ax-3,ay,ax+3,ay);doc.line(ax+3,ay,ax+1.5,ay-1.3);doc.line(ax+3,ay,ax+1.5,ay+1.3);
      doc.setFillColor('#A7B9E7');if(previousValue)doc.roundedRect(x+3,top+20,(width-6)*previousValue/max,2,0.5,0.5,'F');
      doc.setFillColor(teal);if(currentValue)doc.roundedRect(x+3,top+24,(width-6)*currentValue/max,2,0.5,0.5,'F');
      const rate=c.rate==null?'sem base percentual':(c.delta>0?'+':c.delta<0?'-':'')+(Math.abs(c.rate)*100).toLocaleString('pt-BR',{minimumFractionDigits:1,maximumFractionDigits:1})+'%';
      text((c.delta>0?'+':'')+num(c.delta)+' '+unit+' ('+rate+')',x+3,top+34,8.3,true,color);
      text('Variação em relação ao mês anterior',x+3,top+41,6.7,false,muted);
    }
    function executiveSummary(){
      newPage('Síntese executiva');
      const prior=comparison?.previousPeople&&comparison.comparable!==false?R.summarize(comparison.previousPeople):null;
      const pct=v=>(v*100).toLocaleString('pt-BR',{minimumFractionDigits:1,maximumFractionDigits:1})+'%';
      const scopeText=Object.entries(filters).filter(([,v])=>v).map(([k,v])=>({plan:'Plano',sponsor:'Patrocinadora',group:'Situação',subgroup:'Subsituação',ageBand:'Faixa etária',exclusion:'Disponibilidade'}[k]||k)+': '+(M.exclusions.find(d=>d[0]===v)?.[1]||v)).join(' | ')||'Público oficial completo';
      wrap(scopeText,176,7.2).slice(0,2).forEach((l,i)=>text(l,left,49+i*3.5,7.2,false,muted));
      const profile=segments('contractGroup').slice(0,3).map(g=>g.label+': '+num(g.identified)).join(' | ')+' | '+num(segments('plano').length)+' planos | '+num(segments('patrocinador').length)+' patrocinadoras';
      text(profile,left,56.5,6.5,true,teal);
      const values=[['Público avaliado',num(s.identified)],['Participantes com erro',num(s.fail)],['Ocorrências de erro',num(s.errorOccurrences)],['Taxa de participantes com erro',U.coveragePercent(s.fail,s.identified)],['Com canal válido',U.coveragePercent(s.covered,s.identified)],['Sem e-mail',num(s.withoutEmail)],['Sem celular',num(ps.filter(p=>p.exclusions.sem_celular).length)],['Sem telefone fixo',num(ps.filter(p=>p.exclusions.sem_fixo).length)],['Sem canais cadastrados',num(s.withoutAny)],['Pendentes de tratamento',num(s.pending)]];
      values.forEach(([label,value],i)=>{const x=left+(i%5)*35.6,top=60+Math.floor(i/5)*25;doc.setFillColor(bg);doc.roundedRect(x,top,33.5,22,1.7,1.7,'F');wrap(label,28,6.3).slice(0,2).forEach((l,j)=>text(l,x+2.5,top+4.3+j*3,6.3,false,muted));text(value,x+2.5,top+18,15,true);});
      text(prior?'Comparativo de ocorrências de erro':'Ocorrências por código',left,119,10,true);
      text('Cobertura dos canais',129,119,10,true);
      const catalog=M.rules.filter(r=>r.severity==='Erro'),currentCounts=new Map(),oldCounts=new Map();
      for(const p of ps)for(const i of p.issues)if(i.severity==='Erro')currentCounts.set(i.rule,(currentCounts.get(i.rule)||0)+1);
      for(const p of comparison?.previousPeople||[])for(const i of p.issues)if(i.severity==='Erro')oldCounts.set(i.rule,(oldCounts.get(i.rule)||0)+1);
      if(prior){
        let points=(comparison.historySeries||[]).filter(v=>Number.isFinite(v.errorOccurrences)).slice(-6);
        if(points.length<2)points=[{photo:comparison.previousRun.photo,errorOccurrences:prior.errorOccurrences},{photo,errorOccurrences:s.errorOccurrences}];
        if(points.length===2){compactChange(left,126,106,prior.errorOccurrences,s.errorOccurrences,comparison.previousRun.photo,photo,'ocorrências');}else{
        const min=new Date(points[0].photo.slice(0,7)+'-01').getTime(),maxDate=new Date(points.at(-1).photo.slice(0,7)+'-01').getTime(),max=Math.max(1,...points.map(v=>v.errorOccurrences)),xx=v=>left+8+(new Date(v.photo.slice(0,7)+'-01').getTime()-min)/Math.max(1,maxDate-min)*91,yy=v=>163-v/max*34;
        [0,.5,1].forEach(f=>{doc.setDrawColor(line);doc.setLineWidth(.15);doc.line(left+7,yy(max*f),left+104,yy(max*f));text(num(Math.round(max*f)),left+5,yy(max*f)+1,6,false,muted,'right');});
        points.forEach((v,i)=>{if(i){const a=points[i-1],d1=new Date(a.photo.slice(0,7)+'-01'),d2=new Date(v.photo.slice(0,7)+'-01');if(d2.getUTCFullYear()*12+d2.getUTCMonth()-d1.getUTCFullYear()*12-d1.getUTCMonth()===1&&(!a.profile||!v.profile||a.profile===v.profile)){doc.setDrawColor(teal);doc.setLineWidth(.65);doc.line(xx(a),yy(a.errorOccurrences),xx(v),yy(v.errorOccurrences));}}doc.setFillColor(teal);doc.circle(xx(v),yy(v.errorOccurrences),1,'F');text(num(v.errorOccurrences),xx(v),yy(v.errorOccurrences)-3,6.3,true,teal,'center');text(v.photo.slice(5,7)+'/'+v.photo.slice(2,4),xx(v),170,6.3,false,muted,'center');});
        }
      }else{
        const max=Math.pow(10,Math.ceil(Math.log10(Math.max(10,...currentCounts.values()))));catalog.forEach((r,i)=>{const value=currentCounts.get(r.id)||0,x=left+5+i*10,h=Math.log1p(value)/Math.log1p(max)*35;doc.setFillColor(teal);if(value)doc.rect(x,163-h,5,h,'F');text(num(value),x+2.5,160-h,5.8,true,teal,'center');text(r.code,x+2.5,170,6,false,muted,'center');});doc.setDrawColor(line);doc.setLineWidth(.2);doc.line(left+3,164,left+104,164);text('Escala logarítmica: log(1 + quantidade)',left+3,176,6,false,muted);
      }
      const cx=162,cy=146,rad=14,ratio=s.identified?s.covered/s.identified:0;
      doc.setDrawColor(line);doc.setLineWidth(5.1);doc.circle(cx,cy,rad,'S');doc.setDrawColor(teal);doc.setLineCap('butt');
      if(ratio>=1)doc.circle(cx,cy,rad,'S');else if(ratio>0){const steps=Math.max(1,Math.ceil(ratio*360)),path=[];let px=cx,py=cy-rad;for(let i=1;i<=steps;i++){const a=(-90+i/steps*ratio*360)*Math.PI/180,x=cx+Math.cos(a)*rad,y=cy+Math.sin(a)*rad;path.push([x-px,y-py]);px=x;py=y;}doc.lines(path,cx,cy-rad,[1,1],'S',false);}
      doc.setLineWidth(.2);
      text(U.coveragePercent(s.covered,s.identified),cx,148,13,true,teal,'center');text('Com canal válido: '+num(s.covered),cx,169,6.6,true,teal,'center');text('Sem canal válido: '+num(s.identified-s.covered)+' ('+U.coveragePercent(s.identified-s.covered,s.identified)+')',cx,174,6.6,false,muted,'center');
      rule(182,line,.25);text('Planos com maior concentração de participantes com erro',left,190,9,true);
      const plans=segments('plano').sort((a,b)=>b.fail-a.fail).slice(0,5),maxPlan=Math.max(1,...plans.map(g=>g.fail));
      plans.forEach((g,i)=>{const yy=199+i*8;wrap(U.shortPlan(g.label),49,6.5).slice(0,2).forEach((l,j)=>text(l,left,yy+j*2.5,6.5,false,navy));doc.setFillColor('#E4EBFC');doc.rect(left+50,yy-2.5,36,2.7,'F');doc.setFillColor(teal);doc.rect(left+50,yy-2.5,36*g.fail/maxPlan,2.7,'F');text(num(g.fail),left+98,yy,7,true,teal,'right');});
      text('Principais apontamentos',127,190,9,true);text(prior?'Ant. / Atual / Variação':'Ocorrências no mês',right,196,6,false,muted,'right');
      const ranking=catalog.map((r,i)=>({id:r.id,code:r.code,label:r.label,value:currentCounts.get(r.id)||0})).sort((a,b)=>b.value-a.value).slice(0,5);
      ranking.forEach((r,i)=>{const yy=204+i*7.6;text(r.code,127,yy,6.7,true);wrap(r.label,37,6).slice(0,2).forEach((l,j)=>text(l,135,yy+j*2.5,6,false,navy));const old=oldCounts.get(r.id)||0;const v=prior?num(old)+' / '+num(r.value)+' / '+(r.value-old>0?'+':'')+num(r.value-old):num(r.value);text(v,right,yy,6.7,true,r.value-old>0?'#9F1846':teal,'right');});
      y=246;rule(y-5,line,.25);
      const em=ps.reduce((a,p)=>Math.max(a,p.counts.EM),0),ce=ps.reduce((a,p)=>Math.max(a,p.counts.CE),0);
      const change=prior?'Variação frente a '+date(comparison.previousRun.photo)+': '+(s.errorOccurrences-prior.errorOccurrences>0?'+':'')+num(s.errorOccurrences-prior.errorOccurrences)+' ocorrências de erro. ':'Não há período anterior comparável. ';
      wrap(change+'Maior quantidade de registros por participante: '+num(em)+' e-mails e '+num(ce)+' celulares. Quantidades por plano não são aditivas.',176,7.1).slice(0,3).forEach((l,i)=>text(l,left,y+i*3.6,7.1,false,muted));
      wrap('Este estudo não contempla participantes e pensionistas com morte presumida, nem a base corporativa do I-Petros.',176,7.1).slice(0,2).forEach((l,i)=>text(l,left,263+i*3.6,7.1,true,teal));
    }
    function movementTable(){
      if(!comparison?.previousPeople)return;
      const current={people:ps,result:state.result,migrationNote:state.result.migrationNote},previous={...comparison.previousRun,people:comparison.previousPeople,result:comparison.previousRun.result||{selection:state.result.selection,evaluatedRules:state.result.evaluatedRules||state.result.selection}};
      const rows=D.ruleRows(current,previous,{}).filter(r=>r.severity==='Erro'),sum=key=>rows.every(r=>r[key]!=null)?rows.reduce((s,r)=>s+r[key],0):null,number=v=>v==null?'—':num(v),before=sum('previous'),now=sum('current');
      newPage('Movimentação dos apontamentos');
      paragraph('Comparação completa das regras de erro avaliadas: '+date(comparison.previousRun.photo)+' e '+date(photo)+'. O mesmo recorte de público é aplicado aos dois períodos.',8);
      const data=rows.map(r=>[M.rules.find(rule=>rule.id===r.rule)?.code||'—',r.label,number(r.previous),num(r.current),number(r.entered),number(r.exited),U.formatVariation(r.current,r.previous)]);
      data.push(['Total','Ocorrências',number(before),number(now),number(sum('entered')),number(sum('exited')),before==null?'—':U.formatVariation(now,before)]);
      table('Comparativo por código',['Código','Erro identificado',date(comparison.previousRun.photo),date(photo),'Entradas','Saídas','Variação líquida'],data,[17,52,18,18,20,20,31],['left','left']);
      paragraph('Entradas e saídas são comparadas por matrícula, regra e chave de evidência, incluindo repetições. Saídas indicam ocorrências não observadas no recorte atual; não comprovam, isoladamente, correção cadastral. Podem refletir mudança de contato, público ou enquadramento. Percentual sobre o período anterior. — indica informação não comparável ou evidência histórica insuficiente.',7.5);
    }
    function sponsorFigure(){
      const groups=segments('patrocinador').sort((a,b)=>b.fail-a.fail),shown=groups.slice(0,8),max=Math.max(1,...shown.map(g=>g.fail));ensure(78,'Participantes por patrocinadora');
      text('Participantes com erro por patrocinadora',left,y,11,true);y+=8;const top=y,width=176/Math.max(1,shown.length);
      shown.forEach((g,i)=>{const x=left+i*width+width/2,h=g.fail/max*36;doc.setFillColor(teal);if(g.fail)doc.rect(x-4,top+39-h,8,h,'F');text(num(g.fail),x,top+36-h,7,true,teal,'center');wrap(g.label,width-2,6).slice(0,3).forEach((line,j)=>text(line,x,top+45+j*3,6,false,muted,'center'));});
      y=top+59;paragraph('Participantes distintos por patrocinadora. '+(groups.length>8?'Exibidas as oito maiores concentrações; a tabela de cobertura detalha todas as patrocinadoras. ':'')+'Vínculos distintos podem incluir a mesma pessoa em mais de uma categoria.',7);
    }
    function demographicFigure(){
      const rows=D.demographics(ps),known=rows.reduce((s,r)=>s+r.F+r.M,0),series=[...(known?[['F','Mulheres',teal],['M','Homens','#C74370']]:[]),...(rows.some(r=>r.N)?[['N','Não informado / não reconhecido','#A7B9E7']]:[]),...(rows.some(r=>r.D)?[['D','Divergente',muted]]:[])],max=Math.max(1,...rows.flatMap(r=>series.map(([key])=>r[key])));
      newPage('Perfil etário por sexo');
      const legend=series.map(([key,label])=>key+': '+label).join(' | ');paragraph(legend||'Sem participantes no recorte.',8);
      if(!known&&ps.length)paragraph('Sexo não disponível nesta fotografia. Reprocesse a base oficial com a coluna Sexo (M/F) para apresentar a separação entre mulheres e homens.',8);
      const rowHeight=series.length*3.6+(series.length>=4?3:4.4);
      for(const row of rows){ensure(rowHeight+2,'Perfil etário por sexo');text(row.label,left,y+rowHeight/2,7.5,true);series.forEach(([key,,color],i)=>{const yy=y+i*3.6;text(key,left+25,yy+3,6.5,true,muted);doc.setFillColor(bg);doc.rect(left+33,yy+0.8,118,2.2,'F');doc.setFillColor(color);if(row[key])doc.rect(left+33,yy+0.8,118*row[key]/max,2.2,'F');text(num(row[key]),right,yy+3,7,true,navy,'right');});y+=rowHeight;rule(y-1,line,.1);}
      y+=5;paragraph('Idade na fotografia do estudo. Sexo conforme coluna cadastral, sem inferência pelo nome. Idades ausentes, inválidas ou divergentes entre vínculos aparecem em Não disponível. Cada participante é contado uma vez.',7.5);
    }
    // Match the typographic Word cover. Indicators start on the executive summary.
    Brand.draw(doc,left,14,58);
    text('NÚCLEO ANALYTICS - GAP/CA',right,21,8,false,'#000000','right');rule(29);
    text('RELATÓRIO EXECUTIVO',left,84,9,true,teal);
    text('Qualidade dos meios',left,103,31,true,'#000000');
    text('de comunicação',left,117,31,true,'#000000');
    text('Presença, validade e prioridades de tratamento cadastral.',left,131,12,false,muted);
    const issued=new Date().toLocaleDateString('pt-BR',{timeZone:'America/Sao_Paulo'});
    [
      ['COMPETÊNCIA',photo.slice(5,7)+'/'+photo.slice(0,4)],
      ['FOTOGRAFIA DA BASE',date(photo)],
      ['EQUIPE RESPONSÁVEL','Núcleo Analytics - GAP/CA'],
      ['DATA DE EMISSÃO',issued],
    ].forEach(([label,value],i)=>{
      const x=left+(i%2)*92,yy=169+Math.floor(i/2)*28;
      doc.setDrawColor(line);doc.setLineWidth(.22);doc.line(x,yy,x+84,yy);
      text(label,x,yy+7,8,true,teal);text(value,x,yy+15,12);
    });
    rule(280);
    executiveSummary();
    movementTable();
    newPage('Comparativos e perfil do público');
    const names={group:'Situação Contratual',subgroup:'Sub Situação Contratual',plan:'Plano',sponsor:'Patrocinadora',ageBand:'Faixa etária',exclusion:'Cadastro dos canais'};
    paragraph(Object.entries(filters).filter(([,v])=>v).map(([k,v])=>(names[k]||k)+': '+(M.exclusions.find(d=>d[0]===v)?.[1]||v)).join(' | ')||'Público oficial completo, sem filtros.');
    paragraph('Este estudo não contempla participantes e pensionistas com morte presumida, nem a base corporativa do I-Petros.',8);
    if(comparison?.previousPeople&&comparison.comparable!==false){
      const before=R.summarize(comparison.previousPeople.filter(R.assessable)),prior=comparison.previousRun.photo;
      const series=(comparison.historySeries||[]).filter(v=>Number.isFinite(v.errorOccurrences)).slice(-12);
      if(series.length<2){series.length=0;series.push({photo:prior,errorOccurrences:before.errorOccurrences},{photo,errorOccurrences:s.errorOccurrences});}
      if(series.length===2){ensure(72,'Comparativo mensal');text('Comparativo mensal',left,y,12,true);y+=8;text('Ocorrências de erro',left,y,9,true);text('Participantes com erro',left+92,y,9,true);y+=4;compactChange(left,y,84,before.errorOccurrences,s.errorOccurrences,prior,photo,'ocorrências');compactChange(left+92,y,84,before.fail,s.fail,prior,photo,'participantes');y+=49;}else{
      ensure(87,'Evolução dos apontamentos');text('Evolução das ocorrências de erro',left,y,12,true);y+=7;
      text('Mesmo recorte de público aplicado aos períodos apresentados.',left,y,7.5,false,muted);y+=7;
      const max=Math.max(1,...series.map(v=>v.errorOccurrences)),top=y,chartH=45,start=new Date(series[0].photo.slice(0,7)+'-01').getTime(),end=new Date(series.at(-1).photo.slice(0,7)+'-01').getTime();
      const xx=v=>left+12+(new Date(v.photo.slice(0,7)+'-01').getTime()-start)/Math.max(1,end-start)*155,yy=v=>top+chartH-(v/max)*chartH;
      [0,.5,1].forEach(t=>{doc.setDrawColor(line);doc.setLineWidth(.15);doc.line(left+10,yy(max*t),right,yy(max*t));text(num(Math.round(max*t)),left+7,yy(max*t)+1,6.5,false,muted,'right');});
      series.forEach((v,i)=>{const x=xx(v),py=yy(v.errorOccurrences);if(i){const d1=new Date(series[i-1].photo.slice(0,7)+'-01'),d2=new Date(v.photo.slice(0,7)+'-01'),gap=d2.getUTCFullYear()*12+d2.getUTCMonth()-d1.getUTCFullYear()*12-d1.getUTCMonth();if(gap===1&&(!v.profile||!series[i-1].profile||v.profile===series[i-1].profile)){doc.setDrawColor(teal);doc.setLineWidth(.7);doc.line(xx(series[i-1]),yy(series[i-1].errorOccurrences),x,py);}}doc.setFillColor(teal);doc.circle(x,py,1.2,'F');if(series.length<=6||i%2===0||i===series.length-1){text(num(v.errorOccurrences),x,Math.max(top-1,py-3),7,true,teal,'center');text(v.photo.slice(5,7)+'/'+v.photo.slice(2,4),x,top+chartH+6,7,false,muted,'center');}});
      y=top+chartH+14;
      }
      const delta=s.errorOccurrences-before.errorOccurrences;
      paragraph('Comparação com '+date(prior)+': '+num(before.errorOccurrences)+' para '+num(s.errorOccurrences)+' ocorrências de erro. Variação: '+(delta>0?'+':'')+num(delta)+'. Variações podem decorrer de novos apontamentos, alterações no público ou redução de ocorrências; não representam, isoladamente, correções confirmadas.',8);
    }
    const highlight=type=>{const values=ps.map(p=>p.counts[type]),max=values.reduce((m,v)=>Math.max(m,v),0);return {max,ties:max?values.filter(v=>v===max).length:0};};
    const em=highlight('EM'),ce=highlight('CE');
    ensure(35,'Destaques do cadastro');text('Destaques do cadastro',left,y,11,true);y+=7;
    paragraph('Maior quantidade de registros de e-mail por participante: '+num(em.max)+' ('+num(em.ties)+' participante(s)). Maior quantidade de registros de celular: '+num(ce.max)+' ('+num(ce.ties)+' participante(s)). As quantidades representam registros, não contatos distintos. Esses recortes podem ser consultados na visão executiva.',8);
    table('Presença e validade dos canais',['Canal','Cadastrado','Estrutura válida'],Object.entries(M.types).map(([k,v])=>[v.label,num(ps.filter(p=>p.counts[k]>0).length),num(ps.filter(p=>p.validCounts[k]>0).length)]),[88,44,44]);
    sponsorFigure();
    for(const [dim,title] of [['contractGroup','Situação Contratual'],['contractSubgroup','Sub Situação Contratual']])table(title,['Categoria','Público','Sem e-mail','Sem canais'],segments(dim).map(g=>[dim==='plano'?U.shortPlan(g.label):g.label,num(g.identified),num(g.withoutEmail),num(g.withoutAny)]),[95,27,27,27]);
    for(const [dim,title] of [['plano','Cobertura por plano'],['patrocinador','Cobertura por patrocinadora']])table(title,['Categoria','Público','Sem e-mail','Sem canais'],segments(dim).map(g=>[dim==='plano'?U.shortPlan(g.label):g.label,num(g.identified),num(g.withoutEmail),num(g.withoutAny)]),[95,27,27,27]);
    const risks=new Map();for(const p of ps)for(const i of p.issues){if(i.rule==='death')continue;const key=JSON.stringify([i.rule,i.problem||i.message]);if(!risks.has(key))risks.set(key,{label:i.problem||i.message,people:new Set()});risks.get(key).people.add(p.id);}
    table('Principais apontamentos',['Problema identificado','Pessoas'],[...risks.values()].sort((a,b)=>b.people.size-a.people.size).map(g=>[g.label,num(g.people.size)]),[149,27]);
    ensure(38,'Notas de leitura');text('Notas de leitura',left,y,11,true);y+=7;
    paragraph('Quantidades representam pessoas distintas. Uma pessoa pode ter mais de um vínculo, canal ou apontamento; categorias não são aditivas. Sem canais cadastrados significa ausência de telefone, celular e e-mail.');
    paragraph('Validade é estrutura, não confirmação de entrega ou titularidade. Registros com data de óbito foram excluídos da avaliação. Tratado encerra a pendência operacional e preserva a evidência. O DDD não é comparado com o endereço.');
    paragraph('Regras aplicadas: '+M.rules.filter(v=>state.result.selection.includes(v.id)).map(v=>v.label).join('; ')+'.',7.5);
    demographicFigure();
    const total=doc.getNumberOfPages();for(let n=1;n<=total;n++){
      doc.setPage(n);text('Núcleo Analytics - Setor de Cadastro',W/2,H-11,8,false,muted,'center');text(n+' / '+total,W-17,H-11,8,false,muted,'right');
    }
    doc.setProperties({title:'PIC - Qualidade dos meios de comunicação',author:'Núcleo Analytics - Setor de Cadastro',subject:'Fotografia '+date(photo)});return doc.output('blob');
  }
  return {generate};
});
