(function(){
 'use strict';
 const H=ComHistory,D=ComExecutiveData,P=ComHistoryPersistence,U=CVCUtils;
 const $=s=>document.querySelector(s),esc=U.escapeHtml,n=U.formatNumber,date=U.formatDate;
 const pause=()=>new Promise(resolve=>setTimeout(resolve,0));
 let db=H.fresh(),handle=null,expected='',dirty=false,loading=false,cacheOK=false,origin='Nenhum histórico carregado',serial=Promise.resolve();
 let pendingTreatment=null,treatmentTimer=null;
 function notify(s){$('#toast').textContent=s;$('#toast').hidden=false;clearTimeout(notify.timer);notify.timer=setTimeout(()=>$('#toast').hidden=true,8000);}
 function message(s){$('#historyMessage').textContent=s;$('#historyMessage').hidden=!s;}
 function progress(p){$('#historyWorkTitle').textContent=p.phase||'Atualizando histórico';$('#historyWorkDetail').textContent=p.detail||'Aguarde a conclusão da operação.';$('#historyWorkBar').value=p.percent||0;$('#historyWorkPercent').textContent=Math.round(p.percent||0)+'%';}
 async function work(title,fn){
   loading=true;controls();progress({phase:title,percent:1});if(!$('#historyWorkDialog').open)$('#historyWorkDialog').showModal();await pause();
   try{return await fn(progress);}finally{loading=false;$('#historyWorkDialog').close();controls();}
 }
 function controls(){
   const sorted=[...db.runs].sort((a,b)=>b.photo.localeCompare(a.photo));
   $('#historyOrigin').textContent=origin;$('#historyStatus').textContent=n(db.runs.length)+' competências registradas';$('#historyDirty').textContent=dirty?'Existem alterações locais ainda não gravadas no arquivo.':'O arquivo não possui alterações locais pendentes.';
   $('#historyCache').textContent=cacheOK?'Cópia local reduzida disponível neste navegador.':'Utilize o arquivo de histórico para preservar os resultados.';$('#openHistory').textContent=dirty?'Histórico · salvar alterações':'Histórico & base';
   for(const id of ['historySave','historySaveAs','historyDownload'])$('#'+id).disabled=loading||!db.runs.length;for(const id of ['historyOpen','historyManualOpen'])$('#'+id).disabled=loading;
   $('#historyCapture').disabled=loading||!ComApp.state.result;$('#historyReconnect').hidden=!handle;
   $('#historyTable').innerHTML='<table><thead><tr><th>Fotografia</th><th>Público avaliado</th><th>Processamento</th><th></th></tr></thead><tbody>'+sorted.map(r=>'<tr><td><b>'+date(r.photo)+'</b></td><td>'+n(r.personCount)+'</td><td>'+esc(new Date(r.result.processedAt).toLocaleString('pt-BR'))+(r.migrationNote?'<small>Histórico convertido para o formato reduzido</small>':'')+'</td><td><button class="quiet" data-history-run="'+esc(r.id)+'">Retomar</button></td></tr>').join('')+'</tbody></table>';
 }
 async function persist(run=null){try{await P.saveDatabase(db,run);cacheOK=true;}catch(e){cacheOK=false;notify('Não foi possível atualizar a cópia local. Salve o arquivo de histórico. '+e.message);}controls();}
 function captureNow(state,onProgress){
   const snapshot=H.capture(state),old=db.runs.find(r=>r.id===snapshot.id);if(old&&snapshot.savedAt<=old.savedAt)snapshot.savedAt=new Date(Date.parse(old.savedAt)+1).toISOString();
   serial=serial.catch(()=>{}).then(async()=>{await H.pack(snapshot,JSZip,onProgress);H.put(db,snapshot);dirty=true;await persist(snapshot);H.evict(db,[]);}).catch(e=>{notify('Não foi possível registrar a fotografia. '+e.message);throw e;});
   return serial;
 }
 function capture(reason='manual',onProgress){
   if(!ComApp.state.result)return serial;
   if(reason==='treatment'){pendingTreatment=ComApp.state;clearTimeout(treatmentTimer);treatmentTimer=setTimeout(()=>{const state=pendingTreatment;pendingTreatment=null;captureNow(state).catch(()=>{});},400);dirty=true;controls();return serial;}
   return captureNow(ComApp.state,onProgress);
 }
 async function flush(){if(pendingTreatment){clearTimeout(treatmentTimer);const state=pendingTreatment;pendingTreatment=null;await captureNow(state);}await serial;}
 function release(){H.evict(db,[]);}
 async function accept(file,h=null,onProgress){
   await flush();const incoming=await H.decode(file,JSZip,onProgress),hasLocal=db.runs.some(r=>!incoming.runs.some(v=>v.id===r.id&&v.savedAt===r.savedAt));
   db=H.merge(incoming,db);dirty=hasLocal||!!incoming.migrated;handle=h;expected=h?await P.signature(file):'';origin=h?'Arquivo vinculado: '+file.name:'Arquivo aberto: '+file.name;
   await P.write('handle',handle).catch(()=>{});await persist();
   if(ComApp.state.result){const r=db.runs.find(r=>r.id===ComApp.state.result.runId);if(r){await H.expand(r,JSZip,onProgress);ComApp.restoreExecution(H.hydrate(r));}}
   message(incoming.migrated?'Histórico convertido para o formato reduzido, com exclusão dos registros com óbito. O arquivo anterior não foi alterado. Salve uma nova cópia para preservar a conversão.':'Histórico carregado. Os resultados estão disponíveis sem novo processamento.');controls();
 }
 async function chooseFile(){
   if(loading)return;try{if(window.showOpenFilePicker){const [h]=await window.showOpenFilePicker({multiple:false,types:[{description:'Histórico cadastral PIC',accept:{'application/zip':['.pic']}}]});const file=await h.getFile();await work('Carregando histórico',p=>accept(file,h,p));}else $('#historyInput').click();}catch(e){if(e.name!=='AbortError')message('Não foi possível abrir o arquivo. '+e.message);}
 }
 async function reconnect(){if(!handle||loading)return;try{if(!await P.permission(handle,false,true))throw Error('Autorize a leitura ou selecione o arquivo novamente.');const file=await handle.getFile();await work('Conferindo arquivo vinculado',p=>accept(file,handle,p));}catch(e){message(e.message);}}
 async function save(asNew=false){
   if(loading||!db.runs.length)return;let target=handle;
   try{
     if(asNew||!target)target=window.showSaveFilePicker?await window.showSaveFilePicker({suggestedName:'PIC_Historico.pic',types:[{description:'Histórico cadastral PIC',accept:{'application/zip':['.pic']}}]}):null;
     if(target&&!await P.permission(target,true,true))throw Error('A gravação não foi autorizada. Utilize Baixar uma cópia.');
     await work('Salvando histórico',async p=>{
       await flush();const update=Date.now(),payload={...db,revision:db.revision+1,updatedAt:new Date().toISOString()},blob=await H.encode(payload,JSZip,p);
       if(target){
         const file=await target.getFile();if(target!==handle&&file.size){const other=await H.decode(file,JSZip);if(other.id!==db.id||other.revision>db.revision)throw Error('O destino possui outro histórico ou uma versão mais recente. Abra o arquivo antes de salvar.');}
         p({percent:99,phase:'Gravando arquivo de histórico',detail:'Aguarde a confirmação da gravação.'});expected=await P.commit(target,blob,target===handle?expected:await P.signature(file));handle=target;db.revision=payload.revision;origin='Arquivo vinculado: '+target.name;dirty=db.runs.some(r=>Date.parse(r.savedAt)>update);await P.write('handle',handle).catch(()=>{});await persist();message('Arquivo salvo. Aguarde a conclusão da sincronização do OneDrive antes de encerrar o computador.');
       }else{U.downloadBlob(blob,'PIC_Historico.pic');message('Download solicitado. Mantenha o arquivo na pasta corporativa com acesso restrito.');}
       p({percent:100,phase:'Histórico concluído',detail:'Os resultados foram preservados no arquivo.'});await pause();
     });
   }catch(e){if(e.name!=='AbortError')message(e.message);}
 }
 async function download(){if(loading||!db.runs.length)return;try{await work('Preparando cópia do histórico',async p=>{await flush();U.downloadBlob(await H.encode(db,JSZip,p),'PIC_Historico.pic');message('Cópia preparada. O arquivo contém dados pessoais e deve permanecer em pasta restrita.');});}catch(e){message(e.message);}}
 function openHistory(){controls();$('#historyDialog').showModal();}
 async function historicalSeries(f,selectedRun){
   const list=H.canonical(selectedRun.classification==='demonstration'?{...db,runs:db.runs.filter(r=>r.classification==='demonstration')}:db);
   const runs=[...list.filter(r=>r.photo<selectedRun.photo&&r.photo.slice(0,7)!==selectedRun.photo.slice(0,7)),selectedRun],out=[];
   for(let i=0;i<runs.length;i++){
     const r=runs[i],unsupported=r.migrationNote&&(f.status||f.treatment||f.rule==='shared');let m=unsupported?null:H.measure(r,f);
     if(!m&&!unsupported){await H.expand(r,JSZip);m=D.metrics(D.filter(r.people,f));if(r.id!==selectedRun.id&&r.data)r.people=null;await pause();}
     out.push({id:r.id,photo:r.photo,profile:H.profile(r),...(m||{identified:null,covered:null,coverageRate:null,errorRate:null,errorOccurrences:null,fail:null}),unavailable:!m});
   }return out;
 }
 async function comparison(result,f={}){
   await flush();const stored=db.runs.find(r=>r.id===result.runId)||H.capture({...ComApp.state,result}),r={...stored,people:stored.people||result.participants},before=H.previous(db,r);
   try{
     if(!before)return {previousRun:null,previousPeople:null,historySeries:await historicalSeries(f,r)};
     await H.expand(before,JSZip);const ps=D.filter(H.people(before),f);
     return {previousRun:before,previousPeople:ps,comparable:D.compare(r,before,f).available,historySeries:await historicalSeries(f,r)};
   }finally{H.evict(db,[]);}
 }
 async function resume(id){
   if(loading||ComApp.state.busy)return;
   try{
     await work('Retomando fotografia',async p=>{
       await flush();const run=db.runs.find(r=>r.id===id);if(!run)throw Error('Fotografia não encontrada.');
       await H.expand(run,JSZip,p);
       ComApp.restoreExecution(H.hydrate(run));H.evict(db,[]);
     });
     $('#historyDialog').close();ComApp.page('dashboard');
   }catch(e){message(e.message);}
 }
 async function init(){
   $('#historyClose').onclick=()=>$('#historyDialog').close();
   $('#historyOpen').onclick=chooseFile;$('#historyManualOpen').onclick=()=>$('#historyInput').click();
   $('#historySave').onclick=()=>save();$('#historySaveAs').onclick=()=>save(true);$('#historyDownload').onclick=download;
   $('#historyReconnect').onclick=reconnect;$('#historyCapture').onclick=()=>work('Registrando fotografia',p=>capture('manual',p));
   $('#historyInput').onchange=async e=>{const file=e.target.files[0];if(!file)return;try{await work('Carregando histórico',p=>accept(file,null,p));}catch(err){message(err.message);}finally{e.target.value='';}};
   $('#openHistory').onclick=openHistory;
   $('#newPhoto').onclick=()=>ComApp.newExecution();
   $('#historyTable').addEventListener('click',e=>{const b=e.target.closest('[data-history-run]');if(b)return resume(b.dataset.historyRun);});
   window.addEventListener('beforeunload',e=>{if(dirty){e.preventDefault();e.returnValue='';}});
   try{
     const cached=await P.loadDatabase(async(r,version)=>{if(version===2){const migrated=H.migrate(r);await H.pack(migrated,JSZip);migrated.people=null;return migrated;}return r;});
     if(cached){db=H.validate({...cached,version:H.VERSION});cacheOK=true;dirty=true;origin='Cópia local · arquivo central ainda não conferido';await persist();}
     handle=await P.read('handle')||null;
     if(handle){if(await P.permission(handle)){const file=await handle.getFile();await work('Conferindo histórico vinculado',p=>accept(file,handle,p));}else origin+=' · reautorização de leitura necessária';}
   }catch(e){message('O carregamento automático não foi concluído. '+e.message);}
   controls();
 }
 globalThis.ComHistoryUI={capture,flush,release,comparison,resume,openHistory,get database(){return db;},get dirty(){return dirty;}};
 init().catch(e=>notify('A abertura do histórico não foi concluída. '+e.message));
})();
