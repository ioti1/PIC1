# Banner de abertura integrado

Imagem: assets/banner-comunicacao-integrado.png (2172 × 724 pixels).
Origem: imagem enviada pelo usuário nesta revisão. O arquivo foi copiado sem alterações nos pixels; nenhuma nova imagem foi gerada.

A composição usa a arte como fundo do banner completo, alinhada à direita e preservando sua proporção. O gradiente azul-petróleo/turquesa e a transição suave à esquerda são camadas de apresentação, não recortes de uma imagem em card.

O texto, o destaque turquesa e o botão são HTML acessível, selecionável e adaptável à largura da tela. No desktop, a altura-base é de 288 px, 10% menor que os 320 px da versão anterior. Em telas estreitas, a altura acompanha o conteúdo para evitar perda de texto ou ações.

A arte anteriormente gerada permanece disponível na pasta da versão 3.1.0, preservada como referência. Os dados, as regras e o Power BI não foram modificados nesta revisão.
