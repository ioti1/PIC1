# Base de manutenção da Central de Validação

## Fonte vigente

Usar esta pasta `Entregas/PIC_Entrega_v3/HUB/apps/Central_Validacao/` como base das próximas manutenções. Ela contém os ajustes de identidade visual e de lotes recebidos do usuário, além da revisão de exportação de 23/10/2026.

Não retomar a antiga aplicação da pasta New project como ponto de partida: ela não contém todas as alterações recebidas posteriormente.

## Referência preservada

O arquivo Central_Validacao.rar recebido em 23/10/2026 foi preservado sem alterações. SHA-256: `E11E8BDE991F7C2B8E761C89568C6B74673AA9FA83F86E0AD21F72BE42C326D8`.

Antes da manutenção, os 53 arquivos da pasta vigente foram comparados com o anexo e eram idênticos. Uma extração original de conferência fica em `tmp/central-validacao-manutencao-20261023/original/`, fora do pacote de entrega. O RAR original é um retrato anterior à revisão do Excel, não a versão atualizada.

## Revisão de 23/10/2026

Escopo: Excel dos lotes completos de erros e alertas da etapa 5. Foram alterados apenas o exportador de lotes, a apresentação dessas abas no gerador XLSX, testes e esta documentação.

Regras e dados mensais para o Power BI mantêm o contrato anterior. O posicionamento dos dados em Base_Cadastral, Execucao e no Excel do recorte não mudou. O topo com identificação e o cabeçalho na linha 5 aplicam-se exclusivamente aos lotes por código.

Para conferir novamente, execute os testes da pasta tests. Eles usam dados sintéticos, incluindo 50.001 evidências, sem carregar bases pessoais. O teste de layout verifica os dois tipos de lote, alturas, identificação, datas, perfil, óbito, filtros, congelamento, literalidade, preservação de dados e limites físicos do Excel.
