"""Independent read-only reconciliation. Prints aggregates, never participant/contact values."""
import sys, re, json, collections
from openpyxl import load_workbook
def key(value):
    if value is None or str(value).strip().upper() in ('', '-', 'N/A', 'NULL', 'NONE'): return ''
    text = re.sub(r'\s', '', str(value))
    if re.fullmatch(r'\d+(?:\.0+)?', text): return str(int(float(text)))
    return text.upper()
public = load_workbook(sys.argv[1], read_only=True, data_only=True)
official = collections.Counter()
for row in public.active.iter_rows(min_row=2, values_only=True):
    if any(v is not None and str(v).strip() for v in row): official[key(row[16])] += 1
public.close()
contact = load_workbook(sys.argv[2], read_only=True, data_only=True)
counts = collections.Counter(); by_person = collections.Counter(); types=collections.Counter(); channels=collections.defaultdict(set)
for row in contact.active.iter_rows(min_row=2, values_only=True):
    if not any(v is not None and str(v).strip() for v in row): counts['blank']+=1; continue
    mp=key(row[0]); kind=str(row[3] or '').upper().strip(); counts['contacts']+=1; types[kind]+=1
    counts['withUser']+=bool(row[8] is not None and str(row[8]).strip())
    counts['withDate']+=row[7] is not None
    if not mp: counts['missingKey']+=1
    elif mp not in official: counts['orphans']+=1
    else:
        counts['matched']+=1; by_person[mp]+=1
        value=row[6] if kind=='EM' else row[5]
        if value is not None and str(value).strip(): channels[mp].add(kind)
contact.close()
eligible={mp for mp in official if mp}
counts.update(identified=len(eligible),bindings=sum(official.values()),noRegistry=sum(mp not in by_person for mp in eligible),noEmail=sum('EM' not in channels[mp] for mp in eligible),noAny=sum(not channels[mp] for mp in eligible),maxContacts=max(by_person.values(),default=0))
print(json.dumps({'independent':dict(counts),'types':dict(types)},indent=2))
