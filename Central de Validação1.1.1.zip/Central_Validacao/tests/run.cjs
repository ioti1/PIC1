const {spawnSync}=require('node:child_process'),path=require('node:path');
const tests=['static-v2.cjs','reader-v2.cjs','core-validators.cjs','v3-data.cjs','pbi-v3.cjs','v3-acceptance.cjs','v31-presentation.cjs','batch-export.cjs','batch-layout.cjs'];
for(const name of tests){const r=spawnSync(process.execPath,[path.join(__dirname,name)],{encoding:'utf8'});if(r.status!==0){console.error(name+' falhou\n'+r.stdout+'\n'+r.stderr);process.exit(r.status||1);}console.log(name+': aprovado');}
console.log('Verificações originais, lotes e novo layout Excel aprovados. Não substituem homologação no navegador ou Power BI Desktop.');
