const assert=require('node:assert/strict');global.crypto=require('node:crypto').webcrypto;global.JSZip=require('../vendor/jszip.min.js');
const M=require('../src/model.js'),R=require('../src/reconcile.js'),B=require('../src/batch-export.js');
const source=(role,rows,id)=>M.prepareSource({id,role,filename:id+'.xlsx',snapshotDate:'2026-09-30',book:{Dados:[M.fields[role].map(f=>f.label),...rows]}},'Dados',1);
const person=mp=>['id'+mp,'Pessoa fictícia '+mp,'A','15/06/1980','','','Rua','1','','Bairro','Rio','20000000','RJ','BRA','','P2',mp,'Ativo','BD',''];
(async()=>{const os=source('official',[person('0001'),person('0002'),person('0003')],'of'),cs=source('contacts',[
['1','Fictícia',1,'TL','00','23456789','','01/09/2026','operador'],
['1','Fictícia',2,'TL','00','23456788','','01/09/2026','operador'],
['2','Fictícia',1,'EM','','',' pessoa@GMAIL.COM ','01/09/2026',''],
],'co');
const official=await R.prepareOfficial([os]);const current=await R.processContacts(official,[cs],{selection:['registry_date']});const state={official,result:current,sources:[os,cs],marks:{},selection:['registry_date'],filters:{search:'ninguém',plan:'INEXISTENTE'}};
const before=current.runId,errors=await B.generate(state,'Erro'),alerts=await B.generate(state,'Alerta');assert.equal(state.result.runId,before);assert.deepEqual(state.selection,['registry_date']);
const e1=errors.data.rules.find(x=>x.id==='ddd');assert.equal(e1.code,'E1');assert.equal(e1.rows.length,2);assert.equal(e1.counts.get('2026-09-30'),2);assert.equal(e1.rows[0][0],'0001');assert.match(e1.rows[0][2],/"00"/);
assert.equal(errors.data.rules.find(x=>x.id==='no_registry').rows.length,1);assert.ok(alerts.data.rules.find(x=>x.id==='registry_user').rows.length);assert.match(alerts.data.rules.find(x=>x.id==='email_format').rows[0][2],/ pessoa@GMAIL.COM /);
for(const out of [errors,alerts]){const z=await JSZip.loadAsync(await out.blob.arrayBuffer(),{checkCRC32:true}),names=Object.keys(z.files);assert.equal(names.length,2);assert.equal(names.filter(x=>x.endsWith('.html')).length,1);assert.equal(names.filter(x=>x.endsWith('.xlsx')).length,1);const html=await z.file(names.find(x=>x.endsWith('.html'))).async('string');assert.match(html,/Quantidade de ocorrências/);assert.equal((html.match(/<th/g)||[]).length,4);assert.equal((html.match(/<tr><td>/g)||[]).length,out.data.rules.length);
 const wb=await JSZip.loadAsync(await z.file(names.find(x=>x.endsWith('.xlsx'))).async('uint8array'),{checkCRC32:true}),xml=await wb.file('xl/workbook.xml').async('string');assert.equal((xml.match(/<sheet /g)||[]).length,out.data.rules.length);
 for(const [i,r]of out.data.rules.entries()){assert.ok(xml.includes('name="'+r.code+'"'));const sheet=await wb.file('xl/worksheets/sheet'+(i+1)+'.xml').async('string');assert.equal((sheet.match(/<row /g)||[]).length,r.rows.length+5);assert.doesNotMatch(sheet,/<f[ >]/);assert.match(sheet,/width="110"/);assert.match(sheet,/<autoFilter ref="A5:/);assert.match(sheet,/ySplit="5" topLeftCell="C6"/);assert.match(sheet,/Data do estudo/);assert.match(sheet,/Gerado em \(Brasília\)/);assert.ok([...sheet.matchAll(/<row [^>]*\sht="([^"]+)"/g)].every(m=>m[1]==='24'));if(r.rows.length)assert.match(sheet,/<row r="6" ht="24"/);}
}
const complete=await R.processContacts(official,[cs]);R.mark(complete,'participant',complete.participants[0].id,true,{});const a=B.build(complete,'Erro');assert.equal(a.rules.find(x=>x.id==='ddd').rows.length,2);
assert.throws(()=>B.catalog('Outro'),/inválido/);console.log('PASS: 2 ZIPs / 2 arquivos cada; códigos estáveis; todas as regras; sem filtros; sem tratamento; contagens = linhas; abas com zero; matrícula original; valores originais; Excel sem fórmulas; estado preservado.');
})().catch(e=>{console.error(e);process.exit(1)});
