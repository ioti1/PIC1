// Focused regression checks for the evidence workbook. Fixtures contain no real participants.
const assert=require('node:assert/strict');global.crypto=require('node:crypto').webcrypto;global.JSZip=require('../vendor/jszip.min.js');
const M=require('../src/model.js'),R=require('../src/reconcile.js'),B=require('../src/batch-export.js'),W=require('../src/xlsx-writer.js'),X=require('../src/xlsx.js');
const source=(role,rows,id)=>M.prepareSource({id,role,filename:id+'.xlsx',snapshotDate:'2026-08-31',book:{Dados:[M.fields[role].map(f=>f.label),...rows]}},'Dados',1);
const person=(mp,plan='Plano A',sponsor='Patrocinadora A',situation='Assistido',benefit='PENSÃO',death='15/08/2026')=>['id'+mp,'Pessoa ilustrativa '+mp,sponsor,'15/06/1980','','','Rua','1','','Bairro','Rio','20000000','RJ','BRA',death,plan,mp,situation,'BD',benefit];
function cell(xml,ref){const m=xml.match(new RegExp('<c r="'+ref+'"[^>]*>([\\s\\S]*?)</c>'));return m?.[1]||'';}
function numeric(xml,ref){return Number(cell(xml,ref).match(/<v>([^<]+)<\/v>/)?.[1]);}
(async()=>{
 const rows=[person('0001'),person('0001','Plano B','Patrocinadora B'),person('0002','Plano C','Patrocinadora C','Ativo','',''),person('0003','Plano A','Patrocinadora A','Assistido','APOSENTADORIA','31/02/2026')];
 const os=source('official',rows,'of'),cs=source('contacts',[
  ['1','Exemplo',1,'TL','20','23456789','','01/08/2026',''],
  ['2','Exemplo',1,'TL','20','23456788','','01/08/2026','operador'],
  ['3','Exemplo',1,'EM','','','sem-arroba','01/08/2026','operador']
 ],'co');
 const official=await R.prepareOfficial([os]),result=await R.processContacts(official,[cs]),state={official,result,sources:[os,cs]},id=result.runId;
 const instant=new Date('2026-10-23T02:30:00Z'),out=await B.generate(state,'Erro',{generatedAt:instant});
 const bundle=await JSZip.loadAsync(await out.blob.arrayBuffer(),{checkCRC32:true}),entry=Object.keys(bundle.files).find(n=>n.endsWith('.xlsx')),bytes=await bundle.file(entry).async('uint8array'),book=await X.read({name:'evidencias.xlsx',arrayBuffer:async()=>bytes}),zip=await JSZip.loadAsync(bytes,{checkCRC32:true});
 assert.equal(result.runId,id);assert.equal(out.data.rules.find(r=>r.id==='ddd').rows.length,2);
 const expected=['Matrícula Petros','Nome','Plano','Patrocinadora','Situação Contratual','Subsituação Contratual','Data de Óbito','Dado para análise','Fotografia'];
 let total=0;
 for(const [index,rule] of out.data.rules.entries()){
  const values=book[rule.code],sheet=await zip.file('xl/worksheets/sheet'+(index+1)+'.xml').async('string');
  assert.deepEqual(values[4],expected);assert.equal(values.length,rule.rows.length+5);assert.match(values[0][0],new RegExp('^Erro '+rule.code+' - '));assert.equal(values[1][0],'Data do estudo');assert.equal(values[2][0],'Gerado em (Brasília)');
  const heights=[...sheet.matchAll(/<row [^>]*\sht="([^\"]+)"/g)].map(m=>Number(m[1]));assert.equal(heights.length,rule.rows.length+5);assert.ok(heights.every(h=>h===24));
  assert.match(sheet,/<autoFilter ref="A5:I\d+"/);assert.match(sheet,/xSplit="2" ySplit="5" topLeftCell="C6"/);assert.doesNotMatch(sheet,/<mergeCell|<f[ >]/);
  assert.equal(numeric(sheet,'B2'),(+new Date('2026-08-31T00:00:00Z'))/86400000+25569);
  assert.equal(numeric(sheet,'B3'),(+new Date('2026-10-22T23:30:00Z'))/86400000+25569);
  total+=rule.rows.length;
 }
 const e=book.E1;assert.equal(e[5][0],'0001');assert.equal(e[5][2],'Plano A | Plano B');assert.equal(e[5][3],'Patrocinadora A | Patrocinadora B');assert.equal(e[5][4],'Assistidos');assert.equal(e[5][5],'Pensionista');assert.equal(e[6][6],'');assert.match(e[5][7],/"20"/);
 const e1=await zip.file('xl/worksheets/sheet1.xml').async('string');assert.match(cell(e1,'A6'),/>0001</);assert.match(e1,/<c r="G6" s="18">/);assert.match(e1,/<c r="H6" s="16" t="inlineStr">/);
 const invalid=book.E6.find(row=>row[0]==='0003');assert.equal(invalid[6],'31/02/2026');assert.equal(invalid[5],'Aposentado');
 const styles=await zip.file('xl/styles.xml').async('string'),xfs=styles.match(/<cellXfs[^>]*>([\s\S]*?)<\/cellXfs>/)[1].split(/(?=<xf\b)/).filter(s=>s.startsWith('<xf'));
 for(const style of [16,17,18,19,20,21])assert.match(xfs[style],/wrapText="0"/);
 console.log('PASS: todas as abas, inclusive vazias; perfil após Nome; óbito válido/ausente/inválido; datas do estudo e geração separadas; Brasília na virada do dia; linhas 24 pt; filtros e congelamento; dados originais e contagens preservados ('+total+' ocorrências).');
 const header=expected,data=['00001','=Nome literal','Plano A','Patrocinadora A','Ativos','Ativo','','=HYPERLINK("https://invalid.example","teste")','2026-08-31'];
 const split=await W.workbook({E1:[header,data,data]},null,{variant:'batch',maxRows:1,sheetMeta:{E1:{title:'Erro E1 - Teste',studyDate:new Date('2026-08-31T00:00:00Z'),generatedAt:new Date('2026-10-23T12:00:00Z')}}}),parts=await JSZip.loadAsync(await split.arrayBuffer(),{checkCRC32:true});
 for(const n of [1,2]){const xml=await parts.file('xl/worksheets/sheet'+n+'.xml').async('string');assert.match(xml,/Erro E1 - Teste/);assert.equal((xml.match(/<row /g)||[]).length,6);assert.doesNotMatch(xml,/<f[ >]/);assert.match(xml,/<autoFilter ref="A5:I6"/);}
 console.log('PASS: cabeçalho repetido nas partes, limite físico protegido e texto com aparência de fórmula mantido literal.');
 const volume=50001,iterable={*[Symbol.iterator](){yield header;for(let i=0;i<volume;i++)yield [String(i).padStart(7,'0'),'Pessoa ilustrativa '+i,'Plano A','Patrocinadora A','Ativos','Ativo','','Dado de exemplo '+i,new Date('2026-08-31T00:00:00Z')];}};
 const big=await W.workbook({E1:iterable},null,{variant:'batch',maxRows:1048571,sheetMeta:{E1:{title:'Erro E1 - Volume sintético',studyDate:new Date('2026-08-31T00:00:00Z'),generatedAt:new Date('2026-10-23T12:00:00Z')}}}),bz=await JSZip.loadAsync(await big.arrayBuffer(),{checkCRC32:true}),xml=await bz.file('xl/worksheets/sheet1.xml').async('string');
 assert.equal((xml.match(/<row /g)||[]).length,volume+5);assert.match(xml,/ref="A5:I50006"/);assert.match(xml,/>0050000</);assert.ok([...xml.matchAll(/<row [^>]*\sht="([^\"]+)"/g)].every(m=>m[1]==='24'));assert.equal((await bz.file('xl/workbook.xml').async('string')).match(/<sheet /g).length,1);
 console.log('PASS: 50.001 linhas de evidência em uma aba, sem cortes e com alturas uniformes até a última linha.');
})().catch(e=>{console.error(e);process.exitCode=1;});
