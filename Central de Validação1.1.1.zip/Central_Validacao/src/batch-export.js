(function(root,factory){const node=typeof module==='object'&&module.exports;const api=factory(root,node?require('./model.js'):root.ComModel,node?require('./reconcile.js'):root.ComReconcile,node?require('./consolidated.js'):root.ComConsolidated,node?require('./xlsx-writer.js'):root.ComExport);if(node)module.exports=api;else root.ComBatchExport=api;})(globalThis,function(root,M,R,C,W){
  'use strict';
  const labels={no_registry:'Sem registro na base de contatos',unknown_type:'Tipo de contato não reconhecido',empty_value:'Contato sem valor',registry_user:'Usuário de cadastro ausente',registry_date:'Data de cadastro ausente, inválida ou posterior à fotografia'};
  const escape=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const uniqueLine=values=>[...new Set(values.filter(v=>v!==''&&v!=null).map(String))].join(' | ');
  function excelDate(value){if(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(value))return value;const d=new Date(value+'T00:00:00Z');return Number.isFinite(+d)&&d.toISOString().slice(0,10)===value?d:value;}
  function profile(p){const vs=p.vinculos,ds=C.deaths(p);return [uniqueLine(vs.map(v=>v.plano)),uniqueLine(vs.map(v=>v.patrocinador)),uniqueLine(vs.map(v=>v.contractGroup)),uniqueLine(vs.map(v=>v.contractSubgroup)),ds.length===1?excelDate(ds[0]):uniqueLine(ds.map(C.formatDate))];}
  // Excel timestamps have no timezone. Store the Brasilia wall-clock explicitly.
  function generationDate(instant){if(!(instant instanceof Date)||!Number.isFinite(+instant))throw new Error('Data de geração inválida.');const parts=Object.fromEntries(new Intl.DateTimeFormat('en-GB',{timeZone:'America/Sao_Paulo',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).formatToParts(instant).filter(p=>p.type!=='literal').map(p=>[p.type,Number(p.value)]));return new Date(Date.UTC(parts.year,parts.month-1,parts.day,parts.hour,parts.minute,parts.second));}
  const headers=['Matrícula Petros','Nome','Plano','Patrocinadora','Situação Contratual','Subsituação Contratual','Data de Óbito','Dado para análise','Fotografia'];
  function catalog(severity){if(!['Erro','Alerta'].includes(severity))throw new Error('Tipo de lote inválido.');return M.rules.filter(r=>r.severity===severity).map((r,i)=>({...r,code:(severity==='Erro'?'E':'A')+(i+1),description:labels[r.id]||r.problem||r.label}));}
  function build(result,severity){
    const contacts=new Map(result.contacts.map(c=>[c.id,c]));const rules=catalog(severity),byRule=new Map(rules.map(r=>[r.id,{...r,rows:[],counts:new Map()}]));
    for(const p of result.participants){
      const context=profile(p);
      for(const {f,evidence} of C.problems(p)){
        if(f.severity!==severity||!byRule.has(f.rule))continue;
        const item=byRule.get(f.rule),contact=contacts.get(f.contactId),raw=contact?.rawValues;let value=String(evidence||f.raw||'Não informado');if(raw){const literal=v=>JSON.stringify(v??'');value=f.rule==='registry_user'?'Usuário de cadastro (origem): '+literal(raw.usuario_registro):f.rule==='registry_date'?'Data de cadastro (origem): '+literal(raw.data_registro):contact.typeCode==='EM'?'E-mail (origem): '+literal(raw.email):'Tipo (origem): '+literal(raw.tipo)+'; DDD (origem): '+literal(raw.ddd)+'; Número (origem): '+literal(raw.numero)+(contact.typeCode?'':'; E-mail (origem): '+literal(raw.email));}
        if(value.length>32767)throw new Error('Um dado para análise excede o limite do Excel. Nenhuma informação foi cortada.');
        item.rows.push([String(p.vinculos.find(v=>String(v.values.matricula??'').trim())?.values.matricula??p.matricula??''),String(p.nome??''),value,p.snapshotDate,...context]);item.counts.set(p.snapshotDate,(item.counts.get(p.snapshotDate)||0)+1);
      }
    }
    return {severity,rules:[...byRule.values()],photos:[...result.photos].sort()};
  }
  function html(data,logoSvg=''){
    const title=data.severity==='Erro'?'Erros identificados':'Alertas para análise',logo=logoSvg?`<img class="brand" alt="Programa de Inteligência Cadastral" src="${logoSvg.startsWith('data:image/')?logoSvg:'data:image/svg+xml;base64,'+(typeof Buffer!=='undefined'?Buffer.from(logoSvg).toString('base64'):btoa(unescape(encodeURIComponent(logoSvg))))}">`:'';
    const tables=data.photos.map(photo=>`<section><h2>Fotografia ${escape(photo.split('-').reverse().join('/'))}</h2><table><thead><tr><th>Código</th><th>O que foi validado</th><th class="number">Quantidade</th></tr></thead><tbody>${data.rules.map(r=>`<tr><td><strong>${r.code}</strong></td><td>${escape(r.description)}</td><td class="number">${r.counts.get(photo)||0}</td></tr>`).join('')}</tbody></table></section>`).join('');
    return `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>PIC · ${title}</title><style>body{margin:0;background:#F0EDE4;color:#101617;font:15px/1.55 'Segoe UI',Arial,sans-serif}main{max-width:1050px;margin:36px auto;padding:42px;background:white}h1,h2{color:#004741;line-height:1.2}h1{font-size:34px;margin:30px 0 16px}h2{font-size:20px;margin-top:38px}.brand{width:350px;max-width:100%;height:auto}.lead{color:#616B68;max-width:820px}table{width:100%;border-collapse:collapse;margin:20px 0 36px}th{background:#004741;color:white;text-align:left;padding:13px}td{padding:12px 13px;border-bottom:1px solid #DCD6C7}tbody tr:nth-child(even){background:#F6F4EC}.number{text-align:right;white-space:nowrap}footer{font-size:12px;color:#616B68;border-top:1px solid #DCD6C7;padding-top:18px}@media(max-width:700px){main{margin:0;padding:22px}h1{font-size:28px}th,td{padding:10px 8px}}@media print{body{background:white}main{margin:0;padding:0}thead{display:table-header-group}tr{break-inside:avoid}}</style></head><body><main>${logo}<h1>${title}</h1><p class="lead">Base integral do cruzamento entre público oficial e contatos. Todas as regras foram verificadas. Este lote ignora os filtros das telas e as marcações de tratamento.</p><p class="lead">Quantidade de ocorrências: cada ocorrência corresponde a uma linha na aba de mesmo código do Excel. A mesma pessoa pode aparecer mais de uma vez. Regras sem ocorrência permanecem com zero e com aba vazia.</p>${tables}<footer>Programa de Inteligência Cadastral · Qualidade de Comunicação<br>Dados originais para análise. A validação estrutural não confirma entrega ou titularidade do contato.</footer></main></body></html>`;
  }
  async function generate(state,severity,{onProgress,logoSvg='',generatedAt=new Date()}={}){
    if(!state.official||!state.result)throw new Error('Conclua o cruzamento das duas bases antes de gerar o lote.');
    const result=await R.processContacts(state.official,state.sources.filter(s=>s.role==='contacts'),{selection:M.rules.map(r=>r.id),referenceDate:state.result.referenceDate,onProgress});
    const data=build(result,severity),tables={},sheetMeta={},created=generationDate(generatedAt),study=data.photos.length===1?excelDate(data.photos[0]):data.photos.map(C.formatDate).join(' | ');
    for(const r of data.rules){tables[r.code]=[headers,...r.rows.map(row=>[row[0],row[1],...row.slice(4),row[2],excelDate(row[3])])];sheetMeta[r.code]={title:(severity==='Erro'?'Erro':'Alerta')+' '+r.code+' - '+r.description,studyDate:study,generatedAt:created};}
    const workbook=await W.workbook(tables,onProgress,{maxRows:1048571,variant:'batch',sheetMeta}),month=data.photos.length===1?data.photos[0].slice(0,7):data.photos[0].slice(0,7)+'_a_'+data.photos.at(-1).slice(0,7),base='PIC_'+(severity==='Erro'?'Erros':'Alertas')+'_'+month;
    const zip=new root.JSZip();zip.file(base+'.html',html(data,logoSvg));zip.file(base+'.xlsx',await workbook.arrayBuffer());
    const blob=await zip.generateAsync({type:'blob',compression:'DEFLATE',compressionOptions:{level:6}},p=>onProgress?.({phase:'Preparando ZIP do lote completo',percent:p.percent}));
    return {blob,filename:base+'.zip',data};
  }
  return {catalog,build,html,generate};
});
