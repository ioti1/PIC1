(function(root,factory){const node=typeof module==='object'&&module.exports;const api=factory(node?require('./audit.js'):root.ComAudit,node?require('./model.js'):root.ComModel,node?require('./reconcile.js'):root.ComReconcile,node?require('./xlsx-writer.js'):root.ComExport);if(node)module.exports=api;else root.ComConsolidated=api;})(globalThis,function(A,M,R,W){
  'use strict';
  const unique=items=>[...new Set(items.filter(v=>v!==''&&v!=null).map(String))];
  const checked=v=>{const s=String(v??'');if(s.length>32767)throw new Error('Um campo consolidado excede 32.767 caracteres (limite do Excel). Refine o recorte ou revise os contatos dessa matrícula. Nenhum dado foi truncado.');return s;};
  const join=items=>checked(unique(items).join('\n'));
  const date=v=>A.isMissingDate(v)?'':A.date(v)||A.str(v);
  function deaths(p){return unique(p.vinculos.filter(v=>!A.isMissingDate(v.values.obito)).map(v=>A.date(v.values.obito)?.toISOString().slice(0,10)||A.str(v.values.obito)));}
  function bindings(p,f={}){return p.vinculos.filter(v=>(!f.plan||v.plano===f.plan)&&(!f.sponsor||v.patrocinador===f.sponsor)&&(!f.group||v.contractGroup===f.group)&&(!f.subgroup||v.contractSubgroup===f.subgroup));}
  function problems(p,{rule='',problem='',contacts=null,includeContext=true}={}){
    const allowed=f=>f.rule!=='death'&&(!rule||f.rule===rule)&&(!problem||(f.problem||f.message)===problem);
    const cs=contacts||p.channels,items=[];
    if(includeContext)for(const f of p.contextIssues.filter(allowed))items.push({f,evidence:f.field==='Óbito'?'Data de óbito: '+deaths(p).map(v=>A.date(v)?formatDate(v):v).join('; '):f.field==='Nascimento'||f.field==='Idade'?join(p.vinculos.map(v=>`Nascimento: ${formatDate(v.values.nascimento)}; idade informada: ${A.str(v.values.idade)||'não informada'}`)):['no_registry','no_contact'].includes(f.rule)?p.channels.length?join(p.channels.map(c=>`${c.label}: ${R.evidence(c)}`)):'Telefone, celular e e-mail: nenhum contato cadastrado':f.raw||f.field});
    for(const c of cs)for(const f of c.issues.filter(allowed))items.push({f,evidence:`${c.label}: ${R.evidence(c)}${['TL','CE'].includes(c.typeCode)?'; DDD de origem: '+(A.str(c.rawValues.ddd)||'ausente')+'; número de origem: '+(A.str(c.rawValues.numero)||'ausente'):''}${f.rule==='unknown_type'?'; tipo de origem: '+A.str(c.rawValues.tipo):''}${f.rule==='registry_user'?'; usuário: '+c.registrationUser:''}${f.rule==='registry_date'?'; data de cadastro: '+M.formatTimestamp(c.registrationDate||c.rawValues.data_registro):''}`});
    return items;
  }
  function formatDate(v){const d=A.date(v);return d?`${String(d.getUTCDate()).padStart(2,'0')}/${String(d.getUTCMonth()+1).padStart(2,'0')}/${d.getUTCFullYear()}`:A.str(v)||'Não informado';}
  function* treatmentRows(ps,f={},contactScope=null){
    yield ['Matrícula Petros','Nome','Data de Nascimento','Plano','Patrocinadora','Situação Contratual','Sub Situação Contratual','Problema Identificado','Campos relacionados ao problema identificado','Data de Óbito'];
    const byPerson=contactScope?new Map():null;
    if(contactScope)for(const c of contactScope){if(!byPerson.has(c.participantId))byPerson.set(c.participantId,[]);byPerson.get(c.participantId).push(c);}
    for(const p of ps){if(!p.eligible)continue;const vs=bindings(p,f),items=problems(p,{...f,contacts:byPerson?.get(p.id)}),births=unique(vs.map(v=>v.birth?.toISOString().slice(0,10)||A.str(v.values.nascimento))),ds=deaths(p);yield [p.matricula,p.nome,births.length===1?date(births[0]):join(births.map(formatDate)),join(vs.map(v=>v.plano)),join(vs.map(v=>v.patrocinador)),join(vs.map(v=>v.contractGroup)),join(vs.map(v=>v.contractSubgroup)),join(items.map(({f})=>f.message))||'Sem apontamentos nas regras selecionadas',join(items.map(i=>i.evidence)),ds.length===1?date(ds[0]):join(ds.map(formatDate))];}
  }
  const headers=['Data_Fotografia','Mes_Referencia','Id_Execucao','Perfil_Regras','Chave_Pessoa','Matricula_Petros','Nome','Data_Nascimento','Idade','Faixa_Etaria','Plano','Patrocinadora','Situacao_Contratual','Sub_Situacao_Contratual','Situacao_Original','Tipo_Beneficio','Obito_Informado','Data_Obito','Resultado','Tratamento','Sem_Email','Sem_Celular','Sem_Telefone','Sem_Canais_Cadastrados','Com_Canal_Valido','Sem_Digital_Valido','Com_Inconsistencia','Com_Ressalva','Pendente','Qtd_Telefones','Qtd_Celulares','Qtd_Emails','Qtd_Canais_Validos','Telefones','Celulares','Emails','Regra','Problema_Identificado','Severidade','Campos_Relacionados','Usuarios_Cadastro','Primeiro_Cadastro','Ultimo_Cadastro'];
  function* factRows(state){
    yield headers;const r=state.result,profile=M.version+'|'+[...r.selection].sort().join(';');
    for(const p of r.participants){if(!p.eligible)continue;const items=problems(p),groups=new Map();
      for(const item of items){const f=item.f,key=JSON.stringify([f.rule,f.problem||f.message,f.severity]);if(!groups.has(key))groups.set(key,{f,evidence:[]});groups.get(key).evidence.push(item.evidence);}
      if(!groups.size)groups.set('none',{f:{ruleLabel:'Nenhuma',message:'Sem apontamentos',severity:'Nenhuma'},evidence:[]});
      const dates=p.channels.map(c=>c.registrationDate).filter(Boolean).sort((a,b)=>a-b),deceased=deaths(p),channels=type=>join(p.channels.filter(c=>c.typeCode===type&&c.valuePresent).map(R.evidence));
      const common=[new Date(p.snapshotDate+'T00:00:00Z'),new Date(p.snapshotDate.slice(0,7)+'-01T00:00:00Z'),r.runId,profile,p.matricula,p.matricula,p.nome];
      const tail=[deceased.length?1:0,deceased.length===1?date(deceased[0]):join(deceased.map(formatDate)),p.status,p.treatmentStatus,p.exclusions.sem_email?1:0,p.exclusions.sem_celular?1:0,p.exclusions.sem_fixo?1:0,p.exclusions.sem_todos?1:0,p.validChannels?1:0,p.exclusions.sem_digital_valido?1:0,p.errors?1:0,p.warnings?1:0,p.pendingIssues?1:0,p.counts.TL,p.counts.CE,p.counts.EM,p.validChannels,channels('TL'),channels('CE'),channels('EM')];
      // One official binding x specific problem. Distinct-count measures prevent double counting.
      const seen=new Set();for(const v of p.vinculos){const signature=JSON.stringify([v.plano,v.patrocinador,v.contractGroup,v.contractSubgroup,v.situacao,v.beneficio,v.birth?.toISOString(),v.age]);if(seen.has(signature))continue;seen.add(signature);
        for(const {f,evidence} of groups.values())yield [...common,v.birth||date(v.values.nascimento),v.age??'',p.ageBand,v.plano,v.patrocinador,v.contractGroup,v.contractSubgroup,v.situacao,v.beneficio,...tail,f.ruleLabel||M.rules.find(d=>d.id===f.rule)?.label||f.rule||'Nenhuma',f.problem||f.message,f.severity,join(evidence),join(p.channels.map(c=>c.registrationUser)),dates[0]||'',dates.at(-1)||''];
      }
    }
  }
  function tables(state){const r=state.result;if(!r||r.photos.length!==1)throw new Error('Processe uma única fotografia por vez para gerar a base mensal.');const photo=r.photos[0];return {Base_Cadastral:factRows(state),Execucao:[['Contrato_PBI','Data_Fotografia','Competencia','Id_Execucao','Perfil_Regras','Publico_Completo','Participantes'],[3,new Date(photo+'T00:00:00Z'),photo.slice(0,7),r.runId,M.version+'|'+[...r.selection].sort().join(';'),1,r.participants.filter(p=>p.eligible).length]]};}
  async function monthly(state,onProgress){const data=tables(state),photo=state.result.photos[0];return {blob:await W.workbook(data,onProgress,{maxRows:1048575}),filename:`PETROS_PBI_MENSAL_${photo.slice(0,7)}.xlsx`};}
  async function treatment(ps,f,cs,onProgress){return W.workbook({Tratamento:treatmentRows(ps,f,cs)},onProgress,{maxRows:1048575,variant:'treatment'});}
  return {headers,formatDate,deaths,bindings,problems,treatmentRows,factRows,tables,monthly,treatment};
});
