(function(root,factory){const node=typeof module==='object'&&module.exports;const api=factory(root,node?require('./reconcile.js'):root.ComReconcile,node?require('./model.js'):root.ComModel);if(node)module.exports=api;else root.ComReportPDF=api;})(globalThis,function(root,R,M){
  'use strict';
  async function generate(state,ps,filters={}){
    const {jsPDF}=root.jspdf,doc=new jsPDF({unit:'mm',format:'a4',compress:true});
    const W=210,H=297,left=17,right=193,bottom=274,navy='#004741',teal='#004741',gold='#F0EDE4',muted='#616B68',line='#DCD6C7',bg='#F0EDE4';
    const s=R.summarize(ps),photo=state.result.photos[0],num=n=>Number(n).toLocaleString('pt-BR'),date=v=>v.split('-').reverse().join('/');let y=0;
    const clean=t=>String(t??'').replace(/[\x00-\x08\x0b\x0c\x0e-\x1f]/g,'').replace(/→|↗/g,'>');
    function text(t,x,yy,size=9,bold=false,color=navy,align='left'){doc.setFont('helvetica',bold?'bold':'normal');doc.setFontSize(size);doc.setTextColor(color);doc.text(clean(t),x,yy,{align});}
    function wrap(t,width,size=9,bold=false){doc.setFont('helvetica',bold?'bold':'normal');doc.setFontSize(size);return doc.splitTextToSize(clean(t),width);}
    function rule(yy,color=line,width=.2){doc.setDrawColor(color);doc.setLineWidth(width);doc.line(left,yy,right,yy);}
    function newPage(title='Qualidade cadastral'){
      doc.addPage();if(root.ComReportLogoPositive)doc.addImage(root.ComReportLogoPositive,'PNG',left,10,64,12.8);else text('PIC',left,17,10,true,teal);text('RELATÓRIO DE QUALIDADE CADASTRAL',right,17,7,true,muted,'right');rule(23);
      text(title,left,35,20,true);text('Fotografia '+date(photo)+' · Público oficial',left,42,8,false,muted);y=53;
    }
    function ensure(h,title){if(y+h>bottom)newPage(title);}
    function paragraph(t,size=8.5){for(const l of wrap(t,176,size)){ensure(5);text(l,left,y,size,false,muted);y+=4.4;}y+=4;}
    function table(title,headers,rows,widths){
      const grid=()=>{
        text(title,left,y,12,true);y+=7;
        let x=left;const hs=headers.map((h,i)=>wrap(h,widths[i]-3,7.5,true)),hh=Math.max(...hs.map(v=>v.length))*3.5+4;
        headers.forEach((h,i)=>{hs[i].forEach((l,j)=>text(l,i?x+widths[i]-1:x,y+3+j*3.5,7.5,true,teal,i?'right':'left'));x+=widths[i];});y+=hh;rule(y,teal,.35);y+=2;
      };
      ensure(30,'Recortes e prioridades');grid();
      const data=rows.length?rows:[['Sem registros neste recorte',...headers.slice(1).map(()=> '—')]];
      for(const row of data){
        const cells=row.map((v,i)=>wrap(v,widths[i]-4,8.5));let offset=0,max=Math.max(...cells.map(c=>c.length));
        while(offset<max){
          let capacity=Math.floor((bottom-y-6)/4.1);
          if(capacity<1){newPage(title+' | continuação');grid();capacity=Math.floor((bottom-y-6)/4.1);}
          const take=Math.min(max-offset,capacity),height=take*4.1+4;let x=left;
          cells.forEach((ls,i)=>{ls.slice(offset,offset+take).forEach((l,j)=>text(l,i?x+widths[i]-1:x,y+3+j*4.1,8.5,i>0,navy,i?'right':'left'));x+=widths[i];});
          y+=height;rule(y);y+=1;offset+=take;
          if(offset<max){newPage(title+' | continuação');grid();}
        }
      }
      y+=8;
    }
    // Editorial cover. Sections flow continuously, without a forced page per dimension.
    doc.setFillColor(navy);doc.rect(0,0,W,H,'F');
    if(root.ComReportLogo)doc.addImage(root.ComReportLogo,'PNG',left,21,100,20);else text('PIC',left,31,26,true,'#ffffff');
    text('NÚCLEO ANALYTICS',left,67,9,true,'#F0EDE4');text('RELATÓRIO EXECUTIVO',left,90,10,true,'#F0EDE4');
    text('Qualidade dos meios',left,108,27,true,'#ffffff');text('de comunicação',left,122,27,true,'#ffffff');rule(137,gold,.8);
    text('Público oficial',left,151,12,false,'#ffffff');text('Fotografia '+date(photo),left,160,12,true,'#ffffff');
    text('Presença, validade e prioridades de tratamento cadastral.',left,175,9,false,'#F0EDE4');
    [['PÚBLICO ANALISADO',s.identified],['SEM CANAIS CADASTRADOS',s.withoutAny],['COM CANAL VÁLIDO',s.covered]].forEach(([l,v],i)=>{
      const x=left+i*60;doc.setDrawColor('#F0EDE4');doc.setLineWidth(.2);doc.line(x,209,x+54,209);text(l,x,218,6.7,true,'#F0EDE4');text(num(v),x,232,23,true,'#ffffff');
    });
    text('Emitido em '+new Date().toLocaleString('pt-BR'),left,253,8,false,'#F0EDE4');text('USO INTERNO · RECORTE SELECIONADO',left,262,7,true,'#F0EDE4');
    newPage('Panorama e perfil do público');
    const names={group:'Situação Contratual',subgroup:'Sub Situação Contratual',plan:'Plano',sponsor:'Patrocinadora',ageBand:'Faixa etária',exclusion:'Cadastro dos canais'};
    paragraph(Object.entries(filters).filter(([,v])=>v).map(([k,v])=>(names[k]||k)+': '+(M.exclusions.find(d=>d[0]===v)?.[1]||v)).join(' | ')||'Público oficial completo, sem filtros.');
    const kpis=[['Público analisado',s.identified],['Sem e-mail',s.withoutEmail],['Sem celular',ps.filter(p=>p.exclusions.sem_celular).length],['Sem telefone fixo',ps.filter(p=>p.exclusions.sem_fixo).length],['Sem canais cadastrados',s.withoutAny],['Com canal válido',s.covered],['Com inconsistências',s.fail],['Pendentes de tratamento',s.pending]];
    ensure(60);const start=y;
    kpis.forEach(([label,value],i)=>{const x=left+(i%4)*45,yy=start+Math.floor(i/4)*28;doc.setFillColor(bg);doc.rect(x,yy,41,24,'F');wrap(label,35,7.2).forEach((l,j)=>text(l,x+3,yy+5+j*3.3,7.2,false,muted));text(num(value),x+3,yy+20,17,true);});y+=63;
    table('Presença e validade dos canais',['Canal','Cadastrado','Estrutura válida'],Object.entries(M.types).map(([k,v])=>[v.label,num(ps.filter(p=>p.counts[k]>0).length),num(ps.filter(p=>p.validCounts[k]>0).length)]),[88,44,44]);
    for(const [dim,title] of [['contractGroup','Situação Contratual'],['contractSubgroup','Sub Situação Contratual']])table(title,['Categoria','Público','Sem e-mail','Sem canais'],R.segments(ps,dim).map(g=>[g.label,num(g.identified),num(g.withoutEmail),num(g.withoutAny)]),[95,27,27,27]);
    for(const [dim,title] of [['plano','Cobertura por plano'],['patrocinador','Cobertura por patrocinadora']])table(title,['Categoria','Público','Sem e-mail','Sem canais'],R.segments(ps,dim).map(g=>[g.label,num(g.identified),num(g.withoutEmail),num(g.withoutAny)]),[95,27,27,27]);
    const risks=new Map();for(const p of ps)for(const i of p.issues){if(i.rule==='death')continue;const key=JSON.stringify([i.rule,i.problem||i.message]);if(!risks.has(key))risks.set(key,{label:i.problem||i.message,people:new Set()});risks.get(key).people.add(p.id);}
    table('Principais apontamentos',['Problema identificado','Pessoas'],[...risks.values()].sort((a,b)=>b.people.size-a.people.size).map(g=>[g.label,num(g.people.size)]),[149,27]);
    ensure(38,'Notas de leitura');text('Notas de leitura',left,y,11,true);y+=7;
    paragraph('Quantidades representam pessoas distintas. Uma pessoa pode ter mais de um vínculo, canal ou apontamento; categorias não são aditivas. Sem canais cadastrados significa ausência de telefone, celular e e-mail.');
    paragraph('Validade é estrutura, não confirmação de entrega ou titularidade. Óbito é informação do perfil e não gera apontamento de comunicação. Tratado encerra a pendência operacional e preserva a evidência. O DDD não é comparado com o endereço.');
    paragraph('Regras aplicadas: '+M.rules.filter(v=>state.result.selection.includes(v.id)).map(v=>v.label).join('; ')+'.',7.5);
    const total=doc.getNumberOfPages();for(let n=1;n<=total;n++){
      doc.setPage(n);const color=n===1?'#F0EDE4':muted;text('Núcleo Analytics - Setor de Cadastro',W/2,H-11,8,false,color,'center');text(n+' / '+total,W-17,H-11,8,false,color,'right');
    }
    doc.setProperties({title:'PIC - Qualidade dos meios de comunicação',author:'Núcleo Analytics - Setor de Cadastro',subject:'Fotografia '+date(photo)});return doc.output('blob');
  }
  return {generate};
});
