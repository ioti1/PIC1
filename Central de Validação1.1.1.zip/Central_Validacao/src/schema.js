(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.ComSchema=api;})(globalThis,function(){
  'use strict';
  const labels=['Id PF','Nome Participante','Nome Patrocinador','Data Nascimento','Idade','Sexo','Caixa Postal','DDD Telefone 1','Telefone 1','DDD Telefone 2','Telefone 2','DDD Celular 1','Celular 1','DDD Celular 2','Celular 2','Email 1','Email 2','Email 3','Data Óbito','Nome Plano','Matrícula Petros','Situação','Tipo Benefício'];
  const ids=['id','nome','patrocinador','nascimento','idade','sexo','caixa','ddd_tel1','tel1','ddd_tel2','tel2','ddd_cel1','cel1','ddd_cel2','cel2','email1','email2','email3','obito','plano','matricula','situacao','beneficio'];
  const fields=ids.map((id,index)=>({id,label:labels[index],index}));
  const channels=[{id:'tel1',label:'Telefone 1',type:'fixo',ddd:'ddd_tel1'},{id:'tel2',label:'Telefone 2',type:'fixo',ddd:'ddd_tel2'},{id:'cel1',label:'Celular 1',type:'celular',ddd:'ddd_cel1'},{id:'cel2',label:'Celular 2',type:'celular',ddd:'ddd_cel2'},{id:'email1',label:'E-mail 1',type:'email'},{id:'email2',label:'E-mail 2',type:'email'},{id:'email3',label:'E-mail 3',type:'email'}];
  const rules=[
    ['ddd','Telefones e celulares','DDD existente','DDD brasileiro com dois dígitos, existente na tabela de códigos nacionais.','Erro'],
    ['pair','Telefones e celulares','Par DDD e número','Identifica DDD sem número e número local sem DDD.','Erro'],
    ['length','Telefones e celulares','Quantidade de dígitos','Fixo com 8 dígitos; celular com 9. DDD incorporado é interpretado para revisão.','Erro'],
    ['prefix','Telefones e celulares','Prefixo do serviço','Fixo inicia em 2, 3, 4 ou 5; celular inicia em 9.','Erro'],
    ['characters','Telefones e celulares','Caracteres permitidos','Aceita dígitos e máscara usual. Texto, ramal e múltiplos números exigem tratamento.','Erro'],
    ['dummy','Telefones e celulares','Padrão numérico suspeito','Sinaliza dígitos repetidos e sequências de exemplo para confirmar legitimidade.','Alerta'],
    ['format','Telefones e celulares','Padronização dos campos','Sinaliza máscara, DDD/DDI incorporado e zero de discagem. Sugere sem alterar a origem.','Alerta'],
    ['email_syntax','E-mails','Estrutura do e-mail','Uma caixa por campo, @ único, domínio com ponto e limites de comprimento.','Erro'],
    ['email_dummy','E-mails','Possível endereço de exemplo','Sinaliza placeholders como teste, sememail, não informado e example.com para revisão.','Alerta'],
    ['email_format','E-mails','Espaços e caixa','Sinaliza espaços externos e maiúsculas no domínio. Preserva a caixa da parte local.','Alerta'],
    ['email_typo','E-mails','Domínio possivelmente digitado errado','Aponta lista conservadora de erros comuns. A sugestão precisa de confirmação.','Alerta'],
    ['repeat','Cruzamentos','Repetição entre campos','Mesmo contato repetido em mais de um campo do registro.','Alerta'],
    ['shared','Cruzamentos','Contato compartilhado','Mesmo contato associado a pessoas distintas. Não considera repetição da pessoa em planos.','Alerta'],
    ['no_contact','Cruzamentos','Sem canal estruturalmente válido','Nenhum contato atende ao padrão técnico entre os canais mapeados.','Erro'],
    ['identity','Contexto da validação','Identificação e vínculo','Chave ausente e repetição da combinação pessoa, plano, situação e benefício.','Alerta'],
    ['age','Contexto da validação','Idade e nascimento','Data inválida/futura, idade fora de 0–120 e diferença acima de um ano da idade informada.','Alerta'],
    ['death','Contexto da validação','Data de óbito','Marca data de óbito informada e datas inválidas/futuras para revisão do público.','Alerta']
  ].map(([id,group,label,description,severity])=>({id,group,label,description,severity,default:true}));
  const issueTaxonomy={
    ddd:{risk:'DDD e vínculo do número',problem:'ddd_invalido'},pair:{risk:'DDD e vínculo do número',problem:'par_incompleto'},
    length:{risk:'Quantidade de dígitos',problem:'quantidade_digitos'},prefix:{risk:'Estrutura de telefone/celular',problem:'prefixo_invalido'},characters:{risk:'Estrutura de telefone/celular',problem:'caracteres_incompativeis'},
    dummy:{risk:'Legitimidade dos contatos',problem:'padrao_numerico_suspeito'},format:{risk:'Padronização dos contatos',problem:'telefone_fora_padrao'},
    email_syntax:{risk:'Estrutura do e-mail',problem:'email_estrutura_invalida'},email_dummy:{risk:'Legitimidade dos contatos',problem:'email_exemplo_ou_placeholder'},email_format:{risk:'Padronização dos contatos',problem:'email_fora_padrao'},email_typo:{risk:'Estrutura do e-mail',problem:'dominio_possivelmente_incorreto'},
    repeat:{risk:'Duplicidade e compartilhamento',problem:'contato_repetido'},shared:{risk:'Duplicidade e compartilhamento',problem:'contato_compartilhado'},
    no_contact:{risk:'Cobertura de comunicação',problem:'nenhum_canal_valido'},identity:{risk:'Contexto cadastral',problem:'identificacao_ou_vinculo'},age:{risk:'Contexto cadastral',problem:'idade_ou_nascimento'},death:{risk:'Contexto cadastral',problem:'obito_informado'}
  };
  const problemLabels={ddd_invalido:'DDD inválido',ddd_inexistente:'DDD inexistente',ddd_quantidade_digitos:'DDD com quantidade incorreta de dígitos',par_incompleto:'Par DDD e número incompleto',ddd_ausente:'DDD ausente',numero_ausente:'Número ausente',ddd_divergente:'DDD divergente entre os campos',quantidade_digitos:'Quantidade incorreta de dígitos',digitos_faltantes:'Faltam dígitos',digitos_excedentes:'Excedem dígitos',prefixo_invalido:'Prefixo inválido',prefixo_celular_invalido:'Prefixo de celular inválido',prefixo_fixo_invalido:'Prefixo de telefone fixo inválido',caracteres_incompativeis:'Caracteres incompatíveis',padrao_numerico_suspeito:'Padrão numérico suspeito',telefone_fora_padrao:'Telefone fora do padrão',email_estrutura_invalida:'Estrutura de e-mail inválida',email_exemplo_ou_placeholder:'E-mail de exemplo ou ausência',email_fora_padrao:'E-mail fora do padrão',dominio_possivelmente_incorreto:'Domínio possivelmente incorreto',contato_repetido:'Contato repetido entre campos',contato_compartilhado:'Contato compartilhado entre pessoas',nenhum_canal_valido:'Nenhum canal válido',identificacao_ou_vinculo:'Identificação ou vínculo',chave_pessoa_ausente:'Chave da pessoa ausente',vinculo_repetido:'Vínculo repetido',idade_ou_nascimento:'Idade ou nascimento',obito_informado:'Óbito informado',email_separador_invalido:'Separador inválido no e-mail',email_arroba_ausente:'E-mail sem @',email_arroba_multipla:'E-mail com múltiplos @',email_caixa_ausente:'Nome da caixa ausente',email_dominio_ausente:'Domínio ausente',email_espaco_interno:'Espaço dentro do e-mail',email_excede_limite:'E-mail acima de 254 caracteres',email_caixa_excede_limite:'Nome da caixa acima de 64 caracteres',email_pontos_caixa:'Pontos inválidos no nome da caixa',email_caractere_caixa:'Caractere inválido no nome da caixa',email_dominio_sem_ponto:'Domínio sem ponto e extensão',email_pontos_dominio:'Pontos inválidos no domínio',email_rotulo_dominio_excede_limite:'Parte do domínio acima de 63 caracteres',email_caractere_dominio:'Caractere ou hífen inválido no domínio',email_extensao_invalida:'Extensão do domínio inválida'};
  Object.values(issueTaxonomy).forEach(t=>{t.problemCode=t.problem;t.problem=problemLabels[t.problem];});
  rules.forEach(rule=>Object.assign(rule,issueTaxonomy[rule.id]));
  const dddUF={};
  const ufCodes={SP:'11 12 13 14 15 16 17 18 19',RJ:'21 22 24',ES:'27 28',MG:'31 32 33 34 35 37 38',PR:'41 42 43 44 45 46',SC:'47 48 49',RS:'51 53 54 55',DF:'61',GO:'62 64',TO:'63',MT:'65 66',MS:'67',AC:'68',RO:'69',BA:'71 73 74 75 77',SE:'79',PE:'81 87',AL:'82',PB:'83',RN:'84',CE:'85 88',PI:'86 89',PA:'91 93 94',AM:'92 97',RR:'95',AP:'96',MA:'98 99'};
  Object.entries(ufCodes).forEach(([uf,list])=>list.split(' ').forEach(d=>dddUF[d]=uf));
  const version='1.1.0';
  return {fields,channels,rules,dddUF,version,labels,issueTaxonomy,problemLabels};
});
