# Petros · Qualidade dos Meios de Comunicação v3.1.1

Aplicação local e independente. A v2 anterior e o HUB Cadastro v15.1 foram preservados. O HUB v15.1 serviu de referência para paleta e logos por tema. A abertura usa a imagem enviada pelo usuário em composição única: azul-petróleo e turquesa, texto branco à esquerda e ícones à direita. As versões anteriores foram preservadas. Esta atualização é apenas visual: motor de validação 3.1.0, regras, contrato PBI 3 e perfis mensais permanecem iguais. Não exige nova migração do Power BI para quem já usa a v3.1.0.

## Abrir e usar

1. Extraia a pasta inteira. Abra index.html em Edge ou Chrome atualizado, de 64 bits. Não abra o HTML diretamente dentro do ZIP.
2. Em Público oficial, adicione um ou mais XLSX, CSV ou TXT. O assistente abre automaticamente: colunas → fotografia manual → confirmação/processamento. Arquivos são concatenados antes da validação.
3. A base de contatos é liberada. Adicione os arquivos e siga o mesmo assistente com a mesma fotografia. Nome do arquivo não define o leiaute: os campos e a ordem de referência orientam o mapeamento.
4. O mapeamento permanece abaixo dos cartões para revisão. Alterar coluna ou fotografia exige reprocessamento.
5. Explore os filtros cruzados em Universo e cobertura. As barras têm valores, tooltip acessível ao teclado e clique para recortar a página. Limpar remove também a seleção do gráfico.
6. Clique na quantidade de Principais apontamentos para abrir a fila no problema correspondente. Na fila, pesquise pessoa/usuário, filtre perfil, qualidade, regra, problema e óbito.
7. Marque Tratado para encerrar pendências sem apagar o achado. Salve o andamento em JSON antes de fechar. Restauração só afeta marcas compatíveis com as mesmas fontes, fotografia, mapeamento, regras e versão.

## Exportações

- Excel deste recorte: todas as pessoas retornadas pelos filtros, uma linha por pessoa, dez colunas: matrícula, nome, nascimento, plano, patrocinadora, situação, sub situação, problema, campos relacionados e data de óbito separada. Não depende da página visível. Na visão de contatos, os contatos selecionados são consolidados por pessoa; por isso a quantidade de pessoas pode ser menor que a quantidade de linhas da fila.
- Excel completo / Power BI: um único .xlsx mensal, independente dos filtros. Base_Cadastral é a única base lógica; Execucao contém os metadados. Sem ZIP e sem blocos de 25 mil linhas. A base tem pessoa x vínculo oficial distinto x problema, então use as medidas de contagem distinta, nunca soma de flags ou contagem de linhas. Só haverá partes internas se atingir o limite físico de linhas do Excel.
- PDF gerencial: download direto com capa, fotografia, recorte, planos, situações, patrocinadoras, apontamentos e rodapé institucional paginado. Não usa a impressão do navegador e não imprime caminhos locais.
- PowerBI_Mensal: manual de 28 páginas, três consultas M, 22 medidas DAX, tema e prévia visual das três páginas. Uma montagem inicial; mensalmente, só acrescentar o Excel na pasta Entrada e Atualizar. Reprocessamento substitui apenas o arquivo do mês.

## Definições e limites

O público oficial é a autoridade. Contatos sem correspondência ou sem matrícula não participam dos indicadores, da fila, dos compartilhamentos, do PDF nem do Excel consolidado. Linhas oficiais sem chave utilizável não podem ser conciliadas e não entram no denominador de pessoas identificadas. A finalidade não é auditar a matrícula.

Sem canais cadastrados significa nenhum telefone, celular ou e-mail com valor cadastrado. Não é duplicado como Sem registro. Sem e-mail, sem celular e sem telefone são ausência de valor, não invalidade. Um tipo desconhecido com valor impede afirmar ausência com certeza. Validade é estrutura, não entrega ou titularidade.

DDD 0071 equivale a 71 sem alerta pelos zeros à esquerda. DDD incompleto/inexistente e falta de DDD geram mensagens específicas. Não há cruzamento DDD x UF/endereço. O endereço residencial não limita o DDD do telefone. Evidência apresenta DDD antes do número e a extração mantém os campos de origem relacionados ao achado.

Ativos inclui as situações de deferimento, Ativo, Remido, Autopatrocinado e Optante pelo BPO. Assistidos é separado em Pensionista quando o benefício contém PENS; os demais assistidos são Aposentado. Situações novas permanecem Não classificado, sem inferência silenciosa.

Óbito é contexto cadastral, sem gerar erro, ressalva ou pendência de comunicação por si só. A data tem coluna própria na fila e no Excel. Com óbito significa alguma data informada (inclusive inválida). A ficha destaca Falecido em DD/MM/AAAA quando a data é utilizável; caso contrário, informa data inválida para revisão. Nascimento usa DD/MM/AAAA; idade considera a fotografia, quando há nascimento válido.

Somente uma fotografia por processamento. O histórico mensal fica no PBI, com uma execução homologada por mês. A exportação usa contrato PBI 3 e o indicador Sem_Canais_Cadastrados. Arquivos anteriores à v3.1 precisam ser reprocessados nesta versão antes da comparação, sem misturar critérios de validação. Na prévia visual, agosto e setembro são cenários ilustrativos isolados, nunca exportados como dados reais.

## Layout e acessibilidade

Logos originais claro/escuro alternadas sem inversão de cores. Imagem fornecida, integrada ao fundo de ponta a ponta com transição suave, sem card lateral. O banner desktop passou de 320 para 288 px de altura (-10%); em telas estreitas, a altura se adapta ao texto para preservar os botões. A arte mantém sua proporção e os ícones não são recortados na vertical. A ordem da navegação e das ações é estável em notebooks e monitores. Faixa intermediária de 901 a 1600 px mantém menu lateral, dois cartões de carga e os seis filtros de cobertura e de perfil em uma linha a partir de 1101 px; o óbito ocupa uma coluna compacta no perfil. Em larguras menores os controles se reorganizam sem desaparecer. Abaixo de 900 px o menu passa ao topo e os cartões se empilham na mesma ordem. Tabelas podem rolar horizontalmente sem deslocar o restante da página. Diálogos preservam cabeçalho e ações de navegação. Interface respeita redução de movimento e foco de teclado.

## Verificações realizadas

- Cabeçalho v3.1.1: integridade da imagem fornecida, texto acessível fora da arte, camadas sem card, regras responsivas e altura desktop de 288 px conferidos estruturalmente. Scripts de validação e exportação idênticos aos da v3.1.0.
- 75 verificações automáticas: 26 verificações de interação em substituto de DOM, incluindo assistente, fotografia, filtros, óbito, segurança de HTML, paginação, tratamento e exportações; mais 15 verificações de dados/segurança e testes de leitor, regras, apresentação e contrato Power BI.
- Recorte sintético com 12.000 pessoas: exatamente 12.000 linhas e dez colunas, independentemente da página.
- Leitura integral local das referências: 128.434 vínculos, 123.845 matrículas identificadas e 420.950 contatos vinculados. Excel consolidado verificado por CRC e reconciliação: 135.735 linhas de dados, 123.845 pessoas distintas, duas abas, cerca de 38 MB. Tempo de exportação observado na revisão final aproximadamente 25 s, variável por computador. Nenhuma base pessoal foi incluída no pacote.
- Regras de telefone/e-mail e leitor XLSX testados separadamente. Referências M/DAX conferidas com o contrato de colunas; referências independentes para mês ausente, janeiro/dezembro, perfil diferente e zero legítimo.
- PDF manual renderizado e inspecionado, sem conteúdo fora das margens. PDF do aplicativo verificado com dados fictícios: três páginas, incluindo capa, sem forçar uma página por dimensão. Excel operacional importado e renderizado para conferir layout, máscara de datas e óbito separado.

Limites de verificação: não houve inspeção visual automatizada no navegador desta versão. As regras responsivas foram revisadas estruturalmente, mas a navegação real nos equipamentos de destino ainda requer homologação. M/DAX não foram executados dentro do Power BI Desktop; compare o primeiro PBIX com o HUB conforme o manual. Não há PBIX pronto nesta entrega.

## Privacidade e operação

Não há servidor, envio de dados, CDN em execução ou persistência automática das bases no navegador. Bibliotecas são locais. Fechar/recarregar perde a base e o andamento não salvo. Use equipamento com memória suficiente para bases extensas; os testes reais utilizaram aproximadamente 2 GB apenas no processamento, além do navegador/exportação. O limite de 32.767 caracteres por célula do Excel é detectado sem truncamento silencioso: em caso de excesso, refine o recorte/revise o cadastro.

Ocultar a página Dados por pessoa no Power BI não protege os dados do modelo. Para a Direção, envie um PDF agregado ou solicite à TI um relatório/modelo sem dados pessoais e controles de acesso apropriados.

Dependências: JSZip local e jsPDF 4.2.1 local (licença MIT em vendor). O programa gera o PDF diretamente com texto e vetores; não há captura de tela desfocada.


## Edição PIC 3.0 / Comunicação 3.1.2

Identidade visual Cyprus e Sand com matriz transparente única. Os botões Gerar ZIP de erros e Gerar ZIP de alertas geram, cada um, exatamente um HTML e um Excel. Cada código representa uma regra estável; a quantidade no resumo corresponde às ocorrências (linhas da aba), sem deduplicar a pessoa. Os lotes verificam todas as regras sobre o cruzamento completo, ignoram filtros e marcações de tratamento e não alteram o estado da tela. Códigos com zero permanecem no resumo e possuem aba com cabeçalho. O Excel preserva a matrícula e o dado da origem, inclusive zeros e espaços.

## Manutenção do Excel por código - 23/10/2026

Esta revisão parte do Central_Validacao.rar fornecido pelo usuário e mantém integralmente a identidade visual atual do PIC. Consulte MANUTENCAO.md para identificar a base correta dos próximos ajustes.

Nos dois lotes da etapa 5 (erros e alertas), todas as abas de evidências seguem o mesmo padrão:

- Linha 1: código e descrição do erro/alerta daquela aba.
- Linha 2: data do estudo, obtida da fotografia informada para a base. Ela não é substituída pela data de geração.
- Linha 3: data e hora de geração no horário de Brasília.
- Linha 4: respiro; linha 5: cabeçalhos; a partir da linha 6: evidências.
- Todas essas linhas usam altura fixa de 24 pontos, sem quebra automática nem redução da fonte. As colunas ficam mais largas, com largura máxima controlada.
- Após Nome, entram Plano, Patrocinadora, Situação Contratual, Subsituação Contratual e Data de Óbito. Na sequência ficam o dado original para análise e a fotografia.
- Pessoas com vários vínculos mantêm os valores distintos separados por " | ", sem duplicar a ocorrência. Óbito é informação do perfil, não um erro adicional.
- Datas válidas são datas reais do Excel, exibidas em DD/MM/AAAA. Óbito ausente fica em branco; uma data de óbito inválida preserva o texto da origem.
- Filtros começam na linha 5. As cinco primeiras linhas e as colunas Matrícula/Nome ficam fixas durante a rolagem.

Textos excepcionalmente longos continuam completos no arquivo e podem ser consultados na barra de fórmulas. Não há corte silencioso de dados para caber na largura. O limite de 32.767 caracteres por célula continua sendo verificado.

Verificações desta manutenção: erros e alertas com abas vazias e preenchidas; perfil com múltiplos vínculos; óbito válido/ausente/inválido; fotografia histórica; geração na virada do dia em Brasília; literalidade de textos com aparência de fórmula; contagens conciliadas; divisão somente quando necessária pelo limite físico do Excel; teste de 50.001 evidências em uma aba. Planilhas sintéticas foram importadas e renderizadas para conferência visual.

Não houve alteração no motor de validação, no mapeamento, nas telas, nos indicadores, nos PDFs ou no contrato da base mensal do Power BI. Não é necessário migrar o painel por causa desta revisão.

O manual técnico do Power BI da versão de origem foi preservado como referência. A interface, a capa e os cabeçalhos do relatório gerado usam a identidade PIC.
