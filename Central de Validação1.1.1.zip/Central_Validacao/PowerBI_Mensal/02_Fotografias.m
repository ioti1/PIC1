let
    Metadados = Table.Distinct(Table.SelectColumns(Base_Cadastral,
        {"Mes_Referencia","Data_Fotografia","Perfil_Regras"})),
    Menor = List.Min(Metadados[Mes_Referencia]),
    Maior = List.Max(Metadados[Mes_Referencia]),
    Meses = List.Generate(()=>Menor,each _ <= Maior,each Date.AddMonths(_,1)),
    Calendario = Table.FromList(Meses,Splitter.SplitByNothing(),{"Mes_Referencia"}),
    Tipos = Table.TransformColumnTypes(Calendario,{{"Mes_Referencia",type date}}),
    Juncao = Table.NestedJoin(Tipos,{"Mes_Referencia"},Metadados,
        {"Mes_Referencia"},"Foto",JoinKind.LeftOuter),
    Expandida = Table.ExpandTableColumn(Juncao,"Foto",{"Data_Fotografia","Perfil_Regras"}),
    Rotulo = Table.AddColumn(Expandida,"Ano_Mes",each
        Date.ToText([Mes_Referencia],"yyyy-MM","pt-BR"),type text),
    Recebido = Table.AddColumn(Rotulo,"Recebido",each
        if [Data_Fotografia] = null then 0 else 1,Int64.Type)
in Recebido
