# Power BI mensal - modelo simplificado v3.1

Uma pasta de entrada, três consultas, um relacionamento, três páginas.

1. No HUB, carregue público e contatos. Informe manualmente a mesma fotografia. Processe e gere o Excel completo / Power BI.
2. Coloque PETROS_PBI_MENSAL_AAAA-MM.xlsx em C:\PBI_Comunicacao\Entrada.
3. Power BI Desktop > Transformar dados > Nova fonte > Consulta nula. Editor Avançado, nesta ordem:
   - pPastaPBI: conteúdo de 00_pPastaPBI.m. Ajuste apenas o caminho entre aspas. Desabilite carga.
   - Base_Cadastral: conteúdo de 01_Base_Cadastral.m.
   - Fotografias: conteúdo de 02_Fotografias.m.
4. Fechar e aplicar. Modelo: Fotografias[Mes_Referencia] (1) para Base_Cadastral[Mes_Referencia] (*), direção única. Nenhum outro relacionamento.
5. Crie cada medida de 03_Medidas.dax separadamente em Modelagem > Nova medida. Não cole tudo de uma vez. Taxas: percentual. Variação: decimal, em pontos percentuais.
6. Importe Tema_Petros.json. Monte as páginas Direção, Evolução e Dados por pessoa conforme o PDF.
7. Mensalmente: acrescente o novo Excel à mesma pasta, abra o PBIX e clique Atualizar. Não refaça consultas nem gráficos.

## Histórico

Uma fotografia homologada por mês. Reprocessou? Substitua seu arquivo, sem cópias (1). Não apague os outros meses. O nome vem do mês da fotografia, não do processamento. A leitura valida nome, contrato, fotografia, execução e quantidade de matrículas. O contrato mensal é 3 (v3.1). Antes de migrar um PBIX anterior, substitua a consulta Base_Cadastral e as medidas pelas versões deste pacote. Reprocesse as fontes históricas na v3.1 e substitua os arquivos mensais antigos, para manter a mesma regra. Essa atualização é feita uma vez; depois basta acrescentar o mês e Atualizar.

## Contagem correta

Base_Cadastral tem uma linha por pessoa + vínculo oficial distinto + problema específico. Contatos do mesmo problema ficam agregados na evidência, preservando valores únicos. Pessoas sem apontamento e sem contato permanecem presentes. Não há contatos externos.

Nunca use contagem de linhas para medir pessoas. Use Publico analisado e as medidas DISTINCTCOUNT. Totais por planos/patrocinadoras não são aditivos. Não some flags nem Qtd_* sobre a tabela expandida: são atributos da pessoa, repetidos a cada problema e vínculo.

Sem e-mail, sem celular e sem telefone significam ausência de valor cadastrado desse tipo, não invalidade. Tipo desconhecido com valor impede afirmar ausência com certeza. Canal válido significa estrutura válida, não entrega ou titularidade. Óbito é contexto e não gera erro ou ressalva por si só. Data_Obito é uma coluna separada. Com óbito inclui data informada inválida, sujeita a revisão. Tratado preserva os achados.

## Páginas

Direção: mês, situação, sub situação, plano e patrocinadora; seis cartões (público, sem e-mail, sem celular, sem telefone, sem canais cadastrados e com canal válido); barras por plano e situação. Não usar pizza.

Evolução: plano, patrocinadora, situação, sub situação, regra e problema; linha mensal Taxa de apontamento; barras lado a lado atual/anterior por plano e patrocinadora; matriz mês x plano. Eixo temporal Fotografias[Ano_Mes], Mostrar itens sem dados. Não conectar meses ausentes. Comparativos ficam em branco sem mês anterior ou com regras diferentes. Mudanças de público também alteram a taxa; não provam correção cadastral por si só.

Dados por pessoa: mês com seleção única; Nome e Matricula_Petros com Pesquisa; perfil, Resultado, Tratamento e Obito_Informado; tabela de matrícula, nome, plano, patrocinadora, nascimento, resultado, regra, problema e Campos_Relacionados. No filtro do visual: No mes exibido = 1. É uma tabela pessoa/problema; o Excel operacional continua uma pessoa por linha.

Sem mês selecionado, cartões mostram o último mês disponível. Vários meses: cartões mostram o último do intervalo; linhas preservam cada mês no eixo. Não sincronize o filtro de mês da Direção com a Evolução, para não cortar a série.

## Segurança e verificação

Use pasta corporativa restrita. Não publique Dados por pessoa à Direção sem autorização. O pacote não inclui bases pessoais. A página Direção usa agregados das bases fornecidas, sem nomes/matrículas reais. A página Evolução contém agosto e setembro simulados, claramente identificados. Esses valores não são incluídos no Excel, nas consultas ou nas medidas. M e DAX foram revisados estruturalmente, mas não executados no Power BI Desktop nesta entrega. Homologue o primeiro PBIX comparando os totais ao HUB.
