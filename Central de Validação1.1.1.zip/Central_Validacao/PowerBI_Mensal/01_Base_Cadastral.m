let
    Fonte = Folder.Contents(pPastaPBI),
    Visiveis = Table.SelectRows(Fonte, each [Extension] <> null
        and not Text.StartsWith([Name], "~$")
        and Record.FieldOrDefault([Attributes], "Hidden", false) <> true),
    Arquivos = Table.SelectRows(Visiveis, each Text.Lower([Extension]) = ".xlsx"),
    ForaPadrao = Table.SelectRows(Visiveis, each
        List.Contains({".xlsx", ".xls", ".csv", ".zip"},Text.Lower([Extension]))
        and (Text.Lower([Extension]) <> ".xlsx" or not
            Text.StartsWith(Text.Upper([Name]), "PETROS_PBI_MENSAL_"))),
    Validados = if Table.RowCount(ForaPadrao) > 0 then error
        "Entrada deve conter apenas os Excel mensais completos do HUB v3.1. Retire recortes, ZIP e arquivos antigos."
        else Arquivos,
    Ler = (Arquivo as record) as table =>
        let
            Nome = Arquivo[Name],
            Mes = try Date.FromText(Text.Middle(Nome,18,7) & "-01",
                [Format="yyyy-MM-dd",Culture="en-US"]) otherwise null,
            NomeCorreto = if Mes = null then false else Text.Upper(Nome) =
                "PETROS_PBI_MENSAL_" & Date.ToText(Mes,"yyyy-MM","en-US") & ".XLSX",
            Livro = if not NomeCorreto then error
                ("Nome mensal inválido: " & Nome & ". Retire cópias (1).")
                else Excel.Workbook(Arquivo[Content],null,true),
            MetaBruta = try Livro{[Item="Execucao",Kind="Sheet"]}[Data]
                otherwise error ("Falta Execucao: " & Nome),
            Meta = Table.PromoteHeaders(MetaBruta,[PromoteAllScalars=true]),
            E = if Table.RowCount(Meta) = 1 then Meta{0}
                else error ("Execucao inválida: " & Nome),
            Foto = try Date.From(E[Data_Fotografia]) otherwise null,
            Valido = if Foto = null then false else
                Record.FieldOrDefault(E,"Contrato_PBI",0) = 3 and
                Record.FieldOrDefault(E,"Publico_Completo",0) = 1 and
                Date.StartOfMonth(Foto) = Mes and
                E[Competencia] = Date.ToText(Mes,"yyyy-MM","en-US"),
            Abas = if not Valido then error
                ("Arquivo incompatível ou parcial: " & Nome & ". Gere pelo HUB v3.1.")
                else Table.SelectRows(Livro,each [Kind] = "Sheet" and
                    ([Item] = "Base_Cadastral" or
                        (Text.StartsWith([Item],"Base_Cadastral_") and
                         (try Number.FromText(Text.AfterDelimiter([Item],
                            "Base_Cadastral_")) otherwise 0) > 1))),
            Partes = List.Transform(Abas[Data],each
                Table.PromoteHeaders(_,[PromoteAllScalars=true])),
            Colunas = if List.IsEmpty(Partes) then error
                ("Falta Base_Cadastral: " & Nome) else Table.ColumnNames(Partes{0}),
            Iguais = List.AllTrue(List.Transform(Partes,each Table.ColumnNames(_) = Colunas)),
            Base = if not Iguais then error ("Abas divergentes: " & Nome)
                else Table.Combine(Partes),
            Tipos = Table.TransformColumnTypes(Base,{
                {"Data_Fotografia",type date},{"Mes_Referencia",type date},
                {"Chave_Pessoa",type text},{"Matricula_Petros",type text},
                {"Id_Execucao",type text},{"Perfil_Regras",type text},
                {"Nome",type text},{"Plano",type text},{"Patrocinadora",type text},
                {"Situacao_Contratual",type text},{"Sub_Situacao_Contratual",type text},
                {"Resultado",type text},{"Tratamento",type text},{"Regra",type text},
                {"Problema_Identificado",type text},{"Severidade",type text},
                {"Sem_Email",Int64.Type},{"Sem_Celular",Int64.Type},
                {"Sem_Telefone",Int64.Type},{"Sem_Canais_Cadastrados",Int64.Type},
                {"Com_Canal_Valido",Int64.Type},{"Sem_Digital_Valido",Int64.Type},
                {"Com_Inconsistencia",Int64.Type},{"Com_Ressalva",Int64.Type},
                {"Pendente",Int64.Type},{"Obito_Informado",Int64.Type},
                {"Qtd_Telefones",Int64.Type},{"Qtd_Celulares",Int64.Type},
                {"Qtd_Emails",Int64.Type},{"Qtd_Canais_Validos",Int64.Type}},"pt-BR"),
            Datas = Table.TransformColumns(Tipos,{
                {"Data_Nascimento",each try Date.From(_) otherwise null,type date},
                {"Data_Obito",each try Date.From(_) otherwise null,type date},
                {"Primeiro_Cadastro",each try DateTime.From(_) otherwise null,type datetime},
                {"Ultimo_Cadastro",each try DateTime.From(_) otherwise null,type datetime},
                {"Idade",each try Int64.From(_) otherwise null,Int64.Type}}),
            Ruins = Table.SelectRows(Datas,each
                [Data_Fotografia] <> Foto or [Mes_Referencia] <> Mes or
                [Id_Execucao] <> Text.From(E[Id_Execucao]) or
                [Perfil_Regras] <> Text.From(E[Perfil_Regras]) or
                [Chave_Pessoa] = null or Text.Trim([Chave_Pessoa]) = ""),
            Conferida = if Table.RowCount(Ruins) > 0 or
                List.Count(List.Distinct(Datas[Chave_Pessoa])) <> Number.From(E[Participantes])
                then error ("Universo, fotografia ou execução divergente: " & Nome) else Datas
        in Table.AddColumn(Conferida,"Arquivo_PBI",each Nome,type text),
    Tabelas = List.Transform(Table.ToRecords(Validados),each Ler(_)),
    Esquemas = List.Transform(Tabelas,each Table.ColumnNames(_)),
    Dados = if List.IsEmpty(Tabelas) then error
        "Entrada vazia. Gere o arquivo mensal no HUB."
        else if not List.AllTrue(List.Transform(Esquemas,each _ = Esquemas{0}))
        then error "Meses com estruturas diferentes. Reprocesse com a mesma versão do HUB."
        else Table.Combine(Tabelas),
    Meses = Table.Distinct(Table.SelectColumns(Dados,{"Mes_Referencia","Arquivo_PBI"})),
    Contagem = Table.Group(Meses,{"Mes_Referencia"},{{"Arquivos",each Table.RowCount(_),Int64.Type}}),
    Duplicados = Table.SelectRows(Contagem,each [Arquivos] <> 1)
in
    if Table.RowCount(Duplicados) > 0 then error
        "Há mais de um arquivo do mesmo mês. Deixe apenas uma fotografia oficial por mês."
    else Dados
