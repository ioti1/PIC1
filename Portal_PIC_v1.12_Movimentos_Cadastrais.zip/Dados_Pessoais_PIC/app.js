(() => {
  'use strict';
  const R=PicPessoal,IO=globalThis.PicPessoalIO,H=PicPessoalHistory,Q=PicPessoalQuery,M=PicPessoalMoves;
  const $=id=>document.getElementById(id),num=v=>Number(v||0).toLocaleString('pt-BR');
  const esc=v=>String(v??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  const dash=v=>R.str(v)||'—',D=R.dateDisplay,wait=()=>new Promise(ok=>setTimeout(ok,0));
  const monthText=m=>m?m.slice(5,7)+'/'+m.slice(0,4):'—';
  const controls=[...document.querySelectorAll('[data-filter]')];
  const selectedFiles={baseFiles:[],extraFiles:[]},session=new Map();
  const mode=$('operation')?'ops':'bi';
  const stages={preparar:['Preparar bases',''],regras:['Regras de validação',''],diagnostico:['Universo e erros','Consulte o público avaliado e selecione um código para investigar.'],fila:['Fila de tratamento','Consulte as evidências e registre o andamento da análise.'],exportacoes:['Relatórios e evidências','Gere os arquivos da competência e do recorte selecionados.']};
  let stage='preparar',catalog=new Map(),folder=null,folderState='',dbAvailable=true,working=false;
  let current=null,previous=null,packed=null,retiredCount=0,loadedMonth='',selectedSource='',filter={},selectedView=null;
  let page=1,detailCase=null,detailTrigger=null,marks=new Set(),movementMode='',movementView=null;
  let popCache=null,popPage=1,popTimer=0,popSummaryCache=null;
  const expandedRules=new Set();
  const monthly=new Set(R.monthlyCodes),stylePeriod=new Intl.NumberFormat('pt-BR',{maximumFractionDigits:1});
  const codeOrder=new Intl.Collator('pt-BR',{numeric:true});
  function catalogEntries(leaves,selected=''){
    const out=[];
    for(const r of [...leaves].sort((a,b)=>codeOrder.compare(a.code,b.code))){
      if(r.parent&&!out.some(x=>x.code===r.parent)&&(!selected||selected===r.parent))
        out.push({code:r.parent,title:R.families[r.parent],family:true});
      out.push(r);
    }
    return out;
  }
  function status(message='',error=false){
    const node=$('notice');node.hidden=!message;node.textContent=message;node.dataset.error=String(error);
    const feedback=$('historyFeedback');
    if(feedback&&$('historyDialog').open){feedback.hidden=!message;feedback.textContent=message;feedback.dataset.error=String(error);}
  }
  function progress(message,pct=null){
    $('busyText').textContent=message;$('busy').hidden=false;
    if(pct==null)$('progress').removeAttribute('value');else{$('progress').max=100;$('progress').value=pct;}
  }
  async function task(fn){
    if(working)return;
    working=true;
    const actions=['run','linkDirectory','refreshHistory','historyFiles','period','saveRun','exportCases','baseFiles','extraFiles','clearBase','clearExtra','print'];
    for(const id of actions)if($(id))$(id).disabled=true;
    status();
    try{await fn();}
    catch(e){if(e?.name!=='AbortError')status(e?.message||'Não foi possível concluir a operação.',true);}
    finally{
      working=false;$('busy').hidden=true;
      for(const id of actions)if($(id))$(id).disabled=false;
      syncExport();
    }
  }
  function download(blob,name){
    const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;
    document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);
  }
  async function permitted(handle,access='read'){
    if(!handle)return false;
    try{return (await handle.queryPermission({mode:access}))==='granted';}catch{return false;}
  }
  async function refreshCatalog(){
    const next=new Map();
    let entries=[];
    try{entries=await H.list();dbAvailable=true;}catch{dbAvailable=false;}
    for(const e of entries)next.set(e.month,{local:e});
    for(const [key,data] of session)next.set(key,{...(next.get(key)||{}),session:data});
    if(folder&&await permitted(folder)){
      try{
        for(const e of await H.scan(folder))next.set(e.month,{...(next.get(e.month)||{}),remote:e.handle});
        folderState='Pasta vinculada: '+folder.name;
      }catch{folderState='Pasta vinculada indisponível. Vincule novamente ou importe o arquivo.';}
    }else folderState=folder?'A pasta precisa de nova autorização. Use Vincular pasta.':'Nenhuma pasta vinculada.';
    catalog=next;
    const months=[...catalog.keys()].sort().reverse();
    const select=$('period');
    select.replaceChildren(...months.map(m=>{
      const e=catalog.get(m),entry=e.session?.record||e.local;
      return new Option(monthText(m)+(entry?.photo?' · '+D(entry.photo):''),m);
    }));
    if(loadedMonth&&next.has(loadedMonth))select.value=loadedMonth;
    $('historyStatus').textContent=(months.length?num(months.length)+' competência(s) disponível(is). ':'Nenhuma competência salva. ')+folderState+(dbAvailable?'':' Memória do navegador indisponível.');
    updatePriorHint();
    return months;
  }
  function updatePriorHint(){
    if(mode!=='ops')return;
    const photo=$('photo').value;
    if(!photo){$('priorHint').textContent='Informe a competência para localizar o mês anterior.';return;}
    const prior=R.priorMonth(photo),found=catalog.has(prior);
    $('priorHint').textContent=found?'Mês anterior disponível: '+monthText(prior)+'.':'Sem arquivo de '+monthText(prior)+'. As quatro regras mensais não serão avaliadas.';
  }
  async function getBlob(month){
    const e=catalog.get(month);
    if(!e)return null;
    const localStamp=e.session?.record.storedAt||e.local?.storedAt||0;
    if(e.remote){
      try{
        const f=await e.remote.getFile();
        if(f.lastModified>=localStamp||!localStamp)return {blob:f,origin:'Pasta vinculada'};
      }catch(error){if(!localStamp)throw error;}
    }
    const blob=e.session?.blob||await H.load(month).catch(()=>null);
    return blob?{blob,origin:e.session?'Sessão atual':'Histórico local'}:null;
  }
  async function readPeriod(month){
    const data=await getBlob(month);if(!data)return null;
    const decoded=await H.decode(data.blob);
    if(decoded.manifest.month!==month)throw Error('O nome do arquivo na pasta não corresponde à competência interna.');
    return {...decoded,...data};
  }
  async function loadMonth(month){
    progress('Abrindo avaliação de '+monthText(month)+'…');
    const data=await readPeriod(month);
    if(!data)throw Error('A competência selecionada não está disponível.');
    // Clear references before loading the comparison month; keep at most two runs.
    current=data.run;packed=data.blob;retiredCount=data.retiredCount;previous=null;loadedMonth=month;selectedSource=data.origin;
    marks=new Set(((await H.prefs('treated:'+month).catch(()=>null))||[]).map(Q.upgradeMark));
    filter={};page=1;movementMode='';$('search').value='';
    const prev=R.priorMonth(data.run.photo);
    if(catalog.has(prev))try{previous=(await readPeriod(prev))?.run||null;}catch(e){status('Não foi possível abrir o mês anterior: '+e.message,true);}
    $('period').value=month;
    render();
  }
  async function reload(selectLatest=false){
    progress('Conferindo histórico…');
    const months=await refreshCatalog();
    const desired=selectLatest?months[0]:loadedMonth&&catalog.has(loadedMonth)?loadedMonth:months[0];
    if(desired)await loadMonth(desired);
    else{current=null;previous=null;loadedMonth='';packed=null;retiredCount=0;render();}
  }
  async function connectFolder(){
    if(typeof window.showDirectoryPicker!=='function'){
      status('Este navegador não permite vincular pastas. Use Importar .picdp para ler os arquivos salvos.',true);return;
    }
    const selected=await window.showDirectoryPicker({id:'pic-dados-pessoais',mode:mode==='ops'?'readwrite':'read'});
    folder=selected;
    await H.prefs('folder',selected).catch(()=>{});
    await reload(true);
  }
  async function importHistory(files){
    for(const f of files){
      progress('Conferindo '+f.name+'…');
      const {manifest}=await H.decode(f);
      if(catalog.has(manifest.month)&&!confirm('Substituir a avaliação local de '+monthText(manifest.month)+' por este arquivo?'))continue;
      const stored=H.record(manifest);
      try{await H.put(f,manifest);session.delete(manifest.month);}
      catch{session.set(manifest.month,{blob:f,record:stored});}
    }
    await reload(true);
  }
  function showFiles(id){
    const files=selectedFiles[id],target=id==='baseFiles'?'baseList':'extraList';
    $(target).textContent=files.length?files.length+' arquivo(s): '+files.map(f=>f.name).join(' · '):id==='baseFiles'?'Nenhuma base selecionada.':'Nenhum complemento selecionado.';
    $(id==='baseFiles'?'clearBase':'clearExtra').hidden=!files.length;
  }
  async function runEvaluation(){
    const photo=$('photo').value,ref=$('reference').value;
    const marital=[...document.querySelectorAll('[name="civilTransition"]:checked')].map(el=>el.value);
    if(!photo||!ref||photo>ref||ref>R.today())throw Error('Informe a data da competência e uma referência entre a fotografia e hoje.');
    if(!selectedFiles.baseFiles.length)throw Error('Selecione pelo menos uma base principal XLSX.');
    const month=R.monthOf(photo),priorMonth=R.priorMonth(photo),oldEntry=catalog.has(month);
    if(oldEntry&&!confirm('Já existe uma avaliação de '+monthText(month)+'. Substituir pela nova execução?'))return;
    progress('Preparando arquivos locais…');await wait();
    let baseline=null;
    if(catalog.has(priorMonth)){
      progress('Abrindo competência anterior para comparação…');
      baseline=current&&loadedMonth===priorMonth?current:previous&&R.monthOf(previous.photo)===priorMonth?previous:(await readPeriod(priorMonth))?.run||null;
      if(!baseline)throw Error('O mês anterior foi localizado, mas não pôde ser lido. Confira o arquivo antes de processar.');
    }
    current=null;previous=null;selectedView=null;packed=null;retiredCount=0;movementView=null;marks=new Set();render();
    const imported=await IO.combine(selectedFiles.baseFiles,selectedFiles.extraFiles,p=>progress('Lendo '+p.file+' · '+num(p.rows)+' linhas',p.percent));
    progress('Preparando as regras de consistência…');
    const result=await R.validateAsync(imported.rows,baseline,{photo,ref,marital},p=>progress(p.phase+' · '+num(p.done)+' de '+num(p.total),Math.min(100,100*p.done/Math.max(1,p.total))));
    result.sources=imported.sources;result.extras=imported.extrasSources;result.enrichment=imported.enrichment;
    imported.rows.length=0;
    progress('Salvando avaliação mensal…',0);
    const encoded=await H.encode(result,n=>progress('Compactando avaliação mensal…',n));
    let savedLocal=false,savedFolder=false,writeError='';
    try{await H.put(encoded.blob,encoded.manifest);savedLocal=true;session.delete(month);}catch{session.set(month,{blob:encoded.blob,record:H.record(encoded.manifest)});}
    if(folder&&await permitted(folder,'readwrite')){
      try{await H.saveFile(folder,month,encoded.blob);savedFolder=true;}catch(e){writeError=e.message;}
    }
    if(!savedFolder)download(encoded.blob,H.filename(month));
    current=result;previous=baseline;packed=encoded.blob;loadedMonth=month;selectedSource=savedFolder?'Pasta vinculada':savedLocal?'Histórico local':'Sessão atual';
    filter={};movementMode='';page=1;$('search').value='';marks=new Set(((await H.prefs('treated:'+month).catch(()=>null))||[]).map(Q.upgradeMark));
    selectedFiles.baseFiles=[];selectedFiles.extraFiles=[];for(const id of ['baseFiles','extraFiles']){$(id).value='';showFiles(id);}
    await refreshCatalog();$('period').value=month;showStage('diagnostico');
    status('Avaliação concluída. '+(savedFolder?'Arquivo salvo na pasta vinculada.':'O download do arquivo .picdp foi solicitado.')+
      (savedLocal?' O Painel de BI já pode ler esta avaliação neste navegador.':' Se a sessão for encerrada, use o arquivo .picdp para reabrir a avaliação.')+
      (writeError?' Não foi possível gravar na pasta: '+writeError+'.':''));
  }
  function optionList(node,entries,selected){
    node.replaceChildren(new Option('Todos',''),...entries.map(([v,l])=>new Option(l,v)));
    if(selected&&!entries.some(([v])=>v===selected))node.append(new Option(selected,selected));
    node.value=selected||'';
  }
  function populationSummary(){
    if(!current||!previous)return null;
    if(!popCache||popCache.current!==current||popCache.previous!==previous)popCache=M.compare(current,previous);
    if(!popCache)return null;
    const grain=$('popGrain').value==='bindings'?'bindings':'people';
    const scope={plan:$('popPlan').value,sponsor:$('popSponsor').value,situation:$('popSituation').value};
    const labels=[['popPlan','Plano'],['popSponsor','Patrocinadora'],['popSituation','Situação de origem']];
    const scopeText=labels.flatMap(([id,label])=>{
      const node=$(id);return node.value?[label+': '+(node.selectedOptions?.[0]?.textContent||node.value)]:[];
    }).join(' · ')||'Todos os planos, patrocinadoras e situações de origem';
    const key=JSON.stringify([grain,scope,scopeText]);
    if(popSummaryCache?.comparison===popCache&&popSummaryCache.key===key)return popSummaryCache.value;
    const value={...M.summary(popCache,grain,scope),scopeText,previousPhoto:previous.photo};
    popSummaryCache={comparison:popCache,key,value};
    return value;
  }
  function movementTables(summary){
    const {total,byPlan,bySponsor,grain,legacy}=summary;
    const label=grain==='people'?'Pensionistas não localizados':'Vínculos de pensão não localizados';
    const values=r=>'<td>'+num(r.pensao)+'</td><td>'+(legacy?'—':num(r.ex))+'</td><td>'+num(r.apos)+'</td>';
    const table=(title,rows)=>'<section><h3>'+title+'</h3><div class="table-scroll"><table aria-label="'+title+'">'+
      '<thead><tr><th scope="col">'+title.replace('Por ','')+'</th><th scope="col">'+label+'</th><th scope="col">Ativos → Ex-Participantes</th><th scope="col">Ativos → Aposentados</th></tr></thead><tbody>'+
      (rows.map(r=>'<tr><th scope="row">'+esc(r.label)+'</th>'+values(r)+'</tr>').join('')||'<tr><td colspan="4">Nenhum desses movimentos no recorte.</td></tr>')+
      '</tbody><tfoot><tr><th scope="row">'+(grain==='people'?'Pessoas distintas':'Total de vínculos')+'</th>'+values(total)+'</tr></tfoot></table></div></section>';
    return '<h3>Resumo das transições</h3><p class="hint">As tabelas usam plano, patrocinadora e situação da fotografia anterior. '+
      (grain==='people'?'Uma pessoa pode aparecer em mais de uma categoria; por isso as linhas não devem ser somadas. ':'')+
      'O grupo Ativos inclui suas subsituações cadastradas. A ausência de pensionistas é só informativa, sem revisão nem saída confirmada.'+
      (legacy?' — indica que o histórico atual não permite verificar Ex-Participantes.':'')+'</p>'+
      '<div class="population-summary-grid">'+table('Por plano',byPlan)+table('Por patrocinadora',bySponsor)+'</div>';
  }
  function renderPopulation(){
    const card=$('populationCard');
    if(!current||!previous){
      popCache=null;popSummaryCache=null;
      $('popContext').textContent='Compare pessoas e vínculos entre fotografias.';
      $('popBody').hidden=true;
      $('popEmpty').textContent='Importe a fotografia do mês imediatamente anterior para consultar os movimentos.';
      $('popEmpty').hidden=false;
      return;
    }
    $('popContext').textContent=D(previous.photo)+' → '+D(current.photo)+' · Pessoas e vínculos';
    if(popCache&&(popCache.current!==current||popCache.previous!==previous)){popCache=null;popSummaryCache=null;}
    if(!card.open)return;
    if(!popCache)popCache=M.compare(current,previous);
    if(!popCache){$('popBody').hidden=true;return;}
    if(!popCache.controlsReady){
      popCache.controlsReady=true;
      popPage=1;
      for(const [id,key] of [['popPlan','plan'],['popSponsor','sponsor'],['popSituation','situation']]){
        optionList($(id),M.options(popCache,key),'');
      }
      optionList($('popKind'),[['review','Movimento a esclarecer'],...Object.entries(M.types).filter(([k])=>k!=='pensao')],'');
      $('popSearch').value='';
    }
    $('popEmpty').hidden=true;$('popBody').hidden=false;
    const summary=populationSummary(),grain=summary.grain,unit=grain==='people'?'pessoas':'vínculos';
    $('popSummary').innerHTML=movementTables(summary);
    const result=M.query(popCache,grain,{plan:$('popPlan').value,sponsor:$('popSponsor').value,situation:$('popSituation').value,
      kind:$('popKind').value,search:$('popSearch').value});
    const tile=(label,count)=>'<div><span>'+label+'</span><b>'+count+'</b></div>';
    $('popStats').innerHTML=tile('Público anterior → atual',num(result.prior)+' → '+num(result.current))+
      tile('Entradas observadas',num(result.counts.entrada))+tile('Saídas documentadas',summary.legacy?'—':num(result.counts.saida))+
      tile('Mudanças de situação',num(result.counts.situacao))+tile('A esclarecer',num(result.counts.review))+
      tile(grain==='people'?'Pensionistas não localizados':'Vínculos de pensão não localizados',num(summary.total.pensao));
    $('popNote').textContent='Unidade: '+unit+'. Os totais são calculados por fotografia. A lista mostra os demais movimentos que atendem ao recorte no mês anterior ou no atual. Busca e tipo de movimento filtram só a lista. “A esclarecer” pode se sobrepor aos demais indicadores. '+
      'Ausências não são correções. O PDF usa os mesmos filtros de origem nas tabelas de movimentos.'+
      (popCache.legacy?' O histórico atual foi gerado sem registros de Ex-Participante. Reprocesse a base original se precisar confirmar saídas.':'');
    const size=20,last=Math.max(1,Math.ceil(result.rows.length/size));popPage=Math.max(1,Math.min(popPage,last));
    const context=rows=>rows.length?rows.map(r=>{
      const profile=[r.situation,r.subgroup].filter(Boolean).filter((v,i,a)=>a.indexOf(v)===i).join(' · ');
      return '<li><b>'+esc(dash(r.plan))+'</b> · '+esc(dash(r.sponsor))+'<small>'+esc(dash(profile))+(r.sponsorMat?' · Matrícula patrocinadora: '+esc(r.sponsorMat):'')+'</small></li>';
    }).join(''):'<li>Não localizado</li>';
    const cells=rows=>rows.length>3?'<details><summary>'+num(rows.length)+' vínculos</summary><ul>'+context(rows)+'</ul></details>':'<ul>'+context(rows)+'</ul>';
    $('popRows').innerHTML=result.rows.slice((popPage-1)*size,popPage*size).map(e=>{
      const r=e.after[0]||e.before[0],marker=e.marker;
      const evidence=marker?'<small>Fonte: '+esc(dash(marker.src))+(marker.line?' · linha '+esc(marker.line):'')+
        (marker.planEnd?' · desligamento no plano: '+esc(D(marker.planEnd)):'')+'</small>':'';
      return '<tr><td><b>'+esc(dash(r.name))+'</b><small>Matrícula Petros: '+esc(r.mat)+'</small></td><td>'+cells(e.before)+'</td><td>'+cells(e.after)+'</td><td><strong>'+
        esc(M.types[e.kind])+'</strong>'+(e.review?'<span class="badge advisory">Movimento a esclarecer</span>':'')+'<small>'+esc(e.note)+'</small>'+evidence+'</td></tr>';
    }).join('')||'<tr><td colspan="4">Nenhum movimento no recorte selecionado.</td></tr>';
    $('popPage').textContent=num(result.rows.length)+' movimentos · página '+num(popPage)+' de '+num(last);
    $('popPrev').disabled=popPage<=1;$('popNext').disabled=popPage>=last;
  }
  function changeFilter(k,value){
    if(!current)return;
    if(k==='search')filter.person='';
    if(k==='rule'&&Object.hasOwn(R.families,value))expandedRules.add(value);
    filter[k]=value;
    if(k==='status'&&value==='Sem achado'){filter.rule='';filter.severity='';}
    if((k==='rule'||k==='severity')&&value&&filter.status==='Sem achado')filter.status='';
    if(k==='severity'&&value&&R.byCode[filter.rule]&&R.severity(current,filter.rule)!==value)filter.rule='';
    if(k==='rule'&&R.byCode[value]&&filter.severity!==R.severity(current,value))filter.severity='';
    if(Q.dims.includes(k)&&value){
      const options=Q.facets(current,{[k]:value});
      for(const other of ['group','subgroup','plan','sponsor']){
        if(k===other||!filter[other])continue;
        if(!options[other].includes(filter[other]))filter[other]='';
      }
    }
    movementMode='';page=1;render();
  }
  function bars(items,k,valueKey,unit,tone='azure'){
    if(!items.length)return '<p>Nenhum registro neste recorte.</p>';
    const max=items.reduce((m,r)=>Math.max(m,r[valueKey]),1);
    return '<div class="bar-list tone-'+tone+'">'+items.map(r=>{
      const label=r.title||(k==='plan'?CVCUtils.shortPlan(r.label):r.label),v=r[valueKey],pressed=filter[k]===r.label;
      const labelHtml='<span class="bar-label">'+esc(label)+'</span>',track='<span class="bar-track" aria-hidden="true"><span class="bar-fill" style="width:'+
        100*v/max+'%"></span></span>',count='<b>'+num(v)+'</b>';
      return '<button class="bar" type="button"'+(v?'':' disabled')+' data-chart-key="'+esc(k)+'" data-chart-value="'+esc(r.label)+'" aria-pressed="'+pressed+
        '" title="'+esc(label+': '+num(v)+' '+unit)+'">'+labelHtml+track+count+'</button>';
    }).join('')+'</div>';
  }
  function columns(items,k,tone){
    if(!items.length)return '<p>Nenhum registro neste recorte.</p>';
    const max=Math.max(...items.map(r=>r.affected),1);
    return '<div class="column-scroll"><div class="column-list column-'+k+' tone-'+tone+'" style="--column-count:'+items.length+'">'+items.map(r=>{
      const n=r.affected,label=esc(r.label),summary=esc(r.label+': '+num(n)+' pessoas com erro');
      const content='<span class="column-plot" aria-hidden="true">'+(n?'<span class="column-fill"></span>':'')+
        '<span class="column-value">'+num(n)+'</span></span><span class="column-label" aria-hidden="true">'+label+'</span>';
      const style=' style="--column-height:'+100*n/max+'%"';
      return n?'<button type="button" class="column-item" data-chart-key="'+k+'" data-chart-value="'+label+'" aria-pressed="'+(filter[k]===r.label)+
        '" aria-label="'+summary+'" title="'+summary+'"'+style+'>'+content+'</button>':
        '<div class="column-item column-zero"'+style+' title="'+summary+'">'+content+'<span class="sr">'+summary+'</span></div>';
    }).join('')+'</div></div>';
  }
  function graph(title,note,body,wide=false){
    return '<article class="graph card'+(wide?' wide':'')+'"><h3>'+esc(title)+'</h3><p>'+esc(note)+'</p>'+body+'</article>';
  }
  function showStage(name){
    if(mode!=='ops'||!Object.hasOwn(stages,name))return;
    stage=name;
    for(const el of document.querySelectorAll('[data-section]'))el.hidden=el.dataset.section!==stage;
    for(const el of document.querySelectorAll('[data-result-section]'))el.hidden=el.dataset.resultSection!==stage;
    for(const el of document.querySelectorAll('.rail [data-stage]'))el.setAttribute('aria-current',el.dataset.stage===stage?'step':'false');
    $('stageTitle').textContent=stages[stage][0];$('stageHint').textContent=stages[stage][1];
    render();window.scrollTo?.(0,0);
  }
  function syncExport(){
    if(mode!=='ops')return;
    $('exportCases').disabled=working||!selectedView?.cases.length;
    $('print').disabled=working||!selectedView;
    $('saveRun').disabled=working||!packed;
    if(selectedView&&current)$('exportScope').textContent='Fotografia '+D(current.photo)+' · '+num(selectedView.people)+' pessoas · '+num(selectedView.issues)+' ocorrências no recorte. O Excel e o relatório usam os filtros acima.';
  }
  function compare(v,forReport=false){
    const pv=previous?Q.view(previous,filter):null;
    const coverage=Boolean(previous&&current.prior&&previous.prior&&current.prior===previous.photo);
    const sameUnit=previous&&current.unit===previous.unit;
    const sameCivil=previous&&JSON.stringify(current.marital||[])===JSON.stringify(previous.marital||[]);
    const samePolicy=previous&&(current.contractRuleVersion||1)===(previous.contractRuleVersion||1);
    const sameCpfPolicy=previous&&(current.cpfRuleVersion||1)===(previous.cpfRuleVersion||1);
    const sameRevision=R.revised(current)===R.revised(previous),revisedCodes=new Set(['EDP01.1','EDP05','EDP07.1','EDP08']);
    const available=(run,code)=>Boolean(run&&(run.catalogVersion||1)>=R.byCode[code].since&&(!monthly.has(code)||run.prior));
    const comparable=code=>Boolean(available(current,code)&&available(previous,code)&&(coverage||!monthly.has(code))&&(sameUnit||code!=='EDP08')&&(sameCivil||code!=='EDP04')&&
      (samePolicy||!R.pensionSensitive.has(code))&&(sameCpfPolicy||!R.cpfShapeSensitive.has(code))&&(sameRevision||!revisedCodes.has(code)));
    const eventEntry=code=>Boolean(previous&&monthly.has(code)&&current.prior===previous.photo&&available(current,code));
    const counts=rows=>{
      const out=new Map();
      for(const {item} of rows){
        for(const code of [item.code,R.byCode[item.code].parent]){
          if(!code)continue;
          out.set(code,(out.get(code)||0)+1);
        }
      }
      return out;
    };
    const now=counts(v.cases),old=pv?counts(pv.cases):new Map();
    const movement=previous?Q.movement(current,{cases:v.cases.filter(c=>comparable(c.item.code)||eventEntry(c.item.code))},previous,{cases:pv.cases.filter(c=>comparable(c.item.code))}):null;
    if(!forReport)movementView=movement;
    const entered=movement?counts(movement.incoming):new Map();
    const exited=movement?counts(movement.outgoing):new Map();
    const label=previous?'Comparativo dos apontamentos':'Principais apontamentos';
    const active=R.rules.filter(r=>R.ruleMatches(r.code,filter.rule)&&(!filter.severity||filter.severity===R.severity(current,r.code)));
    const entries=catalogEntries(active,filter.rule);
    const notes=previous?[
      'Entradas e saídas referem-se aos apontamentos, não ao público. Nas regras mensais, cada mudança pertence ao intervalo em que foi detectada. Uma saída não comprova correção.',
      !coverage?'Mudanças detectadas podem aparecer como entradas mesmo sem resultado equivalente no mês anterior; nesse caso, não há saída nem variação comparável para a regra.':'',
      !sameRevision?'Primeiro nome, sobrenome, admissão e regras que usam a flag do INSS tiveram revisão de critério. Reprocesse as competências para comparar a variação desses códigos.':'',
      !samePolicy?'As regras de datas contratuais usam critérios diferentes para pensionistas entre as competências. Reprocesse a avaliação antiga para comparar esses códigos.':'',
      !sameCpfPolicy&&active.some(r=>R.cpfShapeSensitive.has(r.code))?'As competências usam critérios diferentes para CPF com hífen. Reprocesse a avaliação antiga para comparar EDP02.2 e EDP02.3.':'',
      !sameUnit?'O critério de unidade do TVP mudou.':'',
      !sameCivil?'O critério de estado civil mudou.':'',
      active.some(r=>((current.catalogVersion||1)>=r.since)!==((previous.catalogVersion||1)>=r.since))?'Algumas regras não estavam disponíveis na competência processada com o catálogo anterior.':'',
    ].filter(Boolean).join(' '):'Sem competência imediatamente anterior disponível para comparação.';
    const countButton=(code,n,movement='')=>n?'<button type="button" class="count-link'+(movement==='outgoing'?' flow-out':'')+'" data-rule-drill="'+code+'" data-flow="'+movement+
      '" title="Consultar '+(movement==='outgoing'?'saídas de ':movement==='incoming'?'entradas de ':'')+code+'">'+num(n)+' <span aria-hidden="true">'+(movement==='outgoing'?'↘':'↗')+'</span></button>':num(n);
    const deltaText=(a,b)=>{const d=b-a;return (d>0?'+':'')+num(d)+(a?' ('+(d>0?'+':'')+stylePeriod.format(d*100/a)+'%)':'');};
    let allComparable=Boolean(previous),anyEntry=false,currentTotal=0,priorTotal=0,enteredTotal=0,exitedTotal=0;
    const rows=entries.map(r=>{
      const children=r.family?active.filter(x=>x.parent===r.code):[r];
      const hasNow=children.some(x=>available(current,x.code)),hasPrior=children.some(x=>available(previous,x.code)),can=children.every(x=>comparable(x.code));
      const hasEntry=children.some(x=>comparable(x.code)||eventEntry(x.code));
      const a=old.get(r.code)||0,b=now.get(r.code)||0,en=entered.get(r.code)||0,ex=exited.get(r.code)||0;
      if(!r.family){currentTotal+=b;priorTotal+=a;enteredTotal+=en;exitedTotal+=ex;allComparable&&=can;anyEntry||=hasEntry;}
      const name=r.family?r.title:R.ruleTitle(current,r.code),alert=!r.family&&R.severity(current,r.code)==='Alerta';
      if(forReport)return [r.code,name+(alert?' (alerta)':''),...(previous?[hasPrior?num(a):'—']:[]),hasNow?num(b):'—',
        ...(previous?[hasEntry?num(en):'—',can?num(ex):'—',can?deltaText(a,b):'—']:[])];
      const rowId=code=>'compare-rule-'+code;
      const collapsible=r.parent&&(!filter.rule||filter.rule===r.parent);
      const attrs=r.family?' class="rule-family"':r.parent?' class="rule-child" id="'+rowId(r.code)+'"'+(collapsible&&!expandedRules.has(r.parent)?' hidden':''):'';
      const cells=r.family?'<td colspan="2" class="rule-group-cell"><button type="button" class="rule-disclosure" data-toggle-rule="'+r.code+
        '" aria-expanded="'+expandedRules.has(r.code)+'" aria-controls="'+children.map(x=>rowId(x.code)).join(' ')+'">'+
        '<span class="error-code">'+r.code+'</span><span class="rule-group-name">'+esc(name)+'</span>'+
        '<span class="rule-group-count">'+children.length+' '+(children.length===1?'subregra':'subregras')+'</span><span class="rule-chevron" aria-hidden="true"></span></button></td>':
        '<td><strong class="error-code">'+r.code+'</strong></td><td>'+esc(name)+(alert?' <span class="badge advisory">Alerta</span>':'')+'</td>';
      return '<tr'+attrs+'>'+cells+
        (previous?'<td class="numeric">'+(hasPrior?num(a):'—')+'</td>':'')+'<td class="numeric">'+(hasNow?countButton(r.code,b):'—')+'</td>'+
        (previous?'<td class="numeric">'+(hasEntry?countButton(r.code,en,'incoming'):'—')+'</td><td class="numeric">'+(can?countButton(r.code,ex,'outgoing'):'—')+'</td><td class="numeric '+(can?(b>a?'delta-up':b<a?'delta-down':''):'')+'">'+(can?deltaText(a,b):'—')+'</td>':'')+'</tr>';
    });
    const totalEntry=anyEntry?num(enteredTotal)+(allComparable?'':'*'):'—';
    const notice=notes+(anyEntry&&!allComparable?' * O total de entradas inclui apenas as regras com entradas apuradas.':'');
    if(forReport)return {label,notice,rows:[...rows,['Total','Ocorrências',...(previous?[num(priorTotal)]:[]),num(currentTotal),
      ...(previous?[totalEntry,allComparable?num(exitedTotal):'—',allComparable?deltaText(priorTotal,currentTotal):'—']:[])]],previousPhoto:previous?.photo||''};
    const toolbar=entries.some(r=>r.family)?'<div class="rule-table-actions" role="group" aria-label="Grupos de regras">'+
      '<button type="button" class="button secondary" data-rule-groups="open">Expandir todos</button>'+
      '<button type="button" class="button secondary" data-rule-groups="close">Recolher todos</button></div>':'';
    const body=toolbar+'<div class="table-scroll compare-table"><table><thead><tr><th class="rule-code-heading" scope="col">Código</th><th scope="col">Apontamento</th>'+
      (previous?'<th class="numeric">'+D(previous.photo)+'</th>':'')+'<th class="numeric">'+D(current.photo)+'</th>'+
      (previous?'<th class="numeric">Entradas</th><th class="numeric">Saídas</th><th class="numeric">Variação</th>':'')+'</tr></thead><tbody>'+rows.join('')+
      '</tbody><tfoot><tr><th colspan="2">Total de ocorrências</th>'+(previous?'<th class="numeric">'+num(priorTotal)+'</th>':'')+
      '<th class="numeric">'+num(currentTotal)+'</th>'+(previous?'<th class="numeric">'+totalEntry+'</th><th class="numeric">'+(allComparable?num(exitedTotal):'—')+
      '</th><th class="numeric">'+(allComparable?deltaText(priorTotal,currentTotal):'—')+'</th>':'')+'</tr></tfoot></table></div><p class="chart-foot">'+esc(notice)+' Selecione uma quantidade para consultar as evidências.</p>';
    return graph(label,'As colunas por data mostram ocorrências, não pessoas. Selecione o nome de um grupo para ver suas subregras.',body,true);
  }
  function render(){
    renderPopulation();
    const resultsVisible=mode==='bi'||['diagnostico','fila','exportacoes'].includes(stage);
    $('results').hidden=!current||!resultsVisible;$('empty').hidden=Boolean(current)||!resultsVisible;
    if(!current){$('scopeLine').textContent='';selectedView=null;syncExport();return;}
    if(!resultsVisible){$('scopeLine').textContent='Fotografia '+D(current.photo);return;}
    const v=Q.view(current,filter);selectedView=v;
    const facets=Q.facets(current,filter),rulesScope=filter.rule||filter.status?Q.view(current,{...filter,rule:'',status:''}):v;
    for(const c of controls){
      const k=c.dataset.filter;
      const entries=k==='rule'?catalogEntries(R.rules.filter(r=>rulesScope.byRule.has(r.code)||R.ruleMatches(r.code,filter.rule)&&filter.rule)).map(r=>[r.code,(r.parent?'↳ ':'')+r.code+' · '+(r.family?r.title:R.ruleTitle(current,r.code))]):
        k==='status'?['Com achado','Sem achado'].map(v=>[v,v==='Com achado'?'Com apontamento':'Sem apontamento']):
        k==='severity'?[['Erro','Erro'],['Alerta','Alerta']]: (facets[k]||[]).map(v=>[v,k==='plan'?CVCUtils.shortPlan(v):v]);
      optionList(c,entries,filter[k]);
    }
    $('scopeLine').textContent='Fotografia '+D(current.photo)+' · '+num(v.people)+' pessoas no recorte';
    syncExport();
    if(mode==='ops'&&stage==='fila'){renderCases();return;}
    if(mode==='ops'&&stage==='exportacoes')return;
    const percentage=v.people?stylePeriod.format(v.affectedError*100/v.people)+'% do público avaliado':'Sem pessoas no recorte';
    $('metrics').innerHTML=[
      ['Público avaliado',v.people,'Matrículas distintas'],
      ['Vínculos avaliados',v.bindings,'Linhas contratuais no recorte'],
      ['Participantes com erro',v.affectedError,percentage],
      ['Ocorrências de erro',v.errors,'Uma pessoa pode ter mais de uma ocorrência'],
      ['Alertas para revisão',v.alerts,num(v.affectedAlert)+' pessoas com alerta'],
      ['Pessoas com óbito',v.dead,'Data de óbito em ao menos um vínculo do recorte'],
    ].map(([label,count,note])=>'<article class="card metric"><span>'+label+'</span><strong>'+num(count)+'</strong><small>'+note+'</small></article>').join('');
    const segment=(key,title,tone='azure')=>graph(title,'Pessoas distintas em cada categoria.',bars(Q.segment(current,v,key).filter(x=>x.affected).slice(0,12),key,'affected','pessoas com erro',tone));
    const bySubgroup=Q.segment(current,v,'subgroup').filter(x=>x.affected).slice(0,12);
    const ageCounts=new Map(Q.segment(current,v,'band').map(x=>[x.label,x.affected]));
    const byAge=R.ageBands.some(b=>ageCounts.get(b)>0)?R.ageBands.map(label=>({label,affected:ageCounts.get(label)||0})):[];
    const ranking=Q.ranking(current,v).map(r=>({...r,label:r.key,title:r.title+' · '+r.label}));
    $('graphs').innerHTML='<div class="segment-grid segment-grid-compact">'+segment('plan','Participantes com erro por plano')+segment('sponsor','Participantes com erro por patrocinadora','indigo')+
      graph('Participantes com erro por situação','Pessoas distintas em cada categoria. Selecione uma coluna para filtrar.',columns(bySubgroup,'subgroup','rose'))+'</div>'+compare(v)+
      graph('Perfil etário dos participantes com erro','Idade na fotografia. Selecione uma faixa para filtrar.',
        columns(byAge,'band','azure'),true)+
      graph('Participantes com mais erros','Até 8 matrículas, por número de ocorrências no recorte. Selecione para abrir as evidências.',
        bars(ranking,'person','count','ocorrências de erro','rose'),true);
    const m=current.meta,compareNotes=R.monthlyCodes.map(code=>code+': '+num(m.compareCounts?.[code])+' pessoa(s) comparável(is)').join(' · ');
    $('runDetails').innerHTML='<p>Linhas lidas: '+num(m.readRows)+' · Duplicatas consolidadas: '+num(m.removed)+' · Sem matrícula: '+num(m.noKey)+'</p>'+
      '<p>Vínculos excluídos como ex-participante: '+num(m.excludedRows)+' · Situação não classificada: '+num(m.unclassified)+' · Isenção não classificada: '+num(m.unknownExempt)+'</p>'+
      '<p>'+(current.contractRuleVersion===R.contractRuleVersion?'Vínculos de pensionistas fora das regras de datas contratuais e TVP: '+num(m.pensionBindings)+'.':'Histórico calculado antes da exceção para pensionistas. Reprocesse a competência para atualizar os apontamentos.')+'</p>'+
      '<p>Vínculos sem dados suficientes para EDP08 (TVP): '+num(m.skippedTvp)+'. Registros com INSS '+(R.revised(current)?'S ou Sim':'S')+' não entram neste número.</p>'+
      '<p>'+esc(current.prior?'Comparação original: '+D(current.prior)+' · '+compareNotes:'Sem o mês imediatamente anterior na execução. Alterações mensais não avaliadas.')+'</p>'+
      (!R.revised(current)?'<p>Este histórico mantém os resultados do critério anterior para nome, admissão e INSS. Reprocesse a base original para aplicar as regras atuais.</p>':'')+
      ((current.cpfRuleVersion||1)<R.cpfRuleVersion?'<p>Esta competência foi processada antes do ajuste para CPF com hífen. Reprocesse a base original para atualizar os apontamentos.</p>':'')+
      (current.enrichment?'<p>Vínculos enriquecidos: '+num(current.enrichment.enriched)+' · Campos em conflito não aplicados: '+num(current.enrichment.conflicts)+'</p>':'')+
      '<p>'+esc((current.sources||[]).map(s=>s.name+' ('+num(s.total)+' linhas)').join(' · '))+'</p>';
    if(mode==='bi')renderCases();
  }
  function casesData(){
    if(movementMode==='outgoing'&&movementView&&previous)return {run:previous,list:movementView.outgoing};
    if(movementMode==='incoming'&&movementView)return {run:current,list:movementView.incoming};
    return {run:current,list:selectedView?.cases||[]};
  }
  function treated(run,item){return run===current&&marks.has(Q.evidenceKey(run,item));}
  function renderCases(){
    const {run,list}=casesData(),size=Number($('caseSize').value)||20,last=Math.max(1,Math.ceil(list.length/size));
    page=Math.min(page,last);
    $('casesTitle').textContent=movementMode==='incoming'?'Ocorrências que entraram':movementMode==='outgoing'?'Ocorrências que saíram':'Participantes e evidências';
    $('caseCount').textContent=num(list.length)+' ocorrência(s) · '+D(run.photo)+(movementMode?' · Use Limpar filtros para voltar à lista completa.':'');
    $('caseRows').innerHTML=list.length?list.slice((page-1)*size,page*size).map(({item,id},i)=>{
      const r=run.rows[id],title=R.ruleTitle(run,item.code),alert=R.severity(run,item.code)==='Alerta',isTreated=treated(run,item),n=(page-1)*size+i;
      const age=personAge(r,run);
      return '<tr><td><b>'+esc(dash(r.name))+'</b><small>Matrícula Petros: '+esc(r.mat)+(age==null?'':' · '+age+' anos')+'</small></td><td title="'+esc(dash(r.plan))+'">'+
        esc(CVCUtils.shortPlan(dash(r.plan)))+'<small>'+esc(r.subgroup)+' · '+esc(dash(r.sponsor))+'</small></td><td><strong class="error-code">'+item.code+
        '</strong> '+esc(title)+(alert?' <span class="badge advisory">Alerta</span>':'')+'<small>'+esc(R.labels[item.field])+(item.code==='EDP01.4'?' · Alteração no estado civil: '+esc(item.facts?.civilChange||'Não foi possível comparar'):'')+'</small></td><td><span class="badge'+(isTreated?'':' pending')+'">'+(isTreated?'Tratado':'Pendente')+
        '</span></td><td><button class="button secondary" type="button" data-case="'+n+'">Detalhes ↗</button></td></tr>';
    }).join(''):'<tr><td colspan="5">Nenhum apontamento neste recorte.</td></tr>';
    $('pageLabel').textContent='Página '+page+' de '+last;
    $('prevPage').disabled=page===1;$('nextPage').disabled=page===last;
  }
  function openDetail(index,trigger){
    const {run,list}=casesData(),c=list[index];if(!c)return;
    detailCase={run,...c};detailTrigger=trigger;detailRender();
    $('detail').showModal();
  }
  function personAge(r,run){return r.invalidDates?.includes('birth')?null:R.age(r.birth,run.photo);}
  function explanation(item,r,run){
    if(item.code==='EDP01.4'||item.code==='EDP01.1'&&R.revised(run)){
      const part=item.code==='EDP01.4'?'O sobrenome':'O primeiro nome';
      return part+' mudou de '+(item.before||'não informado')+' para '+(item.after||'não informado')+' entre '+D(run.prior)+' e '+D(run.photo)+'.';
    }
    if(item.code==='EDP07.8')return 'A data de nascimento mudou de '+D(item.before)+' para '+D(item.after)+' entre as fotografias de '+D(run.prior)+' e '+D(run.photo)+'. Confira a origem antes de corrigir.';
    if(item.code==='EDP08'&&item.before&&item.after){
      const duration=s=>{const n=R.durationMonths(s);return n===null?s:R.durationText(n);};
      return 'O tempo de empresa apurado na patrocinadora é de '+duration(item.before)+' e o TVP cadastrado é de '+duration(item.after)+'. A apuração usa a data de admissão'+
        (r.admission?' de '+D(r.admission):'')+' até '+D(run.ref)+'.';
    }
    const title=R.labels[item.field];
    if(item.code==='EDP07.2')return title+': '+item.after+' é posterior à referência da avaliação ('+D(run.ref)+').';
    if(item.code==='EDP07.3')return title+': '+item.after+' é anterior à data de nascimento ('+item.before+').';
    if(item.code==='EDP07.4')return 'Não foi possível interpretar o valor '+item.after+' no campo '+title+'. Confira a data no arquivo de origem.';
    if(monthly.has(item.code)&&item.before&&item.after)
      return title+' passou de '+item.before+' para '+item.after+', entre a fotografia anterior de '+D(run.prior)+' e a fotografia atual de '+D(run.photo)+'.'+(item.code==='EDP04'?' O retorno para Solteiro(a) exige conferência.':'');
    return item.detail;
  }
  function detailRender(){
    const {run,item,id}=detailCase,r=run.rows[id],source=run.rows[item.id],rule=R.byCode[item.code];
    $('detailTitle').textContent=rule.code+' · '+R.ruleTitle(run,rule.code);
    const age=personAge(r,run),status=R.norm(r.benefitStatus),sex=R.norm(r.sex);
    const list=(items)=>'<dl class="evidence-info">'+items.map(([k,v])=>'<div><dt>'+esc(k)+'</dt><dd>'+esc(dash(v))+'</dd></div>').join('')+'</dl>';
    const identity=[['Nascimento',D(r.birth)],['Sexo',sex==='F'?'Feminino':sex==='M'?'Masculino':r.sex],['Estado civil',r.civil]];
    const binding=[['Plano',r.plan],['Patrocinadora',r.sponsor],['Matrícula na patrocinadora',r.sponsorMat],['Situação contratual',r.group],['Subsituação contratual',r.subgroup],['Benefício',r.benefit],
      ['Situação do benefício',status==='AT'?'Ativo (AT)':status==='SU'?'Suspenso (SU)':r.benefitStatus],['INSS',r.inss],['Isenção de IR',r.exempt]];
    if(r.subgroup!=='Pensionista')binding.push(['Admissão na patrocinadora',D(r.admission)],['Inscrição no plano',D(r.enrollment)]);
    $('detailContent').innerHTML='<div class="person-profile"><div><strong>'+esc(dash(r.name))+'</strong><span>Matrícula Petros: '+esc(r.mat)+(age==null?'':' · '+age+' anos na fotografia')+
      '</span></div>'+(r.dead?'<span class="badge pending">Óbito registrado em '+esc(D(r.death))+'</span>':'')+'</div>'+
      '<article class="issue-card"><div><b>'+(R.severity(run,rule.code)==='Alerta'?'Alerta para revisão':'O que foi identificado')+'</b><span class="badge'+(treated(run,item)?'':' pending')+'">'+(treated(run,item)?'Tratado':'Pendente')+'</span></div>'+
      '<p>'+esc(explanation(item,source,run))+'</p><small>Campo: '+esc(R.labels[item.field])+'</small></article>'+
      '<h3>Valores da verificação</h3>'+list(R.evidence(run,item).map(([label,value,kind])=>[label,kind==='date'?D(value):value]))+
      '<h3>Perfil cadastral</h3>'+list(identity)+'<h3>Vínculo contratual</h3>'+list(binding)+
      '<details class="source-detail"><summary>Origem da evidência</summary>'+list([['Fotografia',D(run.photo)],['Fonte',source.src],['Linha',source.line]])+'</details>';
    if($('markCase')){$('markCase').hidden=run!==current;$('markCase').textContent=treated(run,item)?'Reabrir apontamento':'Marcar como tratado';}
  }
  async function markCase(){
    if(!detailCase||mode==='bi'||detailCase.run!==current)return;
    const k=Q.evidenceKey(current,detailCase.item);
    if(marks.has(k))marks.delete(k);else marks.add(k);
    await H.prefs('treated:'+loadedMonth,[...marks]).catch(()=>status('A marcação ficou apenas nesta sessão.',true));
    detailRender();renderCases();
  }
  async function exportCases(){
    const run=current,list=selectedView?.cases||[];
    if(!list.length)throw Error('Não há evidências para exportar neste recorte.');
    const excelDate=v=>/^\d{4}-\d{2}-\d{2}$/.test(v||'')&&R.date(v).iso===v?(v<'1900-01-01'?D(v):new Date(v+'T00:00:00Z')):v;
    const created=new Date().toLocaleString('pt-BR',{timeZone:'America/Sao_Paulo'}),scope='Recorte selecionado · '+num(selectedView.people)+' pessoas · '+num(list.length)+' ocorrências. CPF mascarado nas evidências.';
    const headers=['Matrícula Petros','Nome','Plano','Patrocinadora','Situação','Subsituação','Data de Óbito','Data de Nascimento','Idade na fotografia','Código','Tipo','Apontamento','Campo'];
    const tail=['Evidência','Origem','Linha','Tratamento'];
    const grouped=new Map();
    for(const c of list){const code=c.item.code;if(!grouped.has(code))grouped.set(code,[]);grouped.get(code).push(c);}
    function* rows(group,extra){
      yield [...headers,...extra,...tail];
      for(const {item,id} of group){
        const r=run.rows[id],s=run.rows[item.id],rule=R.byCode[item.code];
        const values=R.evidence(run,item).map(([,v,kind])=>kind==='date'?excelDate(v):v);
        yield [r.mat,r.name,r.plan,r.sponsor,r.group,r.subgroup,excelDate(r.death),excelDate(r.birth),personAge(r,run),
          rule.code,R.severity(run,rule.code),R.ruleTitle(run,rule.code),R.labels[item.field],...values,explanation(item,s,run),s.src,s.line,treated(run,item)?'Tratado':'Pendente'];
      }
    }
    const tables={Resumo:[['Código','Apontamento ou assunto','Tipo','Pessoas distintas','Ocorrências','Pendentes']]};
    const meta=title=>({title,studyDate:excelDate(run.photo),generatedAt:created,scope});
    const sheetMeta={Resumo:{...meta('PIC · Apontamentos de Dados Pessoais'),widths:[25,72,17,21,16,16]}};
    let totalPending=0;
    for(const rule of catalogEntries(R.rules.filter(r=>grouped.has(r.code)))){
      if(rule.family){
        const people=new Set();let occurrences=0,pending=0;
        for(const child of R.rules.filter(r=>r.parent===rule.code))for(const c of grouped.get(child.code)||[]){
          occurrences++;people.add(run.rows[c.id].key);if(!treated(run,c.item))pending++;
        }
        tables.Resumo.push([rule.code,rule.title,'Subtotal',people.size,occurrences,pending]);
        continue;
      }
      const group=grouped.get(rule.code);if(!group)continue;
      const pending=group.reduce((n,c)=>n+(treated(run,c.item)?0:1),0);totalPending+=pending;
      const title=R.ruleTitle(run,rule.code);
      tables.Resumo.push([rule.code,title,R.severity(run,rule.code),new Set(group.map(c=>run.rows[c.id].key)).size,group.length,pending]);
      const extra=R.evidence(run,group[0].item).map(([h])=>h),n=headers.length;
      tables[rule.code]=rows(group,extra);
      const extraWidths=extra.map(h=>/Valores diferentes/.test(h)?75:/Nome|CPF|Isenção|benefício|original|Estado civil/i.test(h)?35:24);
      sheetMeta[rule.code]={...meta(rule.code+' · '+title),widths:[24,40,34,34,18,24,17,19,19,13,12,48,28,...extraWidths,78,52,10,14],
        headerHeight:32,rowHeight:36,wrap:[1,2,3,11,12,...extra.map((_,i)=>n+i),n+extra.length,n+extra.length+1]};
    }
    tables.Resumo.push(['Total','Pessoas distintas com apontamentos (sem somar subtotais)','Todos',selectedView.affected,list.length,totalPending]);
    progress('Preparando a planilha de erros…');await wait();
    const workbook=await ComExport.workbook(tables,p=>progress(p.phase+(p.detail?' · '+p.detail:''),p.percent??null),{variant:'batch',sheetMeta});
    download(workbook,'PIC_Erros_Dados_Pessoais_'+R.monthOf(run.photo)+'.xlsx');
  }
  async function exportReport(){
    if(!current||!selectedView)return;
    const run=current,v=selectedView,dimensions={group:'Situação',subgroup:'Subsituação',plan:'Plano',sponsor:'Patrocinadora',dead:'Óbito',
      band:'Faixa etária',benefitStatus:'Situação do benefício',inss:'INSS',exemption:'Isenção de IR',rule:'Código',status:'Resultado',severity:'Tipo de apontamento'};
    const applied=Object.entries(filter).filter(([key,value])=>value&&dimensions[key]).map(([key,value])=>dimensions[key]+': '+value);
    if(filter.search||filter.person)applied.push('Pesquisa por participante');
    const scope=applied.length?applied.join(' · '):'Todos os vínculos elegíveis da competência';
    progress('Preparando relatório gerencial…');
    const comparison=compare(v,true);
    await wait();
    const segment=k=>Q.segment(run,v,k).filter(x=>x.affected).slice(0,7).map(x=>[k==='plan'?CVCUtils.shortPlan(x.label):x.label,x.affected]);
    const bands=new Map(Q.segment(run,v,'band').map(x=>[x.label,x.affected]));
    const blob=PicPessoalReport.generate({photo:run.photo,reference:run.ref,scope,comparison,population:populationSummary(),
      metrics:[['Público avaliado',v.people],['Participantes com erro',v.affectedError],['Ocorrências de erro',v.errors],['Alertas para revisão',v.alerts]],
      charts:[['Por plano',segment('plan')],['Por patrocinadora',segment('sponsor')],['Por situação',segment('subgroup')],['Por faixa etária',R.ageBands.filter(b=>bands.get(b)>0).map(b=>[b,bands.get(b)])]],
      legacy:run.contractRuleVersion!==R.contractRuleVersion});
    download(blob,'PIC_Relatorio_Dados_Pessoais_'+R.monthOf(run.photo)+'.pdf');
  }
  function showCases(){
    if(mode==='ops')showStage('fila');
    setCasesExpanded(true);
    renderCases();
    $('cases').scrollIntoView({block:'start'});
  }
  function setCasesExpanded(open){
    $('caseBody').hidden=!open;
    $('toggleCases').setAttribute('aria-expanded',String(open));
    $('toggleCases').textContent=open?'− Recolher':'+ Expandir';
  }
  function setRuleExpanded(el,open){
    const code=el.dataset.toggleRule;
    if(open)expandedRules.add(code);else expandedRules.delete(code);
    el.setAttribute('aria-expanded',String(open));
    for(const id of el.getAttribute('aria-controls').split(' ')){const row=$(id);if(row)row.hidden=!open;}
  }
  function wire(){
    if(mode==='ops'){
    $('reference').value=R.today();$('photo').max=R.today();$('reference').max=R.today();
    const catalogLine=r=>'<div class="rule-catalog-line"><b class="error-code">'+r.code+'</b><div>'+esc(r.title)+'<small>'+esc(r.grain)+' · '+r.severity+'</small></div></div>';
    const catalogRows=catalogEntries(R.rules);
    $('ruleCatalog').innerHTML='<div class="rule-group rules-list">'+catalogRows.filter(r=>!r.parent).map(r=>{
      if(!r.family)return catalogLine(r);
      const children=catalogRows.filter(x=>x.parent===r.code);
      return '<details class="rule-family"><summary class="rule-disclosure"><span class="error-code">'+r.code+'</span><span class="rule-group-name">'+esc(r.title)+
        '</span><span class="rule-group-count">'+children.length+' subregras</span><span class="rule-chevron" aria-hidden="true"></span></summary>'+
        '<div class="rule-catalog-children">'+children.map(catalogLine).join('')+'</div></details>';
    }).join('')+'</div>'+
      '<p>EDP01.3 é um alerta, não confirma sexo. Usa uma amostra local de primeiros nomes frequentes com predominância de ao menos 99% nas contagens publicadas do Censo 2010 (IBGE). Nomes fora da amostra não geram alerta. Nenhum dado cadastral é enviado ao IBGE.</p>'+
      '<p>EDP02.2 valida os dígitos verificadores, sem consultar a situação do CPF na Receita Federal. CPF não preenchido não é avaliado nessas verificações.</p>';
    $('photo').addEventListener('change',updatePriorHint);
    for(const id of ['baseFiles','extraFiles']){
      $(id).addEventListener('change',()=>{
        for(const f of $(id).files||[])if(!selectedFiles[id].some(p=>p.name===f.name&&p.size===f.size&&p.lastModified===f.lastModified))selectedFiles[id].push(f);
        $(id).value='';showFiles(id);
      });
      $(id==='baseFiles'?'clearBase':'clearExtra').addEventListener('click',()=>{selectedFiles[id]=[];showFiles(id);});
    }
    for(const el of document.querySelectorAll('[data-stage]'))el.addEventListener('click',()=>showStage(el.dataset.stage));
    $('run').addEventListener('click',()=>task(runEvaluation));
    $('saveRun').addEventListener('click',()=>task(async()=>{
      if(!packed||!loadedMonth)return;
      let blob=packed;
      if(retiredCount){progress('Preparando cópia do histórico…');blob=(await H.encode(current,p=>progress('Preparando cópia do histórico…',p))).blob;}
      download(blob,H.filename(loadedMonth));
    }));
    $('print').addEventListener('click',()=>task(exportReport));
    $('exportCases').addEventListener('click',()=>task(exportCases));
    $('markCase').addEventListener('click',markCase);
    }
    $('theme').addEventListener('click',()=>{const dark=document.body.classList.toggle('dark');$('theme').setAttribute('aria-pressed',String(dark));try{localStorage.setItem('pic.dp.theme',dark?'dark':'light');}catch{}});
    try{if(localStorage.getItem('pic.dp.theme')==='dark'){$('theme').setAttribute('aria-pressed','true');document.body.classList.add('dark');}}catch{}
    $('linkDirectory').addEventListener('click',()=>task(connectFolder));
    $('refreshHistory').addEventListener('click',()=>task(()=>reload(true)));
    $('historyFiles').addEventListener('change',()=>{const files=Array.from($('historyFiles').files||[]);$('historyFiles').value='';if(files.length)task(()=>importHistory(files));});
    const showHistory=()=>{$('historyFeedback').hidden=true;$('historyDialog').showModal();};
    $('openHistory').addEventListener('click',showHistory);
    for(const el of document.querySelectorAll('[data-open-history]'))el.addEventListener('click',showHistory);
    $('historyClose').addEventListener('click',()=>$('historyDialog').close());
    $('period').addEventListener('change',()=>task(()=>loadMonth($('period').value)));
    $('populationCard').addEventListener('toggle',renderPopulation);
    for(const id of ['popGrain','popPlan','popSponsor','popSituation','popKind'])$(id).addEventListener('change',()=>{popPage=1;renderPopulation();});
    $('popSearch').addEventListener('input',()=>{clearTimeout(popTimer);popTimer=setTimeout(()=>{popPage=1;renderPopulation();},180);});
    $('popPrev').addEventListener('click',()=>{popPage--;renderPopulation();});
    $('popNext').addEventListener('click',()=>{popPage++;renderPopulation();});
    $('reset').addEventListener('click',()=>{filter={};$('search').value='';movementMode='';page=1;render();});
    $('collapse').addEventListener('click',()=>{const open=$('filterBody').hidden;$('filterBody').hidden=!open;$('collapse').setAttribute('aria-expanded',String(open));$('collapse').textContent=open?'− Recolher':'+ Expandir';});
    let debounce=0;$('search').addEventListener('input',()=>{clearTimeout(debounce);debounce=setTimeout(()=>changeFilter('search',$('search').value),180);});
    for(const c of controls)c.addEventListener('change',()=>changeFilter(c.dataset.filter,c.value));
    $('graphs').addEventListener('click',e=>{
      const el=e.target.closest('button');if(!el)return;
      if(el.dataset.ruleGroups){
        for(const control of $('graphs').querySelectorAll('[data-toggle-rule]'))setRuleExpanded(control,el.dataset.ruleGroups==='open');
        return;
      }
      if(el.dataset.toggleRule){
        setRuleExpanded(el,!expandedRules.has(el.dataset.toggleRule));
        return;
      }
      if(el.dataset.ruleDrill){
        const {ruleDrill,flow}=el.dataset;
        changeFilter('rule',ruleDrill);movementMode=flow;page=1;showCases();return;
      }
      if(el.dataset.chartKey){
        const key=el.dataset.chartKey,v=el.dataset.chartValue;
        if(key==='person'){filter.search='';$('search').value=filter.person===v?'':v;changeFilter(key,filter.person===v?'':v);showCases();}
        else changeFilter(key,filter[key]===v?'':v);
      }
    });
    $('toggleCases').addEventListener('click',()=>setCasesExpanded($('caseBody').hidden));
    setCasesExpanded(mode==='ops');
    $('caseSize').addEventListener('change',()=>{page=1;renderCases();});
    $('prevPage').addEventListener('click',()=>{page--;renderCases();});
    $('nextPage').addEventListener('click',()=>{page++;renderCases();});
    $('caseRows').addEventListener('click',e=>{const b=e.target.closest('[data-case]');if(b)openDetail(Number(b.dataset.case),b);});
    $('detailClose').addEventListener('click',()=>$('detail').close());
    $('detail').addEventListener('close',()=>{detailTrigger?.focus();detailTrigger=null;detailCase=null;});
    if(mode==='ops')showStage('preparar');else render();
    task(async()=>{folder=await H.prefs('folder').catch(()=>null);await reload(true);});
  }
  wire();
})();
