# PIC · Dados Pessoais

Abra pelo Portal PIC, em **Aplicações → Dados Pessoais**, e escolha **Área Operacional** ou **Painel de BI**. São páginas separadas: a operação prepara, valida, trata e exporta; o painel consulta os indicadores e as evidências. Os dois ambientes rodam localmente e leem o histórico deste módulo. O histórico de Meios de Comunicação continua separado.

## Rotina mensal

1. Na Área Operacional, informe a **Data da competência** correspondente à fotografia. A **Referência das regras** começa no dia atual e pode ser ajustada para repetir uma avaliação antiga. Ela precisa estar entre a fotografia e hoje. A referência usada fica gravada no arquivo.
2. Adicione um ou mais XLSX com o layout principal. Você pode adicionar arquivos de outras pastas em seleções sucessivas. O reconhecimento ocorre pelo cabeçalho, não pelo nome do arquivo nem pela ordem das colunas. As abas com o cabeçalho reconhecido são importadas; uma duplicata idêntica é contabilizada na importação e consolidada, sem eliminar vínculos diferentes.
3. Confira o **TVP Atual**. A aplicação converte o valor numérico da base em anos e meses. Por exemplo, 420 aparece como 35 anos. A comparação usa meses completos desde a admissão e também aceita a duração informada como texto em anos e meses.
4. Clique em **Processar avaliação**. O módulo guarda a competência no navegador e gera um arquivo `PIC_Dados_Pessoais_AAAA-MM.picdp`. Se uma pasta com permissão de escrita estiver vinculada, o arquivo é gravado nela. Caso contrário, a aplicação solicita o download. Uma reexecução no mesmo mês pede confirmação antes de substituir o resultado mensal.
5. Abra o **Painel de BI**. Ele procura a última competência no histórico local e, se houver uma pasta vinculada com acesso concedido, procura também os arquivos nessa pasta. Use **Atualizar** para conferir o conteúdo da pasta. Se o navegador não permitir vínculo de pasta, ou se a permissão expirar, use **Importar .picdp**. Para comparar a primeira avaliação, processe antes a competência anterior. Se importar esse mês posteriormente, reprocesse a competência atual para aplicar as regras mensais.

Mantenha os `.picdp` em pasta de acesso restrito: são arquivos compactados, não criptografados, e contêm dados cadastrais necessários à comparação. O ZIP de entrega não contém a planilha fictícia fornecida nem avaliações salvas.

## O que entra na avaliação

- A **matrícula Petros** identifica uma pessoa. Nome, CPF, sexo, estado civil e nascimento são comparados com o **mês calendário imediatamente anterior**, quando há um único valor comparável de cada lado. Ausência de base anterior ou valores ambíguos não equivalem a “sem alteração”.
- O restante é avaliado **no vínculo da própria linha**. A matrícula pode aparecer em mais de um plano ou patrocinadora. Nos gráficos de pessoas, a mesma matrícula é contada uma vez dentro de cada categoria; os totais das categorias podem se sobrepor.
- Vínculos **Ex-Participante** ficam fora dos indicadores, das regras e do arquivo de evidências. Se a matrícula também tiver vínculo elegível, só esse vínculo entra no estudo. A situação **Ex-Aguardando Deferimento** permanece em Ativos, conforme a classificação de Meios de Comunicação.
- Assistidos com tipo de benefício que contém `PENS` são Pensionistas; os demais são Aposentados. Aposentados e pensionistas com óbito permanecem no universo para permitir a regra de benefício ativo. O filtro de óbito considera a data registrada no vínculo selecionado.
- Vínculos de **pensionistas** não são avaliados em TVP nem em datas de admissão, inscrição, atualização do TVP ou desligamento na patrocinadora e no plano. Nascimento, óbito e situação do benefício continuam sendo avaliados. Se a mesma matrícula tiver outro vínculo elegível que não seja de pensão, as regras contratuais continuam valendo naquele vínculo.
- Complementos opcionais usam **Matrícula Petros** e podem preencher lacunas de nome, CPF, sexo, estado civil, nascimento ou óbito. Não adicionam matrículas ao universo, não sobrescrevem a fonte principal e não aplicam valores complementares conflitantes.

## Regras

| Código | Apontamento | Unidade |
|---|---|---|
| **EDP01** | **Erros relacionados a Nome** | Assunto |
| EDP01.1 | Alteração do primeiro nome | Pessoa · Erro |
| EDP01.2 | Primeiro nome com menos de duas letras | Pessoa |
| EDP01.3 | Possível divergência entre nome e sexo cadastrado | Pessoa · Alerta |
| EDP01.4 | Alteração de sobrenome | Pessoa · Alerta |
| **EDP02** | **Inconsistências relacionadas ao CPF** | Assunto |
| EDP02.1 | Alteração de CPF | Pessoa |
| EDP02.2 | CPF com dígitos verificadores inválidos | Pessoa |
| EDP02.3 | CPF sem 11 dígitos ou com formato inválido | Pessoa |
| EDP02.4 | CPF vinculado a mais de uma matrícula Petros | Pessoa |
| EDP03 | Alteração de gênero de um mês para o outro | Pessoa |
| EDP04 | Transição de estado civil incompatível | Pessoa |
| EDP05 | Isenção de IR sem confirmação de aposentadoria no INSS | Vínculo |
| EDP06 | Benefício ativo com óbito cadastrado | Vínculo |
| **EDP07** | **Alteração de datas** | Assunto |
| EDP07.1 | Data de Admissão posterior à inscrição no Plano | Vínculo · Alerta |
| EDP07.2 | Qualquer data futura | Vínculo e campo |
| EDP07.3 | Data anterior ao nascimento | Vínculo e campo |
| EDP07.4 | Data informada em formato inválido | Vínculo e campo |
| EDP07.5 | Idade acima de 100 anos na fotografia | Vínculo |
| EDP07.6 | Idade inferior a 16 anos na fotografia | Vínculo · exceto pensão |
| EDP07.7 | Admissão antes dos 16 anos | Vínculo · exceto pensão |
| EDP07.8 | Alteração da data de nascimento | Pessoa |
| EDP08 | TVP Atual inferior ao tempo de empresa | Vínculo |
| EDP09 | Campo obrigatório não preenchido | Pessoa e campo |

- **EDP01.1 e EDP01.4:** o primeiro termo é o primeiro nome; os termos restantes são avaliados juntos como sobrenome, inclusive nomes compostos após o primeiro termo. Maiúsculas, acentos e espaços repetidos não geram alterações. A evidência de sobrenome inclui o estado civil anterior e o atual e informa se mudou. Se estiver ausente ou ambíguo, informa que não foi possível comparar.
- **EDP01.3** é uma triagem, não uma determinação do sexo. A amostra local usa primeiros nomes frequentes do [Censo 2010 do IBGE](https://www.ibge.gov.br/censo2010/nomes), com frequência publicada para ambos os sexos, ao menos mil registros somados e pelo menos 99% de predominância nas contagens publicadas. Não sinaliza nome fora da amostra nem quando nome ou sexo está ausente ou ambíguo. Não faz consultas externas durante o uso.
- **EDP02.2–EDP02.3** aceitam 11 dígitos sem pontuação, somente o hífen antes dos dois dígitos verificadores (formato `000000000-00`) ou a máscara completa (formato `000.000.000-00`). O hífen não é contado como dígito. O teste de módulo 11 é aplicado aos formatos aceitos e também rejeita dígitos repetidos. Não confirma titularidade nem situação na Receita. CPF vazio não entra nessas duas regras, e o Excel mantém a máscara de privacidade.
- Competências salvas antes desse ajuste mantêm os apontamentos originais. Para atualizar os resultados antigos e comparar a variação de EDP02.2 e EDP02.3, reprocesse a base original.
- **EDP03** compara o campo de sexo cadastrado entre as fotografias. **EDP04** sinaliza retorno de Casado, Viúvo, Separado/Desquitado ou Divorciado para Solteiro. **EDP05** reconhece `S` e `SIM` como confirmação de aposentadoria no INSS. **EDP06** considera benefício `AT`; `SU` não é apontado. **EDP08** não se aplica a pensionistas nem a registros com INSS `S` ou `SIM` e não presume zero quando o TVP está ausente.
- Nas regras de idade, a data da fotografia é usada em EDP07.5 e EDP07.6; a data de admissão é usada em EDP07.7. Admissão anterior ao nascimento aparece apenas em EDP07.3 para evitar redundância. Não são inferidas regras para datas não preenchidas.
- **EDP09** verifica CPF, nome, nascimento, sexo e estado civil. Emite um apontamento por matrícula e campo, com o total de vínculos elegíveis afetados. A regra verifica os dados após a aplicação dos complementos. Valor presente em formato inválido não é falta de preenchimento. A regra era exibida como EDP15 até a versão 1.11.1; arquivos históricos mantêm essa identificação interna para compatibilidade. O EDP09 dos históricos mais antigos continua sendo interpretado como EDP07.2 (data futura).

No Painel de Indicadores e em **Universo e erros**, selecione o nome de um grupo para abrir ou recolher suas subregras. Use **Expandir todos** e **Recolher todos** para mudar a visualização da tabela inteira. As quantidades consultam as evidências e contam **ocorrências**, não pessoas. Uma mudança detectada entre dois meses é uma entrada no mês em que foi apurada, mesmo quando a avaliação anterior não tinha uma comparação equivalente. Nesse caso, a saída e a variação não são exibidas para a regra. Nas regras recorrentes, o comparativo considera matrícula, código, campo e vínculo quando aplicável. A saída do recorte não confirma tratamento. O perfil etário separa 90–99 de 100 anos ou mais, sem sobreposição.

Em **Fila de tratamento**, selecione **Detalhes** para ler a explicação e os dados cadastrais do vínculo. A marcação de tratamento é local ao navegador e não apaga a evidência. Históricos anteriores mantêm seus resultados; reprocesse as bases para aplicar o novo critério de nome, admissão e INSS e comparar essas regras entre os meses.

Desde a versão 1.11.1, o EDP13 não é gerado nem incluído nas telas, nos indicadores ou nas exportações. O histórico anterior continua abrindo, sem reprocessar. A cópia baixada pela versão atual não inclui esses apontamentos; o arquivo original permanece intacto.

Em **Relatórios e evidências**, o PDF e o Excel têm botões separados e respeitam os filtros. O Excel tem subtotais por assunto no resumo e uma aba por subregra com ocorrências, independente da paginação. Cada aba inclui colunas para os dados efetivamente comparados: por exemplo, Tipo de Isenção e Flag INSS, ou a data de admissão e a data de inscrição. O ranking de erros não inclui alertas.

Arquivos antigos continuam abrindo: os apontamentos já registrados são remapeados para os novos códigos, sem reprocessar dados. Para calcular as novas regras ou aplicar a exceção de pensionistas a um mês já salvo, reprocesse a base original. A comparação de regras afetadas fica indisponível entre competências processadas com critérios diferentes.

## Movimentos do público cadastral

Abra **Movimentos do público cadastral** no Painel de BI ou na etapa **Universo e erros**. Alterne entre pessoas e vínculos e filtre por plano, patrocinadora, situação de origem, tipo de movimento ou matrícula/nome. Os totais do público refletem cada fotografia separadamente; a lista inclui movimentos que passam pelo filtro em qualquer uma das duas fotografias. **A esclarecer** pode se sobrepor a outras categorias.

- A comparação usa a matrícula Petros para pessoas. Para vínculos, usa também plano, patrocinadora e, quando disponível, matrícula na patrocinadora. Se não houver correspondência única, o PIC não presume um evento.
- Uma entrada na fotografia não confirma nova inscrição. Uma saída cadastral só é documentada quando o vínculo correspondente consta como **Ex-Participante** na extração atual. A ausência de pensionistas é informativa: aparece nos totais e tabelas, sem entrar na lista nominal, em **A esclarecer** ou nas saídas documentadas. Na unidade **Pessoas**, só se conta a pessoa que não está na fotografia atual; na unidade **Vínculos**, conta-se cada vínculo de pensão não localizado.
- O **Resumo das transições** e o **PDF gerencial** mostram, por plano e patrocinadora da fotografia anterior, as ausências de pensionistas e os movimentos do grupo **Ativos** para **Ex-Participantes** ou **Aposentados**. As transições exigem correspondência do vínculo. Na unidade **Pessoas**, o total de cada transição é por matrícula distinta e pode ser menor que a soma das categorias. O PDF usa os filtros de origem e a unidade da seção de movimentos, não a busca nominal ou o tipo de movimento.
- O histórico gerado nesta versão guarda apenas a evidência mínima de Ex-Participante para a comparação, sem incluir essas linhas nas regras ou nos totais de público. Arquivos anteriores continuam utilizáveis, mas para verificar saídas documentadas em uma competência antiga é necessário reprocessar a extração do mês que contém a situação Ex-Participante.

## Volume e compatibilidade

O leitor processa os XLSX em sequência e mantém apenas os campos relevantes; os XML das abas são lidos em partes. O painel carrega a competência selecionada e a anterior, não todas as bases em memória. O limite por XLSX é de 350 MB compactados e o limite por avaliação é de 1.200.000 linhas úteis; o limite prático depende de memória, formato e volume de achados. Dividir os arquivos reduz a pressão durante a leitura, mas os vínculos de uma competência ainda precisam caber na memória do navegador. O vínculo de pasta é opcional e depende da autorização do navegador. Use Edge ou Chrome para a melhor compatibilidade com pastas locais.
