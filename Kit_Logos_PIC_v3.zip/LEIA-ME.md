# Kit de Identidade Visual PIC v3.0

Matriz vetorial única reconstruída a partir do símbolo fornecido. Espaços vazios transparentes, faixas Cyprus e Sand e derivações com a mesma geometria. A edição 3 substitui os arquivos incorretos anteriores.

## Conteúdo
- Brand Book + Manual de Identidade Visual, Caderno de Assinaturas e Guia Rápido.
- Logos em SVG com nome em curvas, PNG transparente e PDF vetorial.
- Paleta JSON, CSS, GPL e prévia HTML.
- Modelo PPTX editável, POTX e PDF de consulta.
- Capas, papel timbrado e assinatura de e-mail em HTML.
- Fundos e imagens de apoio inéditas, geradas para o programa.

## Fontes
Delight por Rajesh Rajput: https://rajputrajesh-448.gumroad.com/l/Delight9. Instalar pelo autor. A licença permite uso, mas proíbe redistribuir os arquivos da fonte. O pacote não inclui esses arquivos.
Inter por Rasmus Andersson: https://github.com/rsms/inter. Licença OFL incluída.

## PowerPoint
O template usa Delight para títulos e Inter no corpo. Os logos são gráficos em curvas. Instale as fontes para preservar a aparência dos textos editáveis. Troque os campos entre colchetes e os dados demonstrativos antes de apresentar. As imagens são ilustrativas e não representam participantes reais da Petros.

## Organização
Este diretório acompanha o HUB. A cópia publicada é disponibilizada na área Identidade. Os 30 estudos antigos são históricos e não compõem a marca oficial.


PNG: lado maior de 4096 px, fundo transparente. PDF e SVG: geometria vetorial sem limite de resolução. `color` = texto verde; `color-black` = texto preto; `negative` = branco; `black` e `cyprus` = uma cor. A versão vertical centraliza cada linha pela área real das letras.

## Aplicação por fundo e tamanho
Branco: símbolo colorido com nome verde (color) ou preto (color-black). Sand: assinatura Cyprus ou preta. Cyprus e fundos escuros: negative branca. A geometria e os vazios são os mesmos em todas as cores. Nunca aplicar verde em fundo verde nem Sand em fundo Sand. Símbolo isolado: mínimo 48 px. Principal: 280 px; horizontal: 240 px; vertical: 180 px.

Os PDFs de produção têm fundo transparente. A versão branca parece vazia em um leitor com página branca: consulte o Caderno ou a prova de contraste para visualizar essa versão sobre Cyprus. PNGs transparentes têm 4096 px no lado maior. SVG e PDF mantêm curvas vetoriais e lettering convertido em contornos.

## Apresentações
40 modelos em PPTX e POTX. Use apenas os layouts convenientes; substitua todos os campos entre colchetes e os dados ilustrativos. Ajuste a numeração após selecionar/reordenar slides. Instale Delight pela origem oficial para editar títulos com fidelidade; o arquivo de fonte não é redistribuído neste kit. Inter e sua licença estão na pasta Fontes. Logos não dependem da instalação da fonte. O PDF de consulta é uma prévia de leitura; o PPTX contém textos, tabelas e gráficos editáveis.
